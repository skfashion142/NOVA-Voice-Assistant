# NOVA — Local-First Android Voice Assistant

NOVA is an Android voice assistant (Kotlin, package `com.nova.assistant`) that talks Hinglish/English. Wake word and common phone commands run **on the phone** (offline Vosk recognizer, no API key). Optional cloud providers are used only for open-ended questions.

| | |
|---|---|
| Version | 6.47 |
| Min / target SDK | 26 / 34 |
| Language / build | Kotlin 1.9.24, AGP 8.5.2, Gradle 8.7, JDK 17 |
| Status | Source complete; **Android build (CI) and phone testing: NOT YET RUN for v6.39 – v6.43** |

> Honest status: the rules layer (55 pure-Kotlin files) compiles and its 521 unit tests pass with kotlinc. `NovaService`, `MainActivity` and the other Android classes have **not** been compiled since v6.38. Run CI first — see [docs/BUILD.md](docs/BUILD.md).

## Capabilities

- **Voice control:** battery, time, torch, volume, brightness, media, navigation, open apps, camera, settings pages, calls (dialer only), WhatsApp messages, alarms/timers.
- **Owner-only voice:** commands are accepted only from the enrolled owner voice; unknown voices get one short refusal (rate-limited) and no command, AI or cloud call is made.
- **Locked phone:** on a voice match NOVA unlocks a *pattern-lock* phone through Accessibility, then runs the task. PIN/biometric locks are never opened.
- **Schedule:** repeating tasks by weekday, priority (normal / zaruri / bahut zaruri) and a note — by voice or the *MERA SCHEDULE* box.
- **Morning routine:** first unlock of the day (06:00–11:59) → greeting + today's jobs; 25‑minute lead reminders; **wake alarm only 06:00–12:00, rings again and again until OFF** (DISMISS = 1 min snooze).
- **Battery guard:** one alert each below 50/40/30/20/10 %; at ≤5 % a WhatsApp SOS to Papa and Mummy.
- **No auto-start:** nothing starts at boot or app open. NOVA runs only after you tap ACTIVATE.
- **Safety invariants:** no `CALL_PHONE`/`QUERY_ALL_PACKAGES`, screen monitoring off by default, banking/payment/installer screens blocked for tap/type, secrets encrypted with Android Keystore.

Full feature list and known limits: [docs/FEATURES_AND_LIMITS.md](docs/FEATURES_AND_LIMITS.md).

## Repository layout

```
app/                Android module (src/main, src/test)
docs/               BUILD, ARCHITECTURE, FEATURES_AND_LIMITS, PHONE_CHECKLIST, SETUP_STEPS, PROGRESS, HANDOFF
docs/archive/       Historical prompts, audits and reports (read-only history)
tools/              Python contract tests, knowledge/skill-pack builders, self-improve script
skillpacks/         Optional skill packs (JSON)
.github/workflows/  CI (unit tests + debug APK)
CHANGELOG.md        Version history
```

## Quick start

1. Push the repo to GitHub → Actions → **NOVA Android CI** (see [docs/BUILD.md](docs/BUILD.md)).
2. Install the debug APK, open NOVA, allow Microphone, set up your voice profile and pattern lock.
3. Tap **ACTIVATE**, say "nova", then a command. Run the [phone checklist](docs/PHONE_CHECKLIST.md).

## Contributing / handoff

Read [docs/HANDOFF.md](docs/HANDOFF.md) first. Rules: small steps, a fresh ZIP after each, and always state what was **RUN** vs **NOT RUN**.
