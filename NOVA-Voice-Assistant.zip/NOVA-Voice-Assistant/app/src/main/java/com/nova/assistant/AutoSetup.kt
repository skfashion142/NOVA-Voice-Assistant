package com.nova.assistant

import android.content.Context
import java.util.concurrent.atomic.AtomicBoolean

/**
 * v34 PART 3: ONE silent background runner for everything NOVA can prepare by itself once the owner has pressed "allow":
 *  1. the voice-check model (small download),
 *  2. the verified offline Qwen model when the device has enough RAM/storage,
 *  3. a tiny health check of every online AI provider that has a key (Groq, Qwen via Groq, OpenRouter).
 * No pop-up, nothing spoken, no provider name in a chat reply. Results are only SELF TEST lines (Settings).
 * Retries use AutoSetupPlan's back-off. It cannot switch on Accessibility / Notification access / Overlay: Android forbids that.
 */
object AutoSetup {
    private const val PREFS = "nova_auto_setup"
    private const val AUTO_ENROLL_STARTED = "voice_auto_enroll_started_v2"
    private val started = AtomicBoolean(false)
    @Volatile private var stopFlag = false
    private val lines = ArrayList<String>()

    private fun add(l: String) {
        synchronized(lines) {
            lines.add(l)
            while (lines.size > 40) lines.removeAt(0)
        }
    }

    /** Lines written by the background runner so far. */
    fun log(): List<String> = synchronized(lines) { ArrayList(lines) }

    /** Called when the mic service is running (permissions given). Safe to call again: only one runner exists. */
    fun start(ctx: Context) {
        startVoiceModel(ctx.applicationContext)   // v6.34: the 14 MB voice-check model also starts at app open and retries by itself
        startQwen(ctx.applicationContext)   // v6.33: the offline brain has its own runner, it no longer waits behind the other tasks
        if (!started.compareAndSet(false, true)) { stopFlag = false; return }   // already running (maybe about to stop): keep it
        stopFlag = false
        val app = ctx.applicationContext
        Thread({
            try {
                loop(app)
            } catch (e: Throwable) {
                add("WARN Auto setup ruk gaya - " + e.javaClass.simpleName)
            } finally {
                started.set(false)
            }
        }, "nova-autosetup").apply { isDaemon = true }.start()
    }

    fun stop() { stopFlag = true }

    private fun loop(app: Context) {
        var tasks = AutoSetupPlan.initial()
        var hindiAttempted = false
        while (!stopFlag) {
            val now = System.currentTimeMillis()
            val t = AutoSetupPlan.due(tasks, now)
            if (t == null) {
                // The provider task repeats every 6 hours, so code after loop(app) would never run while the service stays alive.
                // Try the optional Hindi model once after the initial voice/provider setup pass, before waiting for the next task.
                if (!hindiAttempted) {
                    hindiAttempted = true
                    if (!stopFlag && ExtCfg.autoModels(app) && !HindiPack.ready(app)) {
                        val herr = HindiPack.ensure(app)
                        if (herr == null) add("READY Hindi voice pack")
                        else if (herr != "wait" && herr != "busy") add("WARN Hindi voice pack - $herr, agli baar koshish hogi")
                    }
                    // Auto-enrol only once per installation. If a sample is rejected, the owner can use
                    // AWAAZ SAVE KARO again; the background runner must never start a new 5-sample loop.
                    val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    if (!stopFlag && NovaService.instance != null && !VoiceLock.hasProfile(app) &&
                        !prefs.getBoolean(AUTO_ENROLL_STARTED, false)) {
                        prefs.edit().putBoolean(AUTO_ENROLL_STARTED, true).apply()
                        try { NovaService.instance?.startVoiceEnroll() } catch (e: Throwable) { }
                    }
                }
                val next = AutoSetupPlan.nextWake(tasks) ?: return
                try { Thread.sleep(minOf(maxOf(next - now, 1000L), 60_000L)) } catch (e: InterruptedException) { return }
                continue
            }
            val o = try {
                when (t.id) {
                    AutoSetupPlan.VOICE -> voiceTask(app)
                    AutoSetupPlan.PROVIDERS -> providersTask(app)
                    else -> AutoSetupPlan.Outcome.FATAL
                }
            } catch (e: Throwable) { AutoSetupPlan.Outcome.RETRY }
            val after = AutoSetupPlan.apply(t, o, System.currentTimeMillis())
            tasks = tasks.map { if (it.id == t.id) after else it }
        }
    }

    private fun voiceTask(app: Context): AutoSetupPlan.Outcome {
        if (!ExtCfg.autoModels(app)) { add("SKIP Awaaz model - auto band hai"); return AutoSetupPlan.Outcome.SKIP }
        if (VoiceLock.modelReady(app)) return AutoSetupPlan.Outcome.SKIP
        val err = ModelAuto.silentVoice(app)
        return if (err == null) { add("PASS Awaaz model - download ho gaya"); AutoSetupPlan.Outcome.OK }
        else { add("WARN Awaaz model - $err, dobara koshish hogi"); AutoSetupPlan.Outcome.RETRY }
    }

    // ---- v6.33: offline Qwen brain, downloaded automatically as soon as the app opens (own thread, retries by itself, resumes the .part file)
    private val qwenStarted = AtomicBoolean(false)

    private fun online(app: Context): Boolean = try {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null && caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (e: Throwable) { true }

    private val voiceStarted = AtomicBoolean(false)

    private fun startVoiceModel(app: Context) {
        if (!voiceStarted.compareAndSet(false, true)) return
        Thread({
            try {
                try { Thread.sleep(1500L) } catch (e: InterruptedException) { return@Thread }
                var attempt = 0
                while (ExtCfg.autoModels(app) && !VoiceLock.modelReady(app)) {
                    if (online(app)) {
                        val err = ModelAuto.silentVoice(app)
                        if (err == null) { add("PASS Awaaz model - download ho gaya"); break }
                        if (err != "busy") { add("WARN Awaaz model - $err, dobara koshish hogi"); attempt++ }
                    }
                    val wait = if (!online(app)) 15_000L else minOf(10_000L shl minOf(attempt, 6), 10L * 60_000L)
                    try { Thread.sleep(wait) } catch (e: InterruptedException) { return@Thread }
                }
                // v6.35: better voice engine (WeSpeaker ResNet, 26 MB). Only on strong phones, never fatal, resumes by itself.
                var tries = 0
                while (ExtCfg.autoModels(app) && VoiceLock.modelReady(app) && OnnxSpeaker.wanted(app) && !OnnxSpeaker.modelReady(app) && tries < 6) {
                    if (online(app)) {
                        val err = OnnxSpeaker.ensure(app)
                        if (err == null) { add("PASS Behtar awaaz model (ResNet) - download ho gaya"); break }
                        if (err == "phone-not-suitable") break
                        if (err != "busy") { add("WARN Behtar awaaz model - $err, dobara koshish hogi"); tries++ }
                    }
                    try { Thread.sleep(if (!online(app)) 15_000L else minOf(10_000L shl minOf(tries, 5), 5L * 60_000L)) } catch (e: InterruptedException) { return@Thread }
                }
            } catch (e: Throwable) {
                add("WARN Awaaz model runner ruk gaya - " + e.javaClass.simpleName)
            } finally {
                voiceStarted.set(false)
            }
        }, "nova-voice-model-auto").apply { isDaemon = true; priority = Thread.MIN_PRIORITY }.start()
    }

    private fun startQwen(app: Context) {
        if (!qwenStarted.compareAndSet(false, true)) return
        Thread({
            try {
                qwenLoop(app)
            } catch (e: Throwable) {
                add("WARN Offline Qwen runner ruk gaya - " + e.javaClass.simpleName)
            } finally {
                qwenStarted.set(false)
            }
        }, "nova-qwen-auto").apply { isDaemon = true; priority = Thread.MIN_PRIORITY }.start()
    }

    private fun qwenLoop(app: Context) {
        try { Thread.sleep(2500L) } catch (e: InterruptedException) { return }   // let the first screen draw before any disk / network work
        var attempt = 0
        var refused = 0
        while (true) {
            if (UpdateManager.activeModelPath(app).isNotEmpty()) {
                add("READY Offline Qwen")
                LocalBrains.warmUp(app)
                return
            }
            if (!ModelCatalog.ramOk(totalRamMb(app))) { add("SKIP Offline Qwen - RAM too low"); return }
            if (LocalBrains.factory == null) LocalBrains.installEngine(app)
            if (online(app)) {
                val r = ModelAuto.silentOfflineQwen(app)
                when {
                    r == null -> {
                        add("READY Offline Qwen - downloaded and verified, offline ON")
                        LocalBrains.warmUp(app)
                        return
                    }
                    r == "ram-low" || r == "engine-unavailable" -> { add("SKIP Offline Qwen - $r"); return }
                    r == "busy" -> { /* the manual DOWNLOAD button is running it: just look again soon */ }
                    else -> {
                        add("WARN Offline Qwen - $r, dobara koshish hogi")
                        // A wrong file is deleted by the safety check; do not download 491 MB again and again.
                        if ((r ?: "").contains("refused") || (r ?: "").contains("checksum")) { if (++refused >= 2) { add("FAIL Offline Qwen - file verify nahi hui, band"); return } }
                        attempt++
                    }
                }
            }
            val wait = if (!online(app)) 20_000L else minOf(15_000L shl minOf(attempt, 7), 30L * 60_000L)
            try { Thread.sleep(wait) } catch (e: InterruptedException) { return }
        }
    }

    private fun totalRamMb(ctx: Context): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager ?: return 0L
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.totalMem / (1024L * 1024L)
    }

    /** Providers that have the key they need. Pollinations (no key) is left out: it is not a setup item. */
    private fun keyOf(ctx: Context, p: FreeProvider): String = when (p.keyName) {
        "groq" -> SecureStore.getGroq(ctx)
        "openrouter" -> SecureStore.getSlot(ctx, "openrouter")
        "zai" -> SecureStore.getSlot(ctx, "zai")
        "zai2" -> SecureStore.getSlot(ctx, "zai2")
        "zai3" -> SecureStore.getSlot(ctx, "zai3")
        else -> ""
    }.trim()

    /** One tiny request per keyed provider (first model only). Returns SELF TEST lines. Network: worker thread only. */
    fun checkProviders(ctx: Context): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        for (p in FreeProviders.ordered()) {
            if (p.keyName == null) continue
            val key = keyOf(ctx, p)
            if (key.isEmpty()) continue
            val r = FreeHttp.post(p, FreeProviders.buildBody(p.models[0], "Reply with one word.", "ok", 16), key)
            out.add(Pair(p.label + " (" + p.models[0] + ")", r.code))
        }
        return out
    }

    private fun providersTask(app: Context): AutoSetupPlan.Outcome {
        val res = checkProviders(app)
        if (res.isEmpty()) return AutoSetupPlan.Outcome.SKIP
        var worst = AutoSetupPlan.Outcome.OK
        for ((label, code) in res) {
            add(AutoSetupPlan.line(label, code))
            if (AutoSetupPlan.outcomeFor(code) == AutoSetupPlan.Outcome.RETRY) worst = AutoSetupPlan.Outcome.RETRY
        }
        return worst
    }
}
