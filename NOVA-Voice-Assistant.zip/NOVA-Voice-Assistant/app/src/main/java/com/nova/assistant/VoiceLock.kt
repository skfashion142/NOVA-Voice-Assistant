package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.SpeakerModel
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * v17 "only my voice": storage + speaker model + vector extraction.
 * Privacy: the voiceprint (numbers only, no audio) stays in the app's private no-backup folder. Audio is never saved,
 * and neither the print nor audio is sent anywhere. Only the public Vosk speaker model is downloaded (one https host).
 * Evidence level: written + statically checked. Not compiled here, not phone tested.
 */
object VoiceLock {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-spk-0.4.zip"
    private const val MODEL_HOST = "alphacephei.com"
    private const val MAX_ZIP_BYTES = 40L * 1024 * 1024
    private const val MAX_UNZIPPED_BYTES = 90L * 1024 * 1024

    @Volatile private var spk: SpeakerModel? = null
    /** v6.25: short reason of the last failed vector() ("" = fine), shown in the chat so a failure is no longer a mystery. */
    @Volatile var lastWhy: String = ""

    private fun modelDir(ctx: Context) = File(ctx.filesDir, "model-spk")
    private fun profileFile(ctx: Context) = File(ctx.noBackupFilesDir, "voiceprint.json")

    fun modelReady(ctx: Context): Boolean {
        val d = modelDir(ctx)
        // The official vosk-model-spk-0.4 package contains these four core speaker files.
        // Checking them avoids reporting READY when an interrupted/unpacked archive only has a few files.
        val raw = File(d, "final.ext.raw")
        return File(d, ".done").isFile &&
            raw.isFile && raw.length() > 1_000_000L &&
            File(d, "mean.vec").isFile &&
            File(d, "transform.mat").isFile &&
            File(d, "mfcc.conf").isFile
    }

    fun hasProfile(ctx: Context): Boolean = loadFull(ctx) != null

    /** v6.35: both prints of the saved profile ("v" Vosk, optional "v2" ONNX), or null. */
    fun loadFull(ctx: Context): VoiceProfileCodec.Profile? = try {
        val f = profileFile(ctx)
        if (!f.isFile) null else VoiceProfileCodec.decode(f.readText())
    } catch (e: Exception) { null }

    /** Engine that is used right now: "onnx" only if the profile has the ONNX print AND the engine is usable on this phone. */
    fun activeEngine(ctx: Context): String {
        val p = loadFull(ctx)
        return VoiceEngineRules.pickEngine(p?.v2 != null, p?.v2 != null && OnnxSpeaker.usable(ctx))
    }

    /** Engine that produced the last vector() (set on every call). Read right after vector() on the same thread. */
    @Volatile var lastEngine: String = VoiceEngineRules.VOSK

    /** The saved print of the ACTIVE engine (Vosk 128-d or ONNX 256-d). */
    fun loadProfile(ctx: Context): DoubleArray? {
        val p = loadFull(ctx) ?: return null
        return if (activeEngine(ctx) == VoiceEngineRules.ONNX) p.v2 else p.v
    }

    /**
     * The saved print that matches a vector just made by vector(): picked by the vector's engine (lastEngine), so a one-call
     * fallback from ONNX to Vosk still compares against the Vosk print. null = no matching print.
     */
    fun profileForLast(ctx: Context): DoubleArray? {
        val p = loadFull(ctx) ?: return null
        return if (lastEngine == VoiceEngineRules.ONNX) p.v2 else p.v
    }

    /** Distance limit for [engine] (default: the engine of the last vector). */
    fun threshold(ctx: Context, engine: String = lastEngine): Double =
        VoiceEngineRules.effectiveThreshold(engine, ExtCfg.voiceLevel(ctx), ExtCfg.voiceThreshold(ctx), ExtCfg.voiceTunedEngine(ctx))

    /** Call right after the owner's tuned limit was saved: remembers WHICH engine it was tuned with. */
    fun markTuned(ctx: Context) { ExtCfg.setVoiceTunedEngine(ctx, lastEngine) }

    /** Text for the Settings status line. */
    fun engineText(ctx: Context): String {
        val p = loadFull(ctx)
        val eng = activeEngine(ctx)
        return VoiceEngineRules.engineText(eng, p != null, p?.v2 != null, OnnxSpeaker.usable(ctx))
    }

    /** Vosk-only save (kept for old callers). */
    fun saveProfile(ctx: Context, v: DoubleArray): Boolean = saveProfile(ctx, v, null)

    fun saveProfile(ctx: Context, v: DoubleArray, v2: DoubleArray?): Boolean = try {
        val text = VoiceProfileCodec.encode(v, v2) ?: return false
        val target = profileFile(ctx)
        val tmp = File(target.parentFile, target.name + ".tmp")
        tmp.writeText(text)
        if (!tmp.renameTo(target)) { target.writeText(tmp.readText()); tmp.delete() }
        loadFull(ctx) != null
    } catch (e: Exception) { false }

    /** Deletes the owner's voiceprint (the shared speaker model file stays). */
    fun deleteProfile(ctx: Context) {
        try { profileFile(ctx).delete() } catch (e: Exception) { }
    }

    fun release() {
        try { spk?.close() } catch (t: Throwable) { }
        spk = null
        try { OnnxSpeaker.release() } catch (t: Throwable) { }
    }

    private fun speakerModel(ctx: Context): SpeakerModel? {
        spk?.let { return it }
        if (!modelReady(ctx)) return null
        return try {
            val m = SpeakerModel(modelDir(ctx).absolutePath)
            spk = m
            m
        } catch (t: Throwable) { null }
    }

    /**
     * x-vector and frame count for one utterance (16-bit mono PCM). null = no usable vector.
     * v6.25: Vosk hands out the speaker vector together with every finished segment. When the endpointer fires inside
     * acceptWaveForm (a pause or the trailing silence), that segment's vector is only in getResult(); finalResult() then
     * holds just the leftover tail and usually has NO vector. The old code read finalResult() only, so long commands or
     * ones with trailing silence came back "no vector" (HYPOTHESIS for the owner's "voice model could not run" lines,
     * Kotlin not compiled, not phone tested). Now every segment's vector is collected and merged by frame count.
     */
    fun vectorVosk(ctx: Context, md: Model, pcm: ByteArray, rate: Int): Pair<DoubleArray, Int>? {
        val sm = speakerModel(ctx)
        if (sm == null) { lastWhy = "no-speaker-model"; return null }
        var rec: Recognizer? = null
        return try {
            // Use a normal recognizer and attach the speaker model explicitly. Vosk documents this path as useful
            // when the recognizer also has grammar/decoder configuration, and it keeps speaker extraction independent
            // from the constructor overload used by older Android AARs.
            val r = Recognizer(md, rate.toFloat())
            r.setSpeakerModel(sm)
            rec = r
            val parts = ArrayList<Pair<DoubleArray, Int>>()
            fun take(js: String) {
                try {
                    val j = JSONObject(js)
                    val a = j.optJSONArray("spk")
                    if (a != null && a.length() > 0) {
                        val v = DoubleArray(a.length()) { a.optDouble(it, 0.0) }
                        var frames = j.optInt("spk_frames", 0)
                        // Some older/native builds omitted spk_frames while still returning a valid x-vector.
                        // Estimate conservatively from PCM duration so a valid vector is not discarded as zero-frame.
                        if (frames <= 0) frames = ((pcm.size / 2.0) / rate * 100.0).toInt()
                        parts.add(Pair(v, frames))
                    }
                } catch (e: Exception) { }
            }
            var off = 0
            while (off < pcm.size) {
                val n = minOf(6400, pcm.size - off)
                if (r.acceptWaveForm(pcm.copyOfRange(off, off + n), n)) take(r.result)
                off += n
            }
            take(r.finalResult)
            val merged = SpeakerRules.mergeParts(parts)
            lastWhy = when {
                merged == null -> "no-voice-vector"
                merged.second < 50 -> "voice-vector-too-short"
                else -> ""
            }
            merged
        } catch (t: Throwable) { lastWhy = t.javaClass.simpleName; null } finally {
            try { rec?.close() } catch (t: Throwable) { }
        }
    }

    /** v6.35: ONNX (ResNet34) print of one utterance, or null. Enrolment uses this next to vectorVosk. */
    fun vectorOnnx(ctx: Context, pcm: ByteArray): Pair<DoubleArray, Int>? = OnnxSpeaker.embed(ctx, pcm)

    /**
     * v6.35: the vector of the ACTIVE engine. If the ONNX engine returns nothing for this call, the Vosk vector is used for
     * this call (lastEngine tells which one it was). Two ONNX errors in a row switch the ONNX engine off by itself.
     */
    fun vector(ctx: Context, md: Model, pcm: ByteArray, rate: Int): Pair<DoubleArray, Int>? {
        if (activeEngine(ctx) == VoiceEngineRules.ONNX) {
            val o = vectorOnnx(ctx, pcm)
            if (o != null) { lastEngine = VoiceEngineRules.ONNX; lastWhy = ""; return o }
        }
        lastEngine = VoiceEngineRules.VOSK
        return vectorVosk(ctx, md, pcm, rate)
    }

    private val downloading = java.util.concurrent.atomic.AtomicBoolean(false)

    /**
     * Downloads the public speaker model once (about 14 MB). Returns null on success, else a short reason ("busy" = another
     * download is already running, so a second tap never starts a parallel one). Up to 3 tries with a slow-network timeout.
     */
    fun downloadModel(ctx: Context): String? {
        if (modelReady(ctx)) return null
        if (!downloading.compareAndSet(false, true)) return "busy"
        try {
            var last: String? = "unknown"
            for (attempt in 1..3) {
                last = downloadOnce(ctx)
                if (last == null) return null
                if (attempt < 3) try { Thread.sleep(2000) } catch (e: InterruptedException) { return last }
            }
            return last
        } finally {
            downloading.set(false)
        }
    }

    private fun downloadOnce(ctx: Context): String? {
        if (modelReady(ctx)) return null
        val tmpZip = File(ctx.cacheDir, "spk.zip.part")
        val tmpDir = File(ctx.cacheDir, "spk_unpack")
        try {
            tmpZip.delete()
            tmpDir.deleteRecursively()
            var cur = MODEL_URL
            var c: HttpURLConnection? = null
            for (hop in 0..4) {
                val u = URL(cur)
                if (u.protocol != "https" || !(u.host == MODEL_HOST || u.host.endsWith(".$MODEL_HOST"))) return "blocked host"
                val x = u.openConnection() as HttpURLConnection
                x.instanceFollowRedirects = false
                x.connectTimeout = 20000
                x.readTimeout = 60000
                x.setRequestProperty("User-Agent", "NOVAAndroidAssistant/6.18 (speaker model)")
                val code = x.responseCode
                if (code in 300..399) {
                    val loc = x.getHeaderField("Location")
                    x.disconnect()
                    if (loc == null) return "redirect"
                    cur = URL(u, loc).toString()
                    continue
                }
                if (code != 200) { x.disconnect(); return "http $code" }
                c = x
                break
            }
            val conn = c ?: return "too many redirects"
            var total = 0L
            conn.inputStream.use { ins ->
                tmpZip.outputStream().use { out ->
                    val buf = ByteArray(65536)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_ZIP_BYTES) throw IOException("too big")
                        out.write(buf, 0, n)
                    }
                }
            }
            conn.disconnect()
            tmpDir.mkdirs()
            val root = tmpDir.canonicalPath + File.separator
            var unzipped = 0L
            ZipInputStream(tmpZip.inputStream()).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    val dest = File(tmpDir, e.name)
                    if (!dest.canonicalPath.startsWith(root)) throw IOException("bad zip path")
                    if (e.isDirectory) { dest.mkdirs(); continue }
                    dest.parentFile?.mkdirs()
                    dest.outputStream().use { out ->
                        val buf = ByteArray(65536)
                        while (true) {
                            val n = zin.read(buf)
                            if (n < 0) break
                            unzipped += n
                            if (unzipped > MAX_UNZIPPED_BYTES) throw IOException("too big")
                            out.write(buf, 0, n)
                        }
                    }
                }
            }
            val kids = tmpDir.listFiles() ?: emptyArray()
            val src = if (kids.size == 1 && kids[0].isDirectory) kids[0] else tmpDir
            val dest = modelDir(ctx)
            dest.deleteRecursively()
            if (!src.renameTo(dest)) return "could not save"
            File(dest, ".done").writeText("1")
            return if (modelReady(ctx)) null else "model files missing"
        } catch (t: Throwable) {
            return t.javaClass.simpleName
        } finally {
            try { tmpZip.delete() } catch (t: Throwable) { }
            try { tmpDir.deleteRecursively() } catch (t: Throwable) { }
        }
    }
}
