package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var cfg: Cfg
    private var testTts: TextToSpeech? = null
    private var listenerOwned = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cfg = Cfg(this)
        ApiUsage.init(this)
        LocalBrains.installEngine(this)
        web = WebView(this)
        hardenWebView(web)
        web.setBackgroundColor(0)
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl(ASSET_URL)
        setContentView(web)
        web.post { firstRunPermissions() }   // v6.38 owner request: every permission asked together on the first open
        boostRefresh()
        // v6.32: Android Keystore work used to run here BEFORE the first frame (visible freeze on open). Same migration, now in the background.
        Thread {
            try {
                SecureStore.migrateOld(this)
                SecureStore.migrateSingleToPool(this)
            } catch (_: Exception) { }
        }.start()
        NovaService.listener = { role, text ->
            runOnUiThread {
                if (!isDestroyed) {
                    web.evaluateJavascript(
                        "onNova(" + JSONObject.quote(role) + "," + JSONObject.quote(text) + ")", null
                    )
                }
            }
        }
        NovaService.learnListener = { runJs("onLearn()") }
        NovaService.publishListener = { ok, msg, url ->
            runJs("onPublish(" + ok + "," + JSONObject.quote(msg) + "," + JSONObject.quote(url) + ")")
        }
        NovaService.siteListener = { ok, msg, html, saved ->
            runJs("onSite(" + ok + "," + JSONObject.quote(msg) + "," + JSONObject.quote(html) + "," + JSONObject.quote(saved) + ")")
        }
        NovaService.imageListener = { ok, msg, thumb, saved ->
            runJs("onImage(" + ok + "," + JSONObject.quote(msg) + "," + JSONObject.quote(thumb) + "," + JSONObject.quote(saved) + ")")
        }
        NovaService.permRequest = { what ->
            if (what == "contacts") runOnUiThread { if (!isDestroyed) requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTACTS) }
        }
        listenerOwned = true
        // Prepare verified offline models silently as soon as the app is opened.
        web.postDelayed({ if (!isDestroyed) AutoSetup.start(this) }, 1500L)   // v6.49: the first frames and the intro run before any model / disk work
        // NOVA never starts by itself: opening the app does not start the microphone. Only the owner's ACTIVATE tap does.
        handleIntent(intent)
    }

    /** The page is a local asset only: no file/content access, no navigation away, no network sub-requests. */
    private fun hardenWebView(w: WebView) {
        val s = w.settings
        s.javaScriptEnabled = true
        s.mediaPlaybackRequiresUserGesture = false   // lets the opening sound play without a tap
        s.domStorageEnabled = true                  // remembers the sound on/off choice
        s.allowFileAccess = false              // file:///android_asset/ is always readable regardless
        s.allowContentAccess = false
        s.allowFileAccessFromFileURLs = false
        s.allowUniversalAccessFromFileURLs = false
        s.setGeolocationEnabled(false)
        s.javaScriptCanOpenWindowsAutomatically = false
        s.setSupportMultipleWindows(false)
        s.textZoom = s.textZoom.coerceAtMost(115)   // v6.38: big system font sizes no longer push buttons off small screens
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                // Never navigate anywhere except our own page.
                return request?.url?.toString() != ASSET_URL
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url?.toString() ?: return blocked()
                return if (u.startsWith(ASSET_PREFIX) || u.startsWith("data:") || u.startsWith("blob:")) null else blocked()
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (url != null && !url.startsWith(ASSET_PREFIX)) view?.stopLoading()
            }
        }
    }

    /** Smoothness: use the phone's highest refresh rate (90/120 Hz) while NOVA is on screen. */
    @Suppress("DEPRECATION")
    private fun boostRefresh() {
        try {
            val modes = windowManager.defaultDisplay.supportedModes
            var best: android.view.Display.Mode? = null
            for (m in modes) { if (best == null || m.refreshRate > best.refreshRate) best = m }
            if (best != null) {
                val lp = window.attributes
                lp.preferredDisplayModeId = best.modeId
                window.attributes = lp
            }
        } catch (e: Throwable) {
        }
    }

    private fun blocked() = WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))

    /** Back: the page decides (close sheet / settings, play the closing animation, or leave). */
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.novaBack?novaBack():'exit')") { r ->
            if (r == null || r.contains("exit")) moveTaskToBack(true)
        }
    }

    @Suppress("DEPRECATION")
    private fun vibe(ms: Long) {
        try {
            val v: android.os.Vibrator? = if (Build.VERSION.SDK_INT >= 31) {
                getSystemService(android.os.VibratorManager::class.java)?.defaultVibrator
            } else {
                getSystemService(VIBRATOR_SERVICE) as? android.os.Vibrator
            }
            if (v == null) return
            if (Build.VERSION.SDK_INT >= 26) {
                v.vibrate(android.os.VibrationEffect.createOneShot(ms, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                v.vibrate(ms)
            }
        } catch (e: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        NovaService.uiVisible = true
        pushFlow("resumed")
        nextSpecialPermission()   // v6.38: continues the one-time permission chain after the user comes back from a Settings page
        // v6.21: health dialogs are never shown automatically on resume. The owner can run SAB TEST KARO manually.
        // v6.33: quiet automatic self test (no popup/sound/torch/screen jump) once keys + mic permission exist, and again when they change.
        AutoTest.kick(this) { sum, rep -> runJs("onAutoTest(" + JSONObject.quote(sum) + "," + JSONObject.quote(rep) + ")") }
    }

    override fun onPause() {
        NovaService.uiVisible = false
        super.onPause()
    }

    override fun onNewIntent(i: Intent?) {
        super.onNewIntent(i)
        setIntent(i)
        handleIntent(i)
    }

    override fun onDestroy() {
        NovaService.uiVisible = false
        if (listenerOwned) {
            NovaService.listener = null
            NovaService.learnListener = null
            NovaService.publishListener = null
            NovaService.siteListener = null
            NovaService.imageListener = null
            NovaService.permRequest = null
        }
        testTts?.shutdown()
        testTts = null
        (web.parent as? ViewGroup)?.removeView(web)
        web.removeJavascriptInterface("Android")
        web.destroy()
        super.onDestroy()
    }

    // No auto-start of any kind: intents never start the microphone service.
    private fun handleIntent(i: Intent?) { i?.removeExtra("autostart") }

    private fun isDefaultAssistant(): Boolean = try {
        (Settings.Secure.getString(contentResolver, "assistant") ?: "").startsWith("$packageName/")
    } catch (e: Exception) { false }

    private fun granted(p: String) =
        checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    /**
     * Requests missing permissions (only reached from a user tap or a user-tapped notification),
     * then starts NOVA. Returns a short status word for the UI: started / perm / nomic.
     * afterResult=true means Android just answered a permission dialog, so we never ask again (no loop).
     */
    private fun startFlow(afterResult: Boolean): String {
        val prefs = getSharedPreferences("nova_perm", Context.MODE_PRIVATE)
        if (!granted(Manifest.permission.RECORD_AUDIO)) {
            if (afterResult) return "nomic"
            if (prefs.getBoolean("start_asked", false)) return "nomic"
            val ask = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (!granted(Manifest.permission.READ_CONTACTS)) ask.add(Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) ask.add(Manifest.permission.POST_NOTIFICATIONS)
            prefs.edit().putBoolean("start_asked", true).apply()
            runOnUiThread { requestPermissions(ask.toTypedArray(), REQ_START) }
            return "perm"
        }
        if (!afterResult && Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS) && !prefs.getBoolean("notif_asked", false)) {
            prefs.edit().putBoolean("notif_asked", true).apply()
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_START) }
            return "perm"
        }
        cfg.active = true
        val svc = Intent(this, NovaService::class.java)
        runOnUiThread {
            try {
                startForegroundService(svc)
            } catch (e: Exception) {
                cfg.active = false
                pushFlow("start_failed")
            }
        }
        return "started"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQ_ALL -> {
                // onResume (which follows this callback) continues with the special-access Settings pages
                if (granted(Manifest.permission.READ_CALENDAR)) { try { CalendarRead.scheduleUpcoming(this) } catch (e: Exception) { } }
                pushFlow("basics_done")
            }
            REQ_START -> pushFlow(startFlow(true))
            REQ_BASIC -> pushFlow("basics_done")
            REQ_CONTACTS -> {
                val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
                pushFlow(if (ok) "contacts_ok" else "contacts_denied")
            }
            REQ_CALENDAR -> {
                val ok = grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
                val count = if (ok) CalendarRead.scheduleUpcoming(this) else 0
                pushFlow(if (ok) "calendar_ok:$count" else "calendar_denied")
            }
            REQ_VIDEO -> {
                val cameraOk = checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                val micOk = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                pushFlow(if (cameraOk && micOk) "video_permission_ok" else "video_permission_denied")
            }
        }
    }

    /**
     * v6.38 owner request: on the very first open ask for all normal permissions in ONE Android dialog
     * (microphone, camera, contacts, calendar, notifications). Android does not allow the special-access items
     * (overlay, write settings, battery, exact alarm, notification access, accessibility) in that dialog, so they follow
     * one after another as Settings pages, each opened at most once. Nothing is granted by NOVA itself.
     */
    private fun firstRunPermissions() {
        val prefs = getSharedPreferences("nova_perm", Context.MODE_PRIVATE)
        if (prefs.getBoolean("all_asked_v638", false)) return
        val ask = ArrayList<String>()
        for (p in listOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.READ_CONTACTS, Manifest.permission.READ_CALENDAR)) {
            if (!granted(p)) ask.add(p)
        }
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) ask.add(Manifest.permission.POST_NOTIFICATIONS)
        prefs.edit().putBoolean("all_asked_v638", true).putBoolean("special_chain", true).apply()
        if (ask.isEmpty()) { nextSpecialPermission(); return }
        try { requestPermissions(ask.toTypedArray(), REQ_ALL) } catch (e: Exception) { nextSpecialPermission() }
    }

    /** Opens the next missing special-access Settings page (once per item). Called from onResume while the one-time chain is active. */
    private fun nextSpecialPermission() {
        val prefs = getSharedPreferences("nova_perm", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("special_chain", false)) return
        val done = HashSet(prefs.getStringSet("special_done", emptySet()) ?: emptySet())
        val pkgUri = Uri.parse("package:" + packageName)
        fun enabledIn(key: String): Boolean = try {
            (Settings.Secure.getString(contentResolver, key) ?: "").contains(packageName)
        } catch (e: Exception) { true }
        val steps = ArrayList<Pair<String, Intent?>>()
        if (!Settings.canDrawOverlays(this)) steps.add("overlay" to Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, pkgUri))
        if (!Settings.System.canWrite(this)) steps.add("write" to Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, pkgUri))
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) steps.add("battery" to Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri))
        } catch (e: Exception) { }
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                val am = getSystemService(Context.ALARM_SERVICE) as android.app.AlarmManager
                if (!am.canScheduleExactAlarms()) steps.add("alarm" to Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, pkgUri))
            } catch (e: Exception) { }
        }
        if (Build.VERSION.SDK_INT >= 34) {
            try {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
                if (!nm.canUseFullScreenIntent()) steps.add("fullscreen" to Intent("android.settings.MANAGE_APP_USE_FULL_SCREEN_INTENT", pkgUri))
            } catch (e: Exception) { }
        }
        if (!enabledIn("enabled_notification_listeners")) steps.add("listener" to Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        if (!enabledIn("enabled_accessibility_services")) steps.add("access" to Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        for ((id, intent) in steps) {
            if (id in done || intent == null) continue
            done.add(id)
            prefs.edit().putStringSet("special_done", done).apply()
            try { startActivity(intent); return } catch (e: Exception) { /* page missing on this phone: try the next one */ }
        }
        prefs.edit().putBoolean("special_chain", false).apply()
        pushFlow("perm_all_done")
    }

    /** Tells the page the result of an asynchronous action (the page defines onFlow). */
    private fun pushFlow(status: String) {
        runOnUiThread {
            if (!isDestroyed) {
                web.evaluateJavascript(
                    "if(window.onFlow)onFlow(" + JSONObject.quote(status) + ")", null
                )
            }
        }
    }

    // ---- FIXIMG1: picked photo + AI image (explicit user taps only)
    private var pickedPhoto: ByteArray? = null
    @Volatile private var imgBusy = false

    private fun runJs(js: String) {
        runOnUiThread { if (!isDestroyed) web.evaluateJavascript(js, null) }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_SPEECH) {
            val t = if (resultCode == RESULT_OK) data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty() else ""
            runJs("onSystemVoice(" + JSONObject.quote(t) + ")")
            return
        }
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == REQ_EXPORT_TEACH) {
            Thread {
                val ok = try {
                    val out = contentResolver.openOutputStream(uri) ?: throw java.io.IOException("No output stream")
                    out.use { it.write(TeachStore.exportJson(this).toByteArray(Charsets.UTF_8)) }
                    true
                } catch (_: Exception) { false }
                runJs("onTeachBackup(" + JSONObject.quote(if (ok) "export_ok" else "export_fail") + ")")
            }.start()
            return
        }
        if (requestCode == REQ_IMPORT_TEACH) {
            Thread {
                val result = try {
                    val raw = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                    if (raw == null || raw.size > 20_000) "invalid" else TeachStore.importJson(this, String(raw, Charsets.UTF_8))
                } catch (_: Exception) { "invalid" }
                runJs("onTeachBackup(" + JSONObject.quote(if (result == "ok") "import_ok" else "import_" + result) + ")")
            }.start()
            return
        }
        if (requestCode != REQ_PICK) return
        Thread {
            try {
                val raw = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (raw == null || raw.isEmpty()) { runJs("onPhotoErr('Photo padh nahi paya')"); return@Thread }
                if (raw.size > 30000000) { runJs("onPhotoErr('Photo bahut badi hai')"); return@Thread }
                val small = ImageGen.shrink(raw, 1280)
                if (small == null) { runJs("onPhotoErr('Ye photo format nahi padh paya')"); return@Thread }
                pickedPhoto = small
                val thumb = ImageGen.shrink(small, 160) ?: small
                runJs("onPhoto(" + JSONObject.quote(ImageGen.b64(thumb)) + ")")
            } catch (e: Throwable) { runJs("onPhotoErr('Photo padhne mein dikkat')") }
        }.start()
    }

    @Volatile private var pubBusy = false

    private fun startPublish(subject: String, html: String) {
        pubBusy = true
        Thread {
            var js: String
            try {
                val r = GitHubPublish.run(this, subject, html)
                js = "onPublish(" + r.ok + "," + JSONObject.quote(r.msg) + "," + JSONObject.quote(r.url) + ")"
            } catch (e: Throwable) {
                js = "onPublish(false," + JSONObject.quote("Publish karte waqt dikkat aayi") + ",\"\")"
            }
            pubBusy = false
            runJs(js)
        }.start()
    }

    private fun startImage(prompt: String, photo: ByteArray?) {
        imgBusy = true
        Thread {
            var js = ""
            try {
                val full = if (photo != null)
                    "Edit the attached photo exactly as requested and keep everything else, especially faces and identity, unchanged. Request: " + prompt
                else prompt
                val r = ImageGen.generate(this, full, photo)
                var thumb = ""
                var saved = ""
                val img = r.img
                if (r.ok && img != null) {
                    saved = ImageGen.saveToGallery(this, img) ?: ""
                    thumb = ImageGen.b64(ImageGen.shrink(img, 1024) ?: img)
                }
                val good = r.ok && thumb.isNotEmpty()
                js = "onImage(" + good + "," + JSONObject.quote(r.msg) + "," + JSONObject.quote(thumb) + "," + JSONObject.quote(saved) + ")"
            } catch (e: Throwable) {
                js = "onImage(false," + JSONObject.quote("Image banate waqt dikkat aayi") + ",\"\",\"\")"
            }
            imgBusy = false
            runJs(js)
        }.start()
    }

    // ---- FIXTEST: image API test (asks first, may cost a little)
    private fun runImageTest() {
        imgBusy = true
        Thread {
            var line = ""
            try {
                val r = ImageGen.generateDirect(this, "A plain blue circle on a white background, minimal", null)
                val img = r.img
                if (r.ok && img != null) {
                    val saved = ImageGen.saveToGallery(this, img)
                    line = "PASS  Image banana: image mili (" + (img.size / 1024) + " KB). Gallery save: " + (saved ?: "FAIL")
                } else {
                    line = "FAIL  Image banana: " + r.msg
                }
            } catch (e: Throwable) {
                line = "FAIL  Image test beech mein ruk gaya"
            }
            imgBusy = false
            runJs("onSelfTest(" + JSONObject.quote(line) + ")")
        }.start()
    }

    // FIXFREE2: tests each free image provider one by one (text-only prompt, no photo)
    private fun runFreeImageTest() {
        imgBusy = true
        Thread {
            try {
                FreeImage.testAll(this) { l -> runJs("onSelfTest(" + JSONObject.quote(l) + ")") }
            } catch (e: Throwable) {
                runJs("onSelfTest(" + JSONObject.quote("FAIL  Free image test beech mein ruk gaya") + ")")
            }
            imgBusy = false
        }.start()
    }

    inner class Bridge {
        @JavascriptInterface
        fun vibrate(ms: Int) { vibe(ms.toLong().coerceIn(5L, 400L)) }

        /** Opens the phone's own voice typing (the same engine the keyboard mic uses). The text comes back through onSystemVoice(). */
        @JavascriptInterface
        fun systemVoice(): String = try {
            runOnUiThread {
                try {
                    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                        .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                        .putExtra(RecognizerIntent.EXTRA_PROMPT, "Boliye...")
                        .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                    @Suppress("DEPRECATION")
                    this@MainActivity.startActivityForResult(i, REQ_SPEECH)
                } catch (e: Exception) { runJs("onSystemVoice('')") }
            }
            "ok"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun running() = NovaService.running

        @JavascriptInterface
        fun hasKey() = SecureStore.hasKeys(this@MainActivity)

        /** Keys are only ever written here, never sent back to the page. */
        @JavascriptInterface
        fun saveKeys(raw: String): String = try {
            val keys = Logic.parseKeys(raw)
            if (keys.isEmpty()) "invalid"
            else if (SecureStore.saveKeys(this@MainActivity, keys)) "ok:" + keys.size
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun keyCount(): Int = SecureStore.getKeys(this@MainActivity).size

        @JavascriptInterface
        fun clearKey() { SecureStore.clearKeys(this@MainActivity) }


        // ---- v6.40 schedule editor (days + time + how important, own words)
        @JavascriptInterface
        fun getSchedules(): String {
            val a = JSONArray()
            for (e in ScheduledTaskStore.list(this@MainActivity)) {
                a.put(JSONObject().put("id", e.id).put("label", e.spec.label).put("kind", e.spec.kind.name)
                    .put("time", String.format(java.util.Locale.ROOT, "%02d:%02d", e.spec.hour, e.spec.minute))
                    .put("days", ScheduledTaskRules.dayText(e.spec.days)).put("repeat", e.spec.repeatDaily)
                    .put("prio", e.spec.prio).put("note", e.spec.note))
            }
            return a.toString()
        }

        @JavascriptInterface
        fun setSchedulePrio(id: String, prio: Int, note: String): String =
            if (ScheduledTaskStore.update(this@MainActivity, id, prio.coerceIn(0, 2), note.trim().take(120)) != null) "ok" else "notfound"

        @JavascriptInterface
        fun cancelSchedule(id: String): String = if (ScheduledTaskStore.cancel(this@MainActivity, id)) "ok" else "notfound"

        /** time = "HH:MM" (24 h). daysMask: Monday = 1 ... Sunday = 64, 0 = no day filter. Returns the store status or badtime / nolabel. */
        @JavascriptInterface
        fun addSchedule(label: String, time: String, daysMask: Int, repeat: Boolean, prio: Int, note: String): String {
            val t = Regex("^\\s*(\\d{1,2}):(\\d{2})\\s*$").find(time) ?: return "badtime"
            val hh = t.groupValues[1].toInt()
            val mm = t.groupValues[2].toInt()
            if (hh !in 0..23 || mm !in 0..59) return "badtime"
            if (label.isBlank()) return "nolabel"
            val spec = ScheduledTaskRules.Spec(hh, mm, repeat, ScheduledTaskRules.Kind.REMINDER, label.trim().take(100),
                days = daysMask and 127, prio = prio.coerceIn(0, 2), note = note.trim().take(120))
            return ScheduledTaskStore.add(this@MainActivity, spec)
        }

        @JavascriptInterface
        fun stopSpeak() { NovaService.instance?.stopSpeaking() }

        @JavascriptInterface
        fun sendText(t: String): String = NovaService.instance?.typed(t.take(500)) ?: "off"

        @JavascriptInterface
        fun wakeNow() { NovaService.instance?.wakeNow() }

        @JavascriptInterface
        fun selfTest(): String {
            if (SelfTest.running) return "busy"
            SelfTest.start(
                this@MainActivity,
                { l -> runJs("onSelfTest(" + JSONObject.quote(l) + ")") },
                { rep -> runJs("onSelfTestDone(" + JSONObject.quote(rep) + ")") }
            )
            return "started"
        }

        @JavascriptInterface
        fun getFreeImg(): Boolean = FreeImage.enabled(this@MainActivity)

        @JavascriptInterface
        fun setFreeImg(on: Boolean): String {
            FreeImage.setEnabled(this@MainActivity, on)
            return "ok"
        }

        @JavascriptInterface
        fun selfTestFree(): String {
            if (imgBusy) return "busy"
            runOnUiThread {
                try {
                    android.app.AlertDialog.Builder(this@MainActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Free image test karein?")
                        .setMessage("Har free provider ko ek chhota text prompt jaayega (koi photo nahi). Together aur Hugging Face tabhi jab unki key saved ho. Hugging Face par paise lag sakte hain. 1-2 minute lag sakte hain.")
                        .setPositiveButton("HAAN") { _, _ -> runFreeImageTest() }
                        .setNegativeButton("NAHI", null)
                        .show()
                } catch (e: Exception) {
                }
            }
            return "asking"
        }

        @JavascriptInterface
        fun selfTestImage(): String {
            if (!SecureStore.hasKeys(this@MainActivity)) return "nokey"
            if (imgBusy) return "busy"
            runOnUiThread {
                try {
                    android.app.AlertDialog.Builder(this@MainActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Image test karein?")
                        .setMessage("Gemini se 1 chhoti image banegi. Billing wali key par thoda paisa lag sakta hai.")
                        .setPositiveButton("HAAN") { _, _ -> runImageTest() }
                        .setNegativeButton("NAHI", null)
                        .show()
                } catch (e: Exception) {
                }
            }
            return "asking"
        }

        @JavascriptInterface
        fun copyText(t: String): String = try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("NOVA report", t.take(20000)))
            "ok"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun getErrors(): String = ErrLog.dump()

        @JavascriptInterface
        fun clearErrors(): String { ErrLog.clear(); return "ok" }

        @JavascriptInterface
        fun openPowerGuide(): String = try { PowerGuide.open(this@MainActivity) } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun shareText(t: String): String {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "text/plain"
                    i.putExtra(Intent.EXTRA_TEXT, t.take(20000))
                    startActivity(Intent.createChooser(i, "Report bhejo"))
                } catch (e: Exception) {
                }
            }
            return "ok"
        }

        @JavascriptInterface
        fun pickPhoto(): String {
            runOnUiThread {
                try {
                    val i = Intent(Intent.ACTION_GET_CONTENT)
                    i.type = "image/*"
                    i.addCategory(Intent.CATEGORY_OPENABLE)
                    startActivityForResult(Intent.createChooser(i, "Photo chuno"), REQ_PICK)
                } catch (e: Exception) {
                    runJs("onPhotoErr('Gallery nahi khuli')")
                }
            }
            return "ok"
        }

        @JavascriptInterface
        fun clearPhoto() { pickedPhoto = null }

        /** started / asking (waits for the HAAN tap) / busy / nokey / empty. A photo is only uploaded after that tap. */
        @JavascriptInterface
        fun makeImage(prompt: String): String {
            val p = prompt.trim().take(800)
            if (p.isEmpty()) return "empty"
            if (!SecureStore.hasKeys(this@MainActivity)) return "nokey"
            if (imgBusy) return "busy"
            val photo = pickedPhoto
            if (photo == null) { startImage(p, null); return "started" }
            runOnUiThread {
                try {
                    android.app.AlertDialog.Builder(this@MainActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Photo Google ko bhejein?")
                        .setMessage("Ye photo edit ke liye internet par Google Gemini ko bheji jayegi.")
                        .setPositiveButton("HAAN, BHEJO") { _, _ -> startImage(p, photo) }
                        .setNegativeButton("NAHI") { _, _ -> runJs("onImgCancel()") }
                        .setOnCancelListener { runJs("onImgCancel()") }
                        .show()
                } catch (e: Exception) {
                    runJs("onImgCancel()")
                }
            }
            return "asking"
        }

        /** The optional Groq key is only ever written here, never sent back to the page. ok / invalid / fail. */
        @JavascriptInterface
        fun saveGroqKey(raw: String): String = try {
            val k = raw.trim()
            if (k.length < 20 || k.length > 200 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveGroq(this@MainActivity, k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasGroqKey(): Boolean = SecureStore.hasGroq(this@MainActivity)

        /** Seconds NOVA waits after you stop speaking (2 to 10). */
        @JavascriptInterface
        fun getWaitSec(): Int = ExtCfg.waitSec(this@MainActivity)

        @JavascriptInterface
        fun setWaitSec(sec: Int): String { ExtCfg.setWaitSec(this@MainActivity, sec); return "ok" }

        @JavascriptInterface
        fun clearGroqKey() { SecureStore.clearGroq(this@MainActivity) }

        /** Optional OpenRouter key for the free AI chain. Written only here, never sent back to the page. ok / invalid / fail. */
        @JavascriptInterface
        fun saveOpenRouterKey(raw: String): String = try {
            val k = raw.trim()
            if (k.length < 20 || k.length > 200 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveSlot(this@MainActivity, "openrouter", k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasOpenRouterKey(): Boolean = SecureStore.hasSlot(this@MainActivity, "openrouter")

        @JavascriptInterface
        fun clearOpenRouterKey() { SecureStore.clearSlot(this@MainActivity, "openrouter") }

        /** Optional Z.ai (Zhipu GLM, free Flash models) key for the free AI chain. Written only here, never sent back. ok / invalid / fail. */
        @JavascriptInterface
        fun saveZaiKey(raw: String): String = try {
            val k = raw.trim()
            if (k.length < 20 || k.length > 200 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveSlot(this@MainActivity, "zai", k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasZaiKey(): Boolean = SecureStore.hasSlot(this@MainActivity, "zai")

        @JavascriptInterface
        fun clearZaiKey() { SecureStore.clearSlot(this@MainActivity, "zai") }

        /** v6.30: extra GLM keys (n = 2 or 3). When key 1's limit is used up, the chain tries key 2, then key 3. ok / invalid / fail. */
        @JavascriptInterface
        fun saveZaiKeyN(n: Int, raw: String): String = try {
            val k = raw.trim()
            if (n != 2 && n != 3) "fail"
            else if (k.length < 20 || k.length > 200 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveSlot(this@MainActivity, "zai$n", k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasZaiKeyN(n: Int): Boolean = (n == 2 || n == 3) && SecureStore.hasSlot(this@MainActivity, "zai$n")

        @JavascriptInterface
        fun clearZaiKeyN(n: Int) { if (n == 2 || n == 3) SecureStore.clearSlot(this@MainActivity, "zai$n") }

        @JavascriptInterface
        fun getFreeChain(): Boolean = ExtCfg.freeChain(this@MainActivity)

        @JavascriptInterface
        fun setFreeChain(on: Boolean): String { ExtCfg.setFreeChain(this@MainActivity, on); return "ok" }

        // PART 2 personal memory: the page only gets a COUNT, and the text only after the owner taps SHOW.
        @JavascriptInterface
        fun getMemoryCount(): Int = PersonalMemoryStore.count(this@MainActivity)

        @JavascriptInterface
        fun getMemoryText(): String = PersonalMemory.encode(PersonalMemoryStore.load(this@MainActivity))

        @JavascriptInterface
        fun clearMemory(): String = if (PersonalMemoryStore.clear(this@MainActivity)) "ok" else "fail"

        @JavascriptInterface
        fun getMemoryInChain(): Boolean = ExtCfg.memoryInChain(this@MainActivity)

        @JavascriptInterface
        fun setMemoryInChain(on: Boolean): String { ExtCfg.setMemoryInChain(this@MainActivity, on); return "ok" }

        /** GitHub token for publishing a website. Written only here, never sent back to the page. ok / invalid / fail. */
        @JavascriptInterface
        fun saveGithubToken(raw: String): String = try {
            val k = raw.trim()
            if (k.length < 20 || k.length > 255 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveSlot(this@MainActivity, GitHubPublish.SLOT, k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasGithubToken(): Boolean = SecureStore.hasSlot(this@MainActivity, GitHubPublish.SLOT)

        @JavascriptInterface
        fun clearGithubToken() { SecureStore.clearSlot(this@MainActivity, GitHubPublish.SLOT) }

        /** PUBLISH button in the chat. A native box asks first; nothing leaves the phone before HAAN. nosite / notoken / busy / asking. */
        @JavascriptInterface
        fun publishLastSite(): String {
            val html = NovaService.lastSiteHtml
            val subject = NovaService.lastSiteSubject
            if (html.isEmpty()) return "nosite"
            if (!SecureStore.hasSlot(this@MainActivity, GitHubPublish.SLOT)) return "notoken"
            if (pubBusy) return "busy"
            runOnUiThread {
                try {
                    android.app.AlertDialog.Builder(this@MainActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Website publish karein?")
                        .setMessage("Tumhare GitHub account mein ek nayi PUBLIC repo banegi aur website internet par sabko dikhegi. Baad mein repo GitHub se hata sakte ho.")
                        .setPositiveButton("HAAN") { _, _ -> startPublish(subject, html) }
                        .setNegativeButton("NAHI", null)
                        .show()
                } catch (e: Exception) {
                }
            }
            return "asking"
        }

        /** Opens only an HTTPS GitHub Pages hostname (not a URL that merely contains "github.io"). */
        @JavascriptInterface
        fun openPublished(url: String) {
            val uri = try { android.net.Uri.parse(url) } catch (e: Exception) { return }
            val host = uri.host?.lowercase() ?: return
            if (uri.scheme != "https" || uri.userInfo != null || (uri.port != -1 && uri.port != 443) ||
                host == "github.io" || !host.endsWith(".github.io")) return
            runOnUiThread {
                try {
                    startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, uri))
                } catch (e: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun getLearned(): String = LearnStore.listJson(this@MainActivity)

        @JavascriptInterface
        fun keepLearned(id: String): String = if (LearnStore.keep(this@MainActivity, id)) "ok" else "fail"

        @JavascriptInterface
        fun deleteLearned(id: String): String = if (LearnStore.delete(this@MainActivity, id)) "ok" else "fail"

        @JavascriptInterface
        fun clearLearned(): String { LearnStore.clear(this@MainActivity); return "ok" }

        @JavascriptInterface
        fun getAlerts(): Boolean = ExtCfg.alerts(this@MainActivity)

        @JavascriptInterface
        fun setAlerts(on: Boolean): String { ExtCfg.setAlerts(this@MainActivity, on); return "ok" }

        @JavascriptInterface
        fun getConvo(): Boolean = ExtCfg.convo(this@MainActivity)

        @JavascriptInterface
        fun setConvo(on: Boolean): String { ExtCfg.setConvo(this@MainActivity, on); return "ok" }

        @JavascriptInterface
        fun getAutoModels(): Boolean = ExtCfg.autoModels(this@MainActivity)

        @JavascriptInterface
        fun setAutoModels(on: Boolean): String { ExtCfg.setAutoModels(this@MainActivity, on); return "ok" }

        @JavascriptInterface
        fun voiceModelReady(): Boolean = VoiceLock.modelReady(this@MainActivity)

        @JavascriptInterface
        fun getAutoLearn(): Boolean = ExtCfg.autoLearn(this@MainActivity)

        @JavascriptInterface
        fun setAutoLearn(on: Boolean): String { ExtCfg.setAutoLearn(this@MainActivity, on); return "ok" }

        /** v6.37: the free AI order NOVA uses right now (best first). */
        @JavascriptInterface
        fun getAiOrder(): String = NovaService.instance?.aiOrderText() ?: ""

        @JavascriptInterface
        fun getNoiseCancel(): Boolean = ExtCfg.noiseCancel(this@MainActivity)

        @JavascriptInterface
        fun setNoiseCancel(on: Boolean): String {
            ExtCfg.setNoiseCancel(this@MainActivity, on)
            MicEffects.setEnabled(on)   // takes effect at once on the running mic
            return "ok"
        }

        @JavascriptInterface
        fun noiseCancelStatus(): String = try { MicEffects.status(ExtCfg.noiseCancel(this@MainActivity)) } catch (e: Throwable) { "?" }

        /** v6.35: which speaker engine is in use ("naya ResNet" / "purana Vosk"), for the Settings status line. */
        @JavascriptInterface
        fun voiceEngine(): String = try { VoiceLock.engineText(this@MainActivity) } catch (e: Throwable) { "purana Vosk" }

        @JavascriptInterface
        fun downloadVoiceModel(): String = ModelAuto.manualVoice(this@MainActivity)

        @JavascriptInterface
        fun brainEngineReady(): Boolean = LocalBrains.factory != null

        @JavascriptInterface
        fun getVoiceLock(): Boolean = ExtCfg.voiceLock(this@MainActivity) && VoiceLock.hasProfile(this@MainActivity)

        @JavascriptInterface
        fun getVoiceSilent(): Boolean = ExtCfg.voiceSilent(this@MainActivity)

        @JavascriptInterface
        fun setVoiceSilent(on: Boolean): String {
            ExtCfg.setVoiceSilent(this@MainActivity, on)
            return "ok"
        }

        @JavascriptInterface
        fun getVoiceLevel(): Int = ExtCfg.voiceLevel(this@MainActivity)

        @JavascriptInterface
        fun setVoiceLevel(level: Int): String {
            ExtCfg.setVoiceLevel(this@MainActivity, level)
            ExtCfg.setVoiceThreshold(this@MainActivity, 0.0)   // PART 5: choosing a level again drops the tuned limit
            return "ok"
        }

        @JavascriptInterface
        fun getVoiceLimitText(): String {
            val t = ExtCfg.voiceThreshold(this@MainActivity)
            val eng = VoiceLock.activeEngine(this@MainActivity)
            val used = VoiceLock.threshold(this@MainActivity, eng)
            val tuned = VoiceEngineRules.isTunedFor(eng, t, ExtCfg.voiceTunedEngine(this@MainActivity))
            return "%.2f".format(used) + if (tuned) " (tune kiya)" else " (default)"
        }

        @JavascriptInterface
        fun voiceTune(others: Boolean): String = NovaService.instance?.startVoiceTune(others) ?: "notrunning"

        // ---- Part 6A: background audio recording (Settings buttons). "notrunning" = NOVA is not ACTIVE.
        @JavascriptInterface
        fun recStart(): String = NovaService.instance?.recStartUi() ?: "notrunning"

        @JavascriptInterface
        fun recStop(): String = NovaService.instance?.recStopUi() ?: "notrunning"

        @JavascriptInterface
        fun recStatus(): String = NovaService.instance?.recStatusUi() ?: "off"

        // Part 6B: explicit visible UI start is required by Android's while-in-use camera permission policy.
        @JavascriptInterface
        fun videoStart(facing: String): String {
            if (facing !in setOf("front", "back")) return "invalid"
            if (RecordSession.active) return "audio_recording_active"
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread { requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), REQ_VIDEO) }
                return "permission_requested"
            }
            if (Build.VERSION.SDK_INT >= 34 && !NovaService.uiVisible) return "not_visible"
            return try {
                val i = Intent(this@MainActivity, VideoRecordService::class.java).setAction(VideoRecordService.ACTION_START).putExtra(VideoRecordService.EXTRA_FACING, facing)
                startForegroundService(i); "starting"
            } catch (e: Exception) { "start_failed:" + (e.message ?: e.javaClass.simpleName).take(60) }
        }

        @JavascriptInterface
        fun videoStop(): String = try {
            startService(Intent(this@MainActivity, VideoRecordService::class.java).setAction(VideoRecordService.ACTION_STOP)); "stopping"
        } catch (stopError: Exception) { "fail:" + stopError.javaClass.simpleName }

        @JavascriptInterface
        fun videoStatus(): String = JSONObject().put("busy", VideoRecordService.isBusy()).put("active", VideoRecordService.active)
            .put("status", VideoRecordService.lastStatus).put("file", VideoRecordService.lastFileName).toString()

        @JavascriptInterface
        fun getRecordings(): String = RecordingManager.listJson(this@MainActivity)

        @JavascriptInterface
        fun playRecording(id: String): String = RecordingManager.play(this@MainActivity, id)

        @JavascriptInterface
        fun shareRecording(id: String): String = RecordingManager.share(this@MainActivity, id)

        @JavascriptInterface
        fun deleteRecording(id: String): String {
            if (RecordingManager.list(this@MainActivity).none { it.id == id }) return "not_found"
            runOnUiThread {
                try {
                    android.app.AlertDialog.Builder(this@MainActivity, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                        .setTitle("Recording delete karein?")
                        .setMessage("${RecordingManager.list(this@MainActivity).firstOrNull { it.id == id }?.name ?: "Recording"} delete ho jayegi. Ye wapas nahi aayegi.")
                        .setPositiveButton("DELETE") { _, _ ->
                            val ok = RecordingManager.delete(this@MainActivity, id)
                            runJs("onRecordingsChanged(" + JSONObject.quote(if (ok) "deleted" else "delete_failed") + ")")
                        }
                        .setNegativeButton("CANCEL", null).show()
                } catch (_: Exception) { }
            }
            return "confirming"
        }

        @JavascriptInterface
        fun getAutoDeleteDays(): Int = RecordingManager.autoDeleteDays(this@MainActivity)

        @JavascriptInterface
        fun setAutoDeleteDays(days: Int): String {
            val r = RecordingManager.setAutoDeleteDays(this@MainActivity, days)
            runJs("onRecordingsChanged(" + JSONObject.quote(if (r == "ok") "updated" else r) + ")")
            return r
        }

        @JavascriptInterface
        fun recoverRecordings(): String {
            Thread { val r = RecordingManager.recover(this@MainActivity); runJs("onRecordingsChanged(" + JSONObject.quote(r) + ")") }.start()
            return "started"
        }

        @JavascriptInterface
        fun getProviderHealth(): String = NovaService.instance?.providerHealthJson() ?: "{\"active\":false,\"providers\":[]}"

        /** LIMITS screen: today's calls, limit and remaining per online service. No key is ever included. */
        @JavascriptInterface
        fun getApiUsage(): String = try { ApiUsage.snapshotJson(this@MainActivity) } catch (e: Exception) { "{\"rows\":[],\"totalToday\":0}" }

        /** Owner-chosen daily limit for one service (0 = back to default). Returns "ok" or "invalid". */
        @JavascriptInterface
        fun setApiLimit(id: String, n: Int): String = if (ApiUsage.setLimit(id, n)) "ok" else "invalid"

        /** Zeroes today's local counters only. */
        @JavascriptInterface
        fun resetApiUsage(): String { ApiUsage.resetToday(); return "ok" }

        @JavascriptInterface
        fun teachAdd(alias: String, value: String): String = TeachStore.add(this@MainActivity, alias, value)

        @JavascriptInterface
        fun teachDelete(alias: String): String = if (TeachStore.delete(this@MainActivity, alias)) "ok" else "not_found"

        @JavascriptInterface
        fun teachList(): String = TeachStore.listJson(this@MainActivity)

        @JavascriptInterface
        fun teachExport(): String {
            runOnUiThread { try { startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, "nova-learned-aliases.json"), REQ_EXPORT_TEACH) } catch (_: Exception) { runJs("onTeachBackup('export_fail')") } }
            return "started"
        }

        @JavascriptInterface
        fun teachImport(): String {
            runOnUiThread { try { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json"), REQ_IMPORT_TEACH) } catch (_: Exception) { runJs("onTeachBackup('import_fail')") } }
            return "started"
        }

        @JavascriptInterface
        fun getRoutines(): String = BrainStore.get(this@MainActivity).skillsJson()

        @JavascriptInterface
        fun saveRoutine(name: String, trigger: String, steps: String): String {
            val parsed = RoutineRules.parse(name, trigger, steps) ?: return "invalid"
            val sk = Skill("routine:" + parsed.name.take(32), listOf(parsed.trigger), parsed.steps, "routine")
            val e = BrainStore.get(this@MainActivity).addSkill(sk)
            return if (e == null) "ok" else "invalid:" + e
        }

        @JavascriptInterface
        fun deleteRoutine(name: String): String = if (BrainStore.get(this@MainActivity).removeSkill(name)) "ok" else "not_found"

        @JavascriptInterface
        fun faceMode(): String = when (FaceGate.mode(this@MainActivity)) {
            LockGate.Mode.WEAK -> "weak"
            LockGate.Mode.CREDENTIAL -> "credential"
            LockGate.Mode.NONE -> "none"
        }

        @JavascriptInterface
        fun getFaceGate(): Boolean = ExtCfg.faceGate(this@MainActivity)

        @JavascriptInterface
        fun setFaceGate(on: Boolean): String {
            if (on) {
                val voiceOk = VoiceLock.hasProfile(this@MainActivity) && ExtCfg.voiceLock(this@MainActivity)
                val err = LockGate.canEnable(voiceOk, FaceGate.mode(this@MainActivity))
                if (err != null) return err
            }
            ExtCfg.setFaceGate(this@MainActivity, on)
            return "ok"
        }

        /** Shows the system face / fingerprint screen once, so the owner can see it work. The answer comes back through onFaceTest(ok). */
        @JavascriptInterface
        fun faceTest(): String {
            val mode = FaceGate.mode(this@MainActivity)
            if (mode == LockGate.Mode.NONE) return "noface"
            Thread({
                val tok = FaceGateState.begin()
                FaceGate.launch(this@MainActivity, tok, mode)
                val ok = FaceGateState.await(tok, LockGate.FACE_WAIT_MS)
                FaceGate.dismissNotice(this@MainActivity)
                runJs("if(window.onFaceTest)onFaceTest(" + ok + ")")
            }, "nova-face-test").start()
            return "ok"
        }

        @JavascriptInterface
        fun hasVoiceProfile(): Boolean = VoiceLock.hasProfile(this@MainActivity)

        @JavascriptInterface
        fun setVoiceLock(on: Boolean): String {
            if (on && !VoiceLock.hasProfile(this@MainActivity)) return "noprofile"
            ExtCfg.setVoiceLock(this@MainActivity, on)
            return "ok"
        }

        @JavascriptInterface
        fun voiceEnroll(): String = NovaService.instance?.startVoiceEnroll() ?: "notrunning"

        @JavascriptInterface
        fun voiceDelete(): String {
            VoiceLock.deleteProfile(this@MainActivity)
            ExtCfg.setVoiceLock(this@MainActivity, false)
            ExtCfg.setVoiceThreshold(this@MainActivity, 0.0)   // PART 5: no voiceprint, no tuning, no face gate (it needs the voice)
            ExtCfg.setVoiceOwnDists(this@MainActivity, "")
            ExtCfg.setFaceGate(this@MainActivity, false)
            return "ok"
        }

        @JavascriptInterface
        fun getFreeKeyless(): Boolean = ExtCfg.freeKeyless(this@MainActivity)

        @JavascriptInterface
        fun setFreeKeyless(on: Boolean): String { ExtCfg.setFreeKeyless(this@MainActivity, on); return "ok" }

        // FIXFREE1: optional free image provider keys (together / hf). Written only here, never sent back to the page.
        @JavascriptInterface
        fun saveImgKey(slot: String, raw: String): String = try {
            val k = raw.trim()
            if (slot != "together" && slot != "hf") "invalid"
            else if (k.length < 10 || k.length > 300 || k.any { it.isWhitespace() }) "invalid"
            else if (SecureStore.saveSlot(this@MainActivity, slot, k)) "ok"
            else "fail"
        } catch (e: Exception) { "fail" }

        @JavascriptInterface
        fun hasImgKey(slot: String): Boolean = (slot == "together" || slot == "hf") && SecureStore.hasSlot(this@MainActivity, slot)

        @JavascriptInterface
        fun clearImgKey(slot: String) {
            if (slot == "together" || slot == "hf") SecureStore.clearSlot(this@MainActivity, slot)
        }

        @JavascriptInterface
        fun toggle(): String {
            if (NovaService.running) {
                cfg.active = false
                runOnUiThread { stopService(Intent(this@MainActivity, NovaService::class.java)) }
                return "stopped"
            }
            return startFlow(false)
        }

        /** READ_CONTACTS is requested here, on a user tap, and nowhere else. */
        @JavascriptInterface
        fun requestContacts(): String {
            if (granted(Manifest.permission.READ_CONTACTS)) return "granted"
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CONTACTS), REQ_CONTACTS) }
            return "asked"
        }

        /** Calendar permission is requested only from this explicit in-app button tap, never from voice. */
        @JavascriptInterface
        fun requestCalendarRead(): String {
            if (granted(Manifest.permission.READ_CALENDAR)) { CalendarRead.scheduleUpcoming(this@MainActivity); return "granted" }
            runOnUiThread { requestPermissions(arrayOf(Manifest.permission.READ_CALENDAR), REQ_CALENDAR) }
            return "asked"
        }

        /** Brightness control needs the special "Modify system settings" permission; the user opens it here. */
        @JavascriptInterface
        fun openWriteSettings() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    pushFlow("write_settings_failed")
                }
            }
        }

        /** The floating NOVA card needs "Display over other apps"; the user opens it here. */
        @JavascriptInterface
        fun openOverlaySettings() {
            runOnUiThread {
                try {
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                } catch (e: Exception) {
                    pushFlow("overlay_settings_failed")
                }
            }
        }

        // ---------------------------------------------------------------- Update Center (what is new / what is missing)

        /** One snapshot for the Update Center page: version + which permissions are on. Nothing is changed here. */
        @JavascriptInterface
        fun getStatus(): String {
            val vName = try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }
            return JSONObject()
                .put("versionName", vName)
                .put("versionCode", UpdateManager.appVersion(this@MainActivity))
                .put("mic", granted(Manifest.permission.RECORD_AUDIO))
                .put("notif", Build.VERSION.SDK_INT < 33 || granted(Manifest.permission.POST_NOTIFICATIONS))
                .put("overlay", Settings.canDrawOverlays(this@MainActivity))
                .put("acc", NovaAccessibilityService.isEnabled(this@MainActivity))
                .put("notifAccess", DrivingBridge.listenerEnabled(this@MainActivity))
                .put("installOk", packageManager.canRequestPackageInstalls())
                .put("assistant", isDefaultAssistant())
                .put("contacts", granted(Manifest.permission.READ_CONTACTS))
                .put("calendar", granted(Manifest.permission.READ_CALENDAR))
                .put("writeSettings", Settings.System.canWrite(this@MainActivity))
                .put("battery", (getSystemService(POWER_SERVICE) as? android.os.PowerManager)?.isIgnoringBatteryOptimizations(packageName) == true)
                .put("pattern", PatternUnlock.isSet(this@MainActivity))
                .put("feedUrl", cfg.feedUrl)
                .put("running", NovaService.running)
                .put("engine", LocalBrains.factory != null)
                .put("ramMb", totalRamMb())
                .put("ramOk", ModelCatalog.ramOk(totalRamMb()))
                .put("brainInstalled", UpdateManager.activeModelPath(this@MainActivity).isNotEmpty())
                .toString()
        }

        /** v6.30: real state of every feature for the home-page box (permissions, keys, service, last errors). Nothing is changed. */
        @JavascriptInterface
        fun getFeatureStatus(): String = try { FeatureStatus.json(this@MainActivity) } catch (e: Throwable) { "{\"items\":[]}" }

        private fun totalRamMb(): Long {
            val am = getSystemService(ACTIVITY_SERVICE) as? android.app.ActivityManager ?: return 0L
            val mi = android.app.ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            return mi.totalMem / (1024L * 1024L)
        }

        /** Puts the built-in offline model on the offer list (nothing is downloaded). "ok" or a short reason. */
        @JavascriptInterface
        fun offerOfflineBrain(): String = UpdateManager.offerOfflineBrain(this@MainActivity) ?: "ok"

        /** Asks Android to stop limiting NOVA's battery use (so the mic service is not killed). The user taps Allow. */
        @JavascriptInterface
        fun openBatterySettings() {
            runOnUiThread {
                val tries = listOf(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")),
                    Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS),
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
                for (i in tries) {
                    try { startActivity(i); return@runOnUiThread } catch (e: Exception) { }
                }
                pushFlow("update_msg:Open Settings > Apps > NOVA > Battery > No restrictions")
            }
        }

        /** Opens NOVA's own pattern-unlock screen (it no longer has its own launcher icon). */
        @JavascriptInterface
        fun openPatternSetup() {
            runOnUiThread {
                try { startActivity(Intent(this@MainActivity, PatternSetupActivity::class.java)) } catch (e: Exception) { }
            }
        }

        /** Opens Android's own "Default digital assistant app" choice. The user picks NOVA there; NOVA cannot set it by itself. */
        @JavascriptInterface
        fun openAssistantSettings() {
            runOnUiThread {
                val tries = listOf(
                    Intent(Settings.ACTION_VOICE_INPUT_SETTINGS),
                    Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
                    Intent(Settings.ACTION_SETTINGS)
                )
                for (i in tries) {
                    try { startActivity(i); return@runOnUiThread } catch (e: Exception) { }
                }
                pushFlow("update_msg:Settings could not be opened. Open Settings > Apps > Default apps > Digital assistant app")
            }
        }

        /** Asks Android for the microphone and notification permission (the user sees the normal Android dialog). */
        @JavascriptInterface
        fun requestBasics(): String {
            val ask = ArrayList<String>()
            if (!granted(Manifest.permission.RECORD_AUDIO)) ask.add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
                ask.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            if (ask.isEmpty()) return "ok"
            // Android stops showing the popup after two denials; then the button looked dead and the Update Center
            // seemed stuck. In that case open this app's settings page instead.
            val prefs = getSharedPreferences("nova_perm", android.content.Context.MODE_PRIVATE)
            val askedBefore = prefs.getBoolean("basics_asked", false)
            val blocked = askedBefore && ask.all { !shouldShowRequestPermissionRationale(it) }
            if (blocked) {
                runOnUiThread {
                    try {
                        val i = Intent(
                            android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                            android.net.Uri.parse("package:" + packageName)
                        )
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        startActivity(i)
                    } catch (e: Exception) {
                        pushFlow("basics_done")
                    }
                }
                return "settings"
            }
            prefs.edit().putBoolean("basics_asked", true).apply()
            runOnUiThread { requestPermissions(ask.toTypedArray(), REQ_BASIC) }
            return "asked"
        }

        /** Driving mode reads messages only after the user switches "Notification access" on for NOVA. */
        @JavascriptInterface
        fun openNotificationAccess() {
            runOnUiThread { DrivingBridge.openListenerSettings(this@MainActivity) }
        }

        // ---------------------------------------------------------------- updates (Discover -> Ask -> Add)

        /** "ok" or "bad" (the feed URL must be https). An empty URL turns update checks off. */
        @JavascriptInterface
        fun setFeedUrl(url: String): String {
            val u = url.trim()
            if (u.isEmpty()) { cfg.feedUrl = ""; return "ok" }
            if (!Updater.feedUrlOk(u)) return "bad"
            cfg.feedUrl = u
            return "ok"
        }

        @JavascriptInterface
        fun checkUpdates() {
            val url = cfg.feedUrl
            Thread {
                val e = if (url.isBlank()) "set the feed URL first" else UpdateManager.refresh(this@MainActivity, url)
                pushFlow(if (e == null) "updates_ok" else "updates_err:$e")
            }.start()
        }

        /** {"offers":[{id,type,title,sizeText,status}],"installed":{id:version}} */
        @JavascriptInterface
        fun getUpdates(): String {
            val arr = JSONArray()
            for (o in UpdateManager.offers(this@MainActivity)) {
                arr.put(
                    JSONObject().put("id", o.item.id).put("type", o.item.type).put("title", o.item.title)
                        .put("sizeText", Updater.sizeText(o.item.size)).put("status", o.status)
                )
            }
            return JSONObject().put("offers", arr)
                .put("installed", JSONObject(UpdateManager.installedJson(this@MainActivity))).toString()
        }

        /** Only the user's tap on INSTALL calls this. The download is verified (https, host list, SHA-256, size). */
        @JavascriptInterface
        fun installUpdate(id: String): String {
            UpdateManager.install(this@MainActivity, id) { ok, msg ->
                if (!ok || msg.isNotEmpty()) pushFlow("update_msg:$msg")
            }
            return "started"
        }

        @JavascriptInterface
        fun skipUpdate(id: String): String { UpdateManager.skip(this@MainActivity, id); return "ok" }

        @JavascriptInterface
        fun rollbackUpdate(id: String): String = UpdateManager.rollback(this@MainActivity, id)

        /** "Install unknown apps" for NOVA - needed once, only for installing a new NOVA version. */
        @JavascriptInterface
        fun openInstallSettings() {
            runOnUiThread {
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
                } catch (e: Exception) {
                    pushFlow("update_msg:Settings could not be opened. Use APP INFO > Install unknown apps")
                }
            }
        }

        /** {"skills":n,"events":n,"learned":n} - how much NOVA has learned on this phone. */
        @JavascriptInterface
        fun brainStats(): String = BrainStore.get(this@MainActivity).statsJson()

        /** Wipes all learned shortcuts and the local event log. */
        @JavascriptInterface
        fun brainClear(): String {
            BrainStore.get(this@MainActivity).clear()
            return "ok"
        }

        @JavascriptInterface
        fun getSettings(): String {
            val keyCount = SecureStore.getKeys(this@MainActivity).size
            val hasKey = SecureStore.hasKeys(this@MainActivity)
            return JSONObject()
                .put("wake", cfg.wake)
                .put("lang", cfg.lang)
                .put("rate", cfg.rate.toDouble())
                .put("pitch", cfg.pitch.toDouble())
                .put("model", cfg.model)
                .put("models", JSONArray(Logic.MODELS))
                .put("autostart", cfg.autostart)
                .put("hasKey", hasKey)
                .put("keyCount", keyCount)
                .put("hasGroq", SecureStore.hasGroq(this@MainActivity))
                .put("localMode", !hasKey)
                .put("acc", NovaAccessibilityService.isEnabled(this@MainActivity))
                .put("screenMonitor", cfg.screenMonitor)
                .put("contacts", granted(Manifest.permission.READ_CONTACTS))
                .put("calendar", granted(Manifest.permission.READ_CALENDAR))
                .put("writeSettings", Settings.System.canWrite(this@MainActivity))
                .put("overlay", Settings.canDrawOverlays(this@MainActivity))
                .put("feedUrl", cfg.feedUrl)
                .put("running", NovaService.running)
                .toString()
        }

        /** Returns ok, need_acc (everything saved but screen monitoring stayed OFF), bad_wake or error. */
        @JavascriptInterface
        fun saveSettings(json: String): String {
            return try {
                val o = JSONObject(json)
                val w = Logic.cleanWake(o.optString("wake"))
                if (w == null) {
                    "bad_wake"
                } else {
                    cfg.wake = w
                    cfg.lang = if (o.optString("lang") == "en") "en" else "hi"
                    cfg.rate = Logic.clampRate(o.optDouble("rate", 1.0).toFloat())
                    cfg.pitch = Logic.clampPitch(o.optDouble("pitch", 1.0).toFloat())
                    cfg.model = Logic.cleanModel(o.optString("model"))
                    cfg.autostart = o.optBoolean("autostart", true)
                    val wantMonitor = o.optBoolean("screenMonitor", false)
                    val accOn = NovaAccessibilityService.isEnabled(this@MainActivity)
                    val before = cfg.screenMonitor
                    cfg.screenMonitor = wantMonitor && accOn
                    if (before != cfg.screenMonitor) NovaAccessibilityService.monitorChanged()
                    NovaService.instance?.reloadVoice()
                    if (wantMonitor && !accOn) "need_acc" else "ok"
                }
            } catch (e: Exception) {
                "error"
            }
        }

        @JavascriptInterface
        fun testVoice() {
            runOnUiThread {
                val text = if (cfg.lang == "en") "Hello, I am Nova" else "नमस्ते, मैं नोवा हूँ"
                val svc = NovaService.instance
                if (svc != null) {
                    svc.speakTest(text)
                } else {
                    testTts?.shutdown()
                    var created: TextToSpeech? = null
                    created = TextToSpeech(this@MainActivity) { st ->
                        if (st == TextToSpeech.SUCCESS) {
                            cfg.applyVoice(created)
                            created?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "test")
                        }
                    }
                    testTts = created
                }
            }
        }

        @JavascriptInterface
        fun openAccessibility() {
            runOnUiThread { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        @JavascriptInterface
        fun openAppInfo() {
            runOnUiThread {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
    }

    private companion object {
        const val ASSET_URL = "file:///android_asset/ui.html"
        const val ASSET_PREFIX = "file:///android_asset/"
        const val REQ_SPEECH = 40
        const val REQ_START = 1
        const val REQ_CONTACTS = 2
        const val REQ_CALENDAR = 8
        const val REQ_BASIC = 3
        const val REQ_PICK = 4
        const val REQ_VIDEO = 5
        const val REQ_ALL = 9
        const val REQ_EXPORT_TEACH = 6
        const val REQ_IMPORT_TEACH = 7
    }
}
