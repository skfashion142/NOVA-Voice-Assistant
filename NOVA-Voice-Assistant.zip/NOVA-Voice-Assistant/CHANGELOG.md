# Changelog

Build/test status for every entry below v6.38 is "not compiled on Android, not phone-tested" unless stated.

## 6.45
- Build fix: force androidx.core/core-ktx to 1.13.1 (transitive 1.15.0 required compileSdk 35 and failed CI).

## 6.43
- Wake alarm: active only 06:00–12:00; rings repeatedly until OFF (DISMISS = 1 min snooze); 20‑minute auto-stop and unlock-stops-alarm removed.
- Docs reorganized: README, CHANGELOG, `docs/` (BUILD, ARCHITECTURE), history moved to `docs/archive/`.

## 6.42
- Fix `ChatText` JSON field regex (over-matched past closing quote).
- Fix `WhatsAppCommandRules` recipient casing.
- Verified with kotlinc: 55 pure-Kotlin files, 521 JUnit tests pass.

## 6.41
- Morning greeting + today's jobs, 25‑minute lead alarms, wake alarm (WakeRules).
- Tests: BatteryRulesTest, ScheduledDaysTest, WakeRulesTest.

## 6.40
- Schedule: weekdays bitmask, priority, note; voice commands and *MERA SCHEDULE* UI.

## 6.39
- Battery alerts (50/40/30/20/10 %) and ≤5 % WhatsApp SOS to Papa/Mummy.

## 6.38
- No auto-start (BootReceiver only restores reminders). Owner-only voice lock; locked-phone voice unlock via pattern.

Older history: [docs/PROGRESS.md](docs/PROGRESS.md) and [docs/archive/](docs/archive/).
