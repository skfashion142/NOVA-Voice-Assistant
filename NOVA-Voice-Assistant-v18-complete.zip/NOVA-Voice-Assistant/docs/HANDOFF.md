# NOVA v6.41 - next account prompt

Tum NOVA (Android voice assistant, Kotlin, package com.nova.assistant) ke code par kaam kar rahe ho. Owner Hinglish me baat karta hai. Chhote steps me kaam karo, har step ke baad updated ZIP do.

## BUILD HONESTY (zaroori)
Is session me Gradle/Android build NAHI chala (Maven/Google servers blocked). Neeche ke sab changes sirf likhe gaye + brace-balance check hue, COMPILE NAHI hue, phone par test NAHI hue, aur unit tests CHALAYE NAHI gaye. Pehle `Build and Test APK` workflow (GitHub Actions) chalao ya local gradle chalao, errors theek karo, tab "kaam karta hai" kaho.
Agar build possible nahi: kotlinc 1.9.24 GitHub releases se mil jata hai; ~55 pure-Kotlin files (jinme android import nahi) + org.json aur Context ke chhote shim ke saath compile karke tests chala sakte ho. Android.jar aur Maven blocked the.

## Is session me kiya (v6.38 -> v6.41), sab owner ke kehne par
1. NO AUTO-START: BootReceiver ab sirf reminders dobara set karta hai (cfg.active=false). Koi notification nahi. MainActivity app khulne par service start nahi karta; handleIntent kuch start nahi karta. Cfg.autostart hamesha false. NovaService start-fail notification hata di. Service sirf ACTIVATE tap se chalti hai.
2. OWNER-ONLY VOICE: ExtCfg.voiceLock() hamesha true, lockOptIn true, faceGate() hamesha false. Awaaz profile na ho to refuse. Anjaan awaaz par refuseNotOwner(): ek saaf bolkar mana (8 s me max ek baar), koi command/AI/cloud call nahi.
3. LOCKED PHONE: faceAllows() ab face/fingerprint nahi maangta. Voice match hone par ownerUnlock() (PatternUnlock + Accessibility) se khud unlock, phir task, koi confirmation nahi. Sirf pattern lock; PIN/biometric nahi khol sakta. Unlock fail ho to chat me batata hai aur task phir bhi try.
4. BATTERY (BatteryRules.kt + batteryWatchRx in NovaService): 50/40/30/20/10% se neeche ek-ek baar alert (charging me nahi). <=5% par Papa aur Mummy ko WhatsApp (sendBatterySos, contacts "Papa"/"Mummy" ya aliases BatteryRules.PAPA/MUMMY), accessibility se send, ek baar per discharge; fail par agle 1% par retry.
5. SCHEDULE: ScheduledTaskRules.Spec me days (bitmask Mon=1..Sun=64), prio (0/1/2), note (120 chars). Encode 11 fields, decode 8/9/11. Voice: "somvar mangalvar subah 7 baje gym yaad dilao bahut zaruri kyunki ..." ; "schedule zaruri|bahut zaruri|normal <label>", "schedule note <label> <text>". Store.update(). UI box "MERA SCHEDULE" + Bridge getSchedules/addSchedule/setSchedulePrio/cancelSchedule.
6. MORNING (WakeRules.kt + NovaService): USER_PRESENT par 06:00-11:59 me din ka pehla unlock = rotating Good-morning greeting + aaj ke kaam (time order, zarurat ke saath); isse owner "awake" mark hota hai. Har REMINDER ke liye 25 min pehle ka lead alarm (ScheduledTaskStore.ACTION_LEAD -> ScheduledTaskReceiver -> NovaService.onLeadTime). Wake alarm (looping alarm ringtone + notification OFF/DISMISS, WakeAlarmReceiver) sirf jab: task time 06:00-11:59, clock 05:30-11:59, aur owner abhi awake nahi. OFF = us din ke liye band; DISMISS = 1 min baad phir; 20 min after due par khud band; 12:00 ke baad kabhi nahi. Awake ke baad sirf normal reminders. Owner ne "12 am" likha tha; maine 12 baje dopahar maana (WakeRules.NOON) - owner se confirm karo.
7. Tests likhe (chalaye nahi): BatteryRulesTest, ScheduledDaysTest, WakeRulesTest.

## Pehle ye karo
- Compile errors theek karo (khaas: NovaService naye blocks, MainActivity Bridge, ScheduledTask*). Phir `./gradlew testDebugUnitTest` (CI).
- Check: koi purana test BootReceiver.showTapToStart / Cfg.autostart / ExtCfg.faceGate/voiceLock opt-in / LockGate flow par depend karta ho to update karo (SafetyInvariantsTest, VoiceFaceRulesTest dekho).
- ui.html ko `node --check` har <script> par (x-shader wala JS nahi hai).
- Owner ki purani invariants: dangerous actions par local spoken yes (skipRiskyConfirm owner ne ON rakha hai), screen monitoring default OFF, QUERY_ALL_PACKAGES/CALL_PHONE nahi.

## Baaki / upgrade ideas (owner ne "full check + missing features + upgrade" maanga tha; wo audit POORA NAHI hua)
- Poora feature audit: har feature ka code path padho, kaam na kare to fix, missing ho to banao.
- Battery SOS: background se WhatsApp kholne ke liye overlay permission zaroori; phone par test karo. Locked/screen-off me fail ho sakta hai.
- Wake alarm: mic alarm sunta hai (false wake/awaaz dismiss mushkil) - buttons primary hain; USAGE_ALARM stream volume check karo.
- Voice match record-replay se dhoka kha sakta hai (owner ne face check hata diya; usse bataya ja chuka hai). Voice test (AWAAZ TEST) se limit set karwao.
- Settings UI me purane "sirf meri awaaz"/face lock/restart-notification controls ab behavior badalte nahi; unhe hata ya "hamesha ON" likho.
- README_NOVA_V6.md / PROGRESS.md me v6.39-v6.41 add karo.

## Rules
- Hinglish me chhota jawab. Har step ke baad ZIP. Build/test ka sach batao (RUN / NOT RUN).
