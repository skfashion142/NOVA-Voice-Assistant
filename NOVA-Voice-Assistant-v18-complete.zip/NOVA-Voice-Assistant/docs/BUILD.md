# Build & test

## CI (recommended)
Workflow `.github/workflows/build.yml` ("NOVA Android CI") runs on every push/PR: JDK 17, Android SDK 34, Gradle 8.7, then
`gradle --no-daemon testDebugUnitTest assembleDebug`.

> **Known gap:** the current workflow does not download the Vosk model. The APK needs
> `vosk-model-small-en-us-0.15` extracted to `app/src/main/assets/model-en/` (not in the repo, ~40 MB). Add it before installing, or extend the workflow with a download step and a check for `graph/words.txt` and `am/final.mdl`.

## Local
```
gradle testDebugUnitTest assembleDebug     # needs Android SDK 34
node --check <each <script> of app/src/main/assets/ui.html>
python3 -m unittest discover tools          # contract tests (if applicable)
```

## Pure-Kotlin check without Android (what was run for v6.42)
Compile the main files that have no `android`/`org.json` imports plus the matching tests with `kotlinc` 1.9.24 and JUnit 4.13.2, with tiny stubs for `MessageMode` and `ApiUsage`; run `org.junit.runner.JUnitCore` from `app/` (some tests read `src/main/assets/knowledge.json`).
Result for v6.42: 521 tests, 0 failures. This does **not** cover `NovaService`, `MainActivity` or any Android API usage.

## Signing, releases, self-improve
See [SETUP_STEPS.md](SETUP_STEPS.md). Note: that guide mentions extra workflows (signing key, release, self-improve) that are **not present** in this ZIP's `.github/workflows/`.
