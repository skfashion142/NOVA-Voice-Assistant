# NOVA v18 - kya naya hai (evidence level: likha gaya + static check, COMPILE NAHI hua, phone test baaki)

1. Popup card: keyboard button -> likhne ka box (NovaHudInput). Text NovaService.typed() se jaata hai.
2. Settings > "SIRF NOVA" (default ON): sirf "nova" wake word, baat-cheet mode forced OFF. Badalne ke baad ACTIVATE dobara.
3. NOVA Browser (NovaBrowserActivity): "nova wikipedia par taj mahal dhundo", "google par iphone price search karo". Sirf http/https.
4. Phone switches: wifi, bluetooth, airplane*, hotspot*, location, dnd, rotation, nfc, battery saver, dark mode, mobile data,
   phone silent/vibrate/normal, screen timeout. (*spoken yes zaroori). Direct API jahan permission ho, warna Quick Settings tile (Accessibility).
5. Ghuma ke bolna: "<app> kholo aur <kaam>" ka agent ab zyada joiners samajhta hai aur sawaal ka jawab screen se padhkar bolta hai.
   AI (Gemini/free providers) ko naye tools mile: toggle_setting, browse_in_app.

## Phone par test (ek ek karke)
- Popup: nova bolo -> card ke keyboard button dabao -> "battery kitni hai" likho -> Bhejo.
- "nova wifi off karo", "nova bluetooth on karo", "nova do not disturb on karo", "nova phone vibrate karo", "nova screen timeout 30 seconds".
- "nova wikipedia par taj mahal dhundo" -> NOVA browser khulna chahiye.
- "nova whatsapp open karo aur mere <group> group mein dekho last post kab hui" (Accessibility ON chahiye).

## Seemayein (sach)
- WiFi/Bluetooth/airplane/hotspot/location/NFC/mobile data Android seedha band-chalu karne nahi deta: tile ka naam/page phone par alag ho to "tile nahi mila" aayega.
- Chrome app NOVA ke andar nahi khul sakta; uski jagah NOVA ka apna browser hai.
- Unit tests naye: BrowserRulesTest, SettingRulesTest, NovaOnlyTest; LogicTest ke 3 wifi/bluetooth expectations jaan-boojh kar badle.
