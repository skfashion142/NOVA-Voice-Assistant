package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceEngineRulesTest {
    @Test fun deviceRule() {
        assertTrue(VoiceEngineRules.deviceOk(4096, 8))
        assertTrue(VoiceEngineRules.deviceOk(3500, 4))
        assertFalse(VoiceEngineRules.deviceOk(3499, 8))
        assertFalse(VoiceEngineRules.deviceOk(8192, 3))
        assertFalse(VoiceEngineRules.deviceOk(0, 0))
    }

    @Test fun engineChoice() {
        assertEquals("onnx", VoiceEngineRules.pickEngine(true, true))
        assertEquals("vosk", VoiceEngineRules.pickEngine(true, false))
        assertEquals("vosk", VoiceEngineRules.pickEngine(false, true))
        assertEquals("vosk", VoiceEngineRules.pickEngine(false, false))
    }

    @Test fun voskKeepsOldLevels() {
        assertEquals(0.4, VoiceEngineRules.levelThreshold("vosk", 0), 0.0)
        assertEquals(0.5, VoiceEngineRules.levelThreshold("vosk", 1), 0.0)
        assertEquals(0.6, VoiceEngineRules.levelThreshold("vosk", 2), 0.0)
    }

    @Test fun onnxLevels() {
        assertEquals(0.45, VoiceEngineRules.levelThreshold("onnx", 0), 0.0)
        assertEquals(0.55, VoiceEngineRules.levelThreshold("onnx", 1), 0.0)
        assertEquals(0.65, VoiceEngineRules.levelThreshold("onnx", 2), 0.0)
        assertEquals(0.45, VoiceEngineRules.levelThreshold("onnx", 99), 0.0)
    }

    @Test fun tunedLimitOnlyForSameEngine() {
        // old app version saved a tuned value without an engine name = Vosk
        assertEquals(0.33, VoiceEngineRules.effectiveThreshold("vosk", 0, 0.33, ""), 0.0)
        assertEquals(0.45, VoiceEngineRules.effectiveThreshold("onnx", 0, 0.33, ""), 0.0)
        assertEquals(0.33, VoiceEngineRules.effectiveThreshold("onnx", 0, 0.33, "onnx"), 0.0)
        assertEquals(0.4, VoiceEngineRules.effectiveThreshold("vosk", 0, 0.33, "onnx"), 0.0)
        // not tuned / out of range -> level
        assertEquals(0.4, VoiceEngineRules.effectiveThreshold("vosk", 0, 0.0, ""), 0.0)
        assertEquals(0.55, VoiceEngineRules.effectiveThreshold("onnx", 1, 0.9, "onnx"), 0.0)
        assertEquals(0.45, VoiceEngineRules.effectiveThreshold("onnx", 0, Double.NaN, "onnx"), 0.0)
    }

    @Test fun tunedFlag() {
        assertTrue(VoiceEngineRules.isTunedFor("vosk", 0.3, ""))
        assertFalse(VoiceEngineRules.isTunedFor("onnx", 0.3, ""))
        assertFalse(VoiceEngineRules.isTunedFor("vosk", 0.0, ""))
    }

    @Test fun engineTextWording() {
        assertEquals("naya ResNet", VoiceEngineRules.engineText("onnx", true, true, true))
        assertEquals("purana Vosk", VoiceEngineRules.engineText("vosk", false, false, false))
        assertTrue(VoiceEngineRules.engineText("vosk", true, false, true).contains("AWAAZ HATAO"))
        assertEquals("purana Vosk", VoiceEngineRules.engineText("vosk", true, false, false))
    }

    // ---- profile JSON
    @Test fun oldProfileWithOnlyVStillLoads() {
        val p = VoiceProfileCodec.decode("{\"v\":[0.5,-1.25,3.0]}")
        assertNotNull(p)
        assertEquals(3, p!!.v.size)
        assertEquals(-1.25, p.v[1], 0.0)
        assertNull(p.v2)
    }

    @Test fun roundTripWithBothPrints() {
        val v = doubleArrayOf(0.1, 0.2, 0.3, 0.4)
        val v2 = DoubleArray(256) { (it % 7) - 3.0 + 0.5 }
        val text = VoiceProfileCodec.encode(v, v2)
        assertNotNull(text)
        val p = VoiceProfileCodec.decode(text!!)
        assertNotNull(p)
        assertEquals(4, p!!.v.size)
        assertEquals(0.3, p.v[2], 0.0)
        assertEquals(256, p.v2!!.size)
        assertEquals(v2[100], p.v2!![100], 0.0)
    }

    @Test fun v2IsNotMistakenForV() {
        val p = VoiceProfileCodec.decode("{\"v2\":[1.0,2.0,3.0]}")
        assertNull(p)
    }

    @Test fun badInputIsRefused() {
        assertNull(VoiceProfileCodec.encode(doubleArrayOf(1.0, 2.0), null))                    // too short
        assertNull(VoiceProfileCodec.encode(doubleArrayOf(0.0, 0.0, 0.0), null))               // all zero
        assertNull(VoiceProfileCodec.encode(doubleArrayOf(1.0, Double.NaN, 2.0), null))        // NaN
        assertNull(VoiceProfileCodec.decode(""))
        assertNull(VoiceProfileCodec.decode("{\"v\":[]}"))
        assertNull(VoiceProfileCodec.decode("{\"v\":[1.0,abc,3.0]}"))
        assertNull(VoiceProfileCodec.decode("garbage"))
    }

    @Test fun badV2IsDroppedButVStays() {
        val text = VoiceProfileCodec.encode(doubleArrayOf(1.0, 2.0, 3.0), doubleArrayOf(0.0, 0.0, 0.0))
        assertNotNull(text)
        assertNull(VoiceProfileCodec.decode(text!!)!!.v2)
        val p = VoiceProfileCodec.decode("{\"v\":[1.0,2.0,3.0],\"v2\":[1.0,xx]}")
        assertNotNull(p)
        assertNull(p!!.v2)
    }
}
