package com.nova.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceSetupSafetyTest {
    @Test fun profileVectorMustBeNonEmptyAndNonZero() {
        assertFalse(DoubleArray(0).size >= 3)
        assertTrue(doubleArrayOf(1.0, 0.0, 0.0).any { it != 0.0 })
    }

    @Test fun strictThresholdIsLowerThanLoose() {
        assertTrue(SpeakerRules.thresholdFor(0) < SpeakerRules.thresholdFor(2))
    }
}
