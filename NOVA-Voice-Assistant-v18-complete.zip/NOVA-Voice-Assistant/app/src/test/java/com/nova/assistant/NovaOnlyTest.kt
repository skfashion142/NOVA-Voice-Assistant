package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

/** v18 "Sirf Nova": the strict wake counters stay as they were, only the word "nova" is the wake word. */
class NovaOnlyTest {
    @Test fun defaultWakeIsNova() {
        assertEquals("nova", Logic.DEFAULT_WAKE)
    }

    @Test fun glitchNeverWakes() {
        assertFalse(Logic.wakeConfirmed(Logic.nextWakeHits(1, false), false))
    }

    @Test fun otherWordIsNotNova() {
        assertFalse(Logic.heardWake("{\"text\":\"computer\"}", "nova"))
    }
}
