package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FbankTest {
    @Test fun frameCountSnipsEdges() {
        assertEquals(0, Fbank.frameCount(0))
        assertEquals(0, Fbank.frameCount(399))
        assertEquals(1, Fbank.frameCount(400))
        assertEquals(1, Fbank.frameCount(559))
        assertEquals(2, Fbank.frameCount(560))
        assertEquals(98, Fbank.frameCount(16000))
    }

    @Test fun tooShortAudioGivesNull() {
        assertNull(Fbank.compute(DoubleArray(399)))
    }

    @Test fun outputShapeIsFramesTimes80() {
        val f = Fbank.compute(DoubleArray(16000) { Math.sin(it * 0.05) * 1000.0 })
        assertNotNull(f)
        assertEquals(98 * Fbank.MELS, f!!.size)
        assertTrue(f.all { it.isFinite() })
    }

    @Test fun constantSignalBecomesAllZeroAfterMeanNormalisation() {
        val f = Fbank.compute(DoubleArray(8000) { 1234.0 })
        assertNotNull(f)
        assertTrue(f!!.all { Math.abs(it) < 1e-6f })
    }

    @Test fun meanOfEveryBinIsZero() {
        val f = Fbank.compute(DoubleArray(16000) { Math.sin(it * 0.3) * 800.0 + Math.sin(it * 0.011) * 3000.0 })!!
        val t = f.size / Fbank.MELS
        for (b in 0 until Fbank.MELS) {
            var m = 0.0
            for (i in 0 until t) m += f[i * Fbank.MELS + b]
            assertEquals(0.0, m / t, 1e-3)
        }
    }

    @Test fun pcmConversionIsSignedLittleEndian() {
        val s = Fbank.pcmToSamples(byteArrayOf(0x01, 0x00, 0xFF.toByte(), 0xFF.toByte(), 0x00, 0x80.toByte()))
        assertEquals(3, s.size)
        assertEquals(1.0, s[0], 0.0)
        assertEquals(-1.0, s[1], 0.0)
        assertEquals(-32768.0, s[2], 0.0)
    }

    @Test fun pcmConversionHonoursTheCap() {
        assertEquals(10, Fbank.pcmToSamples(ByteArray(100), 10).size)
    }

    @Test fun deviceRuleDelegatesToTheSameNumbers() {
        // OnnxSpeaker.deviceOk is a thin wrapper around VoiceEngineRules.deviceOk; the rule itself is tested there
        assertTrue(VoiceEngineRules.deviceOk(OnnxSpeakerLimits.MIN_RAM_MB, OnnxSpeakerLimits.MIN_CORES))
    }
}

/** Mirror of the two limits in OnnxSpeaker (kept here so the test does not load the ONNX classes on a plain JVM). */
private object OnnxSpeakerLimits { const val MIN_RAM_MB = 3500L; const val MIN_CORES = 4 }
