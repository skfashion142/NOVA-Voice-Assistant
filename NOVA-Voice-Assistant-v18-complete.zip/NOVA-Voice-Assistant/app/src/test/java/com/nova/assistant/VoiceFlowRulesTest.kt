package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceFlowRulesTest {
    private val chunk = 100
    private val lim = CaptureRules.SILENCE_MS / chunk   // v6.36: 18 chunks of silence end a command (was 30)

    /** Feeds a pattern of chunks ("s" = speech, "." = silence); returns total ms when the capture ends, or -1. */
    private fun run(pattern: String, maxMs: Int = CaptureRules.MAX_MS): Int {
        var heard = false; var silent = 0; var total = 0
        for (c in pattern) {
            total += chunk
            val speaking = c == 's'
            if (speaking) heard = true
            silent = CaptureRules.nextSilentMs(silent, heard, speaking, chunk)
            if (CaptureRules.shouldEnd(heard, silent, total, CaptureRules.SILENCE_MS, maxMs, 8000)) return total
        }
        return -1
    }

    @Test fun continuousSpeechNeverEnds() = assertEquals(-1, run("s".repeat(300)))

    @Test fun pauseUnderTheLimitKeepsOneCommand() =
        assertEquals(-1, run("s".repeat(10) + ".".repeat(lim - 1) + "s".repeat(10)))   // 1 s speech, pause just under the limit, speech again

    @Test fun speechResumeResetsTimer() {
        val end = run("s".repeat(10) + ".".repeat(lim - 3) + "s" + ".".repeat(lim))
        assertEquals((10 + (lim - 3) + 1 + lim) * chunk, end)   // counted from the LAST speech chunk
    }

    @Test fun exactlyTheLimitEnds() = assertEquals((10 + lim) * chunk, run("s".repeat(10) + ".".repeat(lim)))

    @Test fun justUnderTheLimitDoesNotEnd() = assertEquals(-1, run("s".repeat(10) + ".".repeat(lim - 1)))

    @Test fun silenceBeforeSpeechDoesNotCountAsEndSilence() {
        var silent = 0
        repeat(40) { silent = CaptureRules.nextSilentMs(silent, false, false, chunk) }
        assertEquals(0, silent)
    }

    @Test fun sixtySecondEmergencyCap() = assertEquals(CaptureRules.MAX_MS, run("s".repeat(700)))

    @Test fun capIsOnlyEmergencyNotNormalStop() = assertTrue(run("s".repeat(10) + ".".repeat(lim)) < CaptureRules.MAX_MS)

    @Test fun constantsMatchLogic() {
        assertEquals(Logic.END_SILENCE_MS, CaptureRules.SILENCE_MS)
        assertEquals(Logic.MAX_COMMAND_MS, CaptureRules.MAX_MS)
    }

    // ---- enrollment
    @Test fun enrollmentStopsAfterFiveOfFive() {
        val g = EnrollGuard(5)
        val id = g.tryBegin(); assertTrue(id > 0); assertTrue(g.activate(id))
        repeat(4) { assertEquals(EnrollGuard.Sample.MORE, g.sample()) }
        assertEquals(EnrollGuard.Sample.DONE, g.sample())
        assertFalse(g.active())
        assertEquals(EnrollGuard.State.IDLE, g.state())
    }

    @Test fun noAutomaticRestartAfterDone() {
        val g = EnrollGuard(5)
        val id = g.tryBegin(); g.activate(id)
        repeat(5) { g.sample() }
        assertEquals(EnrollGuard.Sample.IGNORED, g.sample())   // a stray 6th callback does nothing
        assertFalse(g.activate(id))                            // a stale thread cannot re-activate the old session
    }

    @Test fun secondStartWhileRunningIsRefused() {
        val g = EnrollGuard(5)
        assertTrue(g.tryBegin() > 0)
        assertEquals(-1, g.tryBegin())
    }

    @Test fun newSessionNeedsExplicitBeginAndStartsAtZero() {
        val g = EnrollGuard(5)
        val a = g.tryBegin(); g.activate(a); repeat(5) { g.sample() }
        val b = g.tryBegin()
        assertTrue(b > a); assertEquals(0, g.count())
    }

    @Test fun cancelInvalidatesStaleStart() {
        val g = EnrollGuard(5)
        val id = g.tryBegin()
        g.cancel()
        assertFalse(g.activate(id))
        assertFalse(g.active())
    }

    // ---- battery warning
    @Test fun batteryWarningDeferredDuringVoiceWork() {
        assertFalse(AlertGate.maySpeak(false, false, false, false, enrolling = true, tuning = false))
        assertFalse(AlertGate.maySpeak(false, true, false, false, false, false))    // command recording
        assertFalse(AlertGate.maySpeak(true, false, false, false, false, false))    // thinking / auth
        assertFalse(AlertGate.maySpeak(false, false, true, false, false, false))
        assertFalse(AlertGate.maySpeak(false, false, false, true, false, false))
        assertFalse(AlertGate.maySpeak(false, false, false, false, false, tuning = true))
    }

    @Test fun batteryWarningSpeaksWhenIdle() =
        assertTrue(AlertGate.maySpeak(false, false, false, false, false, false))
}
