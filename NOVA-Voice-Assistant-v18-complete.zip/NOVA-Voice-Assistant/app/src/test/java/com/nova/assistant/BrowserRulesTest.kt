package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v18: in-app browser rules. Pure rules only. */
class BrowserRulesTest {
    @Test fun wikipediaSearch() {
        assertEquals("https://en.wikipedia.org/w/index.php?search=taj+mahal", BrowserRules.parse("nova wikipedia par taj mahal dhundo"))
        assertEquals("https://en.wikipedia.org/w/index.php?search=python", BrowserRules.parse("nova app ke andar wikipedia par python dikhao"))
    }

    @Test fun googleSearch() {
        assertEquals("https://www.google.com/search?q=iphone+price", BrowserRules.parse("google par iphone price search karo"))
    }

    @Test fun notStolen() {
        assertNull(BrowserRules.parse("chrome kholo"))                                    // plain open_app
        assertNull(BrowserRules.parse("whatsapp open karo aur group search karo"))       // other apps keep their own path
        assertNull(BrowserRules.parse("wikipedia par taj mahal ke baare mein batao"))    // a question: NOVA answers aloud
        assertNull(BrowserRules.parse("google par kya hai python search karo"))
        assertNull(BrowserRules.parse("google par python search mat karo"))
    }

    @Test fun classifyUsesIt() {
        assertEquals(Logic.Cmd("browse", "https://en.wikipedia.org/w/index.php?search=taj+mahal"), Logic.classify("wikipedia par taj mahal dhundo"))
    }

    @Test fun onlyWebPagesLoad() {
        assertTrue(BrowserRules.safeUrl("https://example.com/a"))
        assertTrue(BrowserRules.safeUrl("http://example.com"))
        assertFalse(BrowserRules.safeUrl("javascript:alert(1)"))
        assertFalse(BrowserRules.safeUrl("intent://scan/#Intent;end"))
        assertFalse(BrowserRules.safeUrl("file:///sdcard/a.html"))
    }

    @Test fun addressBar() {
        assertEquals("https://wikipedia.org", BrowserRules.fromAddressBar("wikipedia.org"))
        assertEquals("https://x.com/a", BrowserRules.fromAddressBar("https://x.com/a"))
        assertEquals("https://www.google.com/search?q=hello+world", BrowserRules.fromAddressBar("hello world"))
        assertNull(BrowserRules.fromAddressBar("   "))
    }
}
