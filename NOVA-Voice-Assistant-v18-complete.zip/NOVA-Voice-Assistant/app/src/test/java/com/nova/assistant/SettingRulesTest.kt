package com.nova.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v18: phone switches by voice. Pure rules only. */
class SettingRulesTest {
    private fun cmd(kind: String, arg: String = "", num: Int = 0) = Logic.Cmd(kind, arg, num)

    @Test fun switches() {
        assertEquals(cmd("toggle", "wifi:on"), SettingRules.parse("wifi on"))
        assertEquals(cmd("toggle", "bluetooth:off"), SettingRules.parse("bluetooth band karo"))
        assertEquals(cmd("toggle", "dnd:on"), SettingRules.parse("do not disturb on karo"))
        assertEquals(cmd("toggle", "airplane:on"), SettingRules.parse("flight mode on"))
        assertEquals(cmd("toggle", "rotation:off"), SettingRules.parse("auto rotate off karo"))
        assertEquals(cmd("toggle", "batterysaver:on"), SettingRules.parse("battery saver chalu karo"))
        assertEquals(cmd("toggle", "dark:on"), SettingRules.parse("dark mode on"))
        assertEquals(cmd("toggle", "mobiledata:off"), SettingRules.parse("mobile data band karo"))
    }

    @Test fun ringerAndTimeout() {
        assertEquals(cmd("ringer", "silent"), SettingRules.parse("phone silent karo"))
        assertEquals(cmd("ringer", "vibrate"), SettingRules.parse("ringer vibrate"))
        assertEquals(cmd("timeout", "", 30), SettingRules.parse("screen timeout 30 seconds"))
        assertEquals(cmd("timeout", "", 120), SettingRules.parse("screen timeout 2 minutes"))
        assertNull(SettingRules.parse("screen timeout 5 seconds"))
    }

    @Test fun unclearIsNull() {
        assertNull(SettingRules.parse("open wifi settings"))          // a settings PAGE keeps opening
        assertNull(SettingRules.parse("wifi"))
        assertNull(SettingRules.parse("wifi on bluetooth off"))      // both on and off words
        assertNull(SettingRules.parse("wifi aur bluetooth on karo")) // two different switches
        assertNull(SettingRules.parse("wifi mat chalu karo"))        // negation
        assertNull(SettingRules.parse("silent replies on"))          // NOVA's own quiet mode
    }

    @Test fun classifyKeepsPagesAndAddsSwitches() {
        assertEquals(cmd("toggle", "wifi:on"), Logic.classify("wifi on"))
        assertEquals(cmd("settings", "wifi"), Logic.classify("open wifi settings"))
    }

    @Test fun confirmAndLabels() {
        assertTrue(SettingRules.needsConfirm("airplane"))
        assertTrue(SettingRules.needsConfirm("hotspot"))
        assertFalse(SettingRules.needsConfirm("wifi"))
        assertTrue("internet" in SettingRules.tileLabels("wifi"))
        for (n in SettingRules.NAMES) assertTrue(n, SettingRules.tileLabels(n).isNotEmpty())
    }

    @Test fun freeProviderAllowList() {
        val ok = PhoneActionRules.parse("{\"tool\":\"toggle_setting\",\"args\":{\"name\":\"wifi\",\"state\":\"on\"}}")
        assertEquals("toggle_setting", ok?.tool)
        assertNull(PhoneActionRules.parse("{\"tool\":\"toggle_setting\",\"args\":{\"name\":\"password\",\"state\":\"on\"}}"))
        assertNull(PhoneActionRules.parse("{\"tool\":\"toggle_setting\",\"args\":{\"name\":\"wifi\",\"state\":\"maybe\"}}"))
        assertEquals("browse_in_app", PhoneActionRules.parse("{\"tool\":\"browse_in_app\",\"args\":{\"query\":\"taj mahal\",\"site\":\"wikipedia\"}}")?.tool)
    }
}
