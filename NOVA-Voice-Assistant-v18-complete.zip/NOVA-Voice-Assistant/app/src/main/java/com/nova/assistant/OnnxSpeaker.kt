package com.nova.assistant

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.app.ActivityManager
import android.content.Context
import java.io.File
import java.nio.FloatBuffer

/**
 * v6.34 better "only my voice" engine: WeSpeaker ResNet34 (VoxCeleb) speaker model, 256-number voiceprint, run with ONNX Runtime.
 * It is a UPGRADE with an automatic fallback: it is only used when
 *   - the 26 MB model file was downloaded and verified (size + SHA-256 pinned, Hugging Face host only),
 *   - the phone is strong enough (RAM, CPU cores),
 *   - it has not failed on this phone (two errors in a row switch it off, VoiceLock then uses the old Vosk speaker model).
 * The voiceprint saved by AWAAZ SAVE contains BOTH prints, so the switch needs no new recording.
 * Evidence level: written + the feature maths unit tested against a numpy reference. The ONNX call itself is NOT compiled or phone tested here.
 */
object OnnxSpeaker {
    const val URL = "https://huggingface.co/Wespeaker/wespeaker-voxceleb-resnet34-LM/resolve/main/voxceleb_resnet34_LM.onnx"
    const val SHA256 = "7bb2f06e9df17cdf1ef14ee8a15ab08ed28e8d0ef5054ee135741560df2ec068"
    const val SIZE = 26530309L
    const val MIN_RAM_MB = 3500L
    const val MIN_CORES = 4
    private const val MAX_SAMPLES = 16000 * 12    // never feed more than 12 s
    private const val MIN_FRAMES = 80             // 0.8 s
    private const val PREF = "nova_ext"
    private const val BAD = "onnx_spk_bad"

    @Volatile var lastWhy: String = ""
    private val lock = Any()
    private var env: OrtEnvironment? = null
    private var session: OrtSession? = null
    private var inputName = "feats"
    private var fails = 0
    private val downloading = java.util.concurrent.atomic.AtomicBoolean(false)

    private fun dir(ctx: Context) = File(ctx.filesDir, "model-spk2")
    private fun modelFile(ctx: Context) = File(dir(ctx), "voxceleb_resnet34_LM.onnx")

    fun modelReady(ctx: Context): Boolean {
        val f = modelFile(ctx)
        return File(dir(ctx), ".done").isFile && f.isFile && f.length() == SIZE
    }

    /** Pure rule (unit tested): is this phone strong enough? */
    fun deviceOk(totalRamMb: Long, cores: Int): Boolean = VoiceEngineRules.deviceOk(totalRamMb, cores)

    private fun totalRamMb(ctx: Context): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return 0L
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.totalMem / (1024L * 1024L)
    }

    fun phoneOk(ctx: Context): Boolean = deviceOk(totalRamMb(ctx), Runtime.getRuntime().availableProcessors())

    private fun appCode(ctx: Context): Int = UpdateManager.appVersion(ctx)

    /** Switched off after repeated failures on this phone (a newer app version tries again). */
    fun isBad(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt(BAD, -1) == appCode(ctx)
    } catch (e: Exception) { false }

    private fun markBad(ctx: Context, why: String) {
        lastWhy = why
        try { ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt(BAD, appCode(ctx)).apply() } catch (e: Exception) { }
        release()
    }

    /** true = the new engine will be used (model there, phone strong enough, not failed before). */
    fun usable(ctx: Context): Boolean = modelReady(ctx) && phoneOk(ctx) && !isBad(ctx)

    /** Worth downloading on this phone at all? */
    fun wanted(ctx: Context): Boolean = phoneOk(ctx) && !isBad(ctx)

    fun release() {
        synchronized(lock) {
            try { session?.close() } catch (t: Throwable) { }
            session = null
        }
    }

    /** Download + verify the 26 MB model. null = ready, otherwise a short reason. Worker thread only. */
    fun ensure(ctx: Context): String? {
        val app = ctx.applicationContext
        if (modelReady(app)) return null
        if (!wanted(app)) return "phone-not-suitable"
        if (!downloading.compareAndSet(false, true)) return "busy"
        try {
            val d = dir(app); d.mkdirs()
            val part = File(d, "model.part")
            val r = ModelDownload.download(
                URL, part, SIZE, SHA256,
                { Updater.hostAllowed(it, null) }, { false }, { }, d.usableSpace
            )
            return when (r) {
                is ModelDownload.Result.Ok -> {
                    val dest = modelFile(app)
                    dest.delete()
                    if (!r.file.renameTo(dest)) { r.file.delete(); "could not save" }
                    else { File(d, ".done").writeText("1"); null }
                }
                is ModelDownload.Result.Fail -> r.reason
            }
        } catch (t: Throwable) {
            return t.javaClass.simpleName
        } finally {
            downloading.set(false)
        }
    }

    private fun open(ctx: Context): OrtSession? {
        session?.let { return it }
        val e = env ?: OrtEnvironment.getEnvironment().also { env = it }
        val opts = OrtSession.SessionOptions()
        opts.setIntraOpNumThreads(2)
        val s = e.createSession(modelFile(ctx).absolutePath, opts)
        try { inputName = s.inputNames.first() } catch (t: Throwable) { }
        session = s
        return s
    }

    /**
     * Voiceprint of one utterance (16 kHz mono 16-bit PCM): (256 numbers, frame count), or null (too short / not usable / failed).
     * Two failures in a row switch the engine off for this app version, so VoiceLock falls back to the Vosk speaker model by itself.
     */
    fun embed(ctx: Context, pcm: ByteArray): Pair<DoubleArray, Int>? {
        if (!usable(ctx)) { lastWhy = "onnx-not-usable"; return null }
        val feats = Fbank.compute(Fbank.pcmToSamples(pcm, MAX_SAMPLES))
        val frames = if (feats == null) 0 else feats.size / Fbank.MELS
        if (feats == null || frames < MIN_FRAMES) { lastWhy = "no-voice-vector"; return null }
        synchronized(lock) {
            var tensor: OnnxTensor? = null
            var res: ai.onnxruntime.OrtSession.Result? = null
            try {
                val s = open(ctx) ?: run { lastWhy = "onnx-open"; return null }
                val e = env ?: return null
                val t = OnnxTensor.createTensor(e, FloatBuffer.wrap(feats), longArrayOf(1L, frames.toLong(), Fbank.MELS.toLong()))
                tensor = t
                res = s.run(mapOf(inputName to t))
                val v = res.get(0).value
                val emb: FloatArray = when (v) {
                    is Array<*> -> (v.firstOrNull() as? FloatArray) ?: throw IllegalStateException("bad output")
                    is FloatArray -> v
                    else -> throw IllegalStateException("bad output")
                }
                if (emb.size < 16 || emb.any { !it.isFinite() }) throw IllegalStateException("bad numbers")
                fails = 0
                lastWhy = ""
                return Pair(DoubleArray(emb.size) { emb[it].toDouble() }, frames)
            } catch (t: Throwable) {
                lastWhy = "onnx-" + t.javaClass.simpleName
                if (++fails >= 2) markBad(ctx, lastWhy)
                return null
            } finally {
                try { res?.close() } catch (t: Throwable) { }
                try { tensor?.close() } catch (t: Throwable) { }
            }
        }
    }
}
