package com.nova.assistant

/**
 * v6.35: pure rules for the two speaker engines (no Android classes, so they are unit tested on a normal JVM).
 *  - "vosk"  = old Vosk speaker model, 128-number print, old thresholds (SpeakerRules).
 *  - "onnx"  = WeSpeaker ResNet34, 256-number print, cosine-distance levels below.
 * The ONNX levels are a GUESS (not tuned on a phone). The owner's own tuned limit is used only when it was tuned with the SAME engine.
 */
object VoiceEngineRules {
    const val VOSK = "vosk"
    const val ONNX = "onnx"

    const val ONNX_STRICT = 0.45
    const val ONNX_NORMAL = 0.55
    const val ONNX_LOOSE = 0.65

    /** Phone strong enough for the ResNet engine? (same rule OnnxSpeaker uses) */
    fun deviceOk(totalRamMb: Long, cores: Int): Boolean = totalRamMb >= 3500L && cores >= 4

    /** The new engine only when the profile has an ONNX print AND the engine is usable on this phone. */
    fun pickEngine(hasOnnxPrint: Boolean, onnxUsable: Boolean): String = if (hasOnnxPrint && onnxUsable) ONNX else VOSK

    fun levelThreshold(engine: String, level: Int): Double =
        if (engine == ONNX) when (level) { 1 -> ONNX_NORMAL; 2 -> ONNX_LOOSE; else -> ONNX_STRICT }
        else SpeakerRules.thresholdFor(level)

    /**
     * [tuned] = the owner's tuned limit (0 = not tuned), [tunedEngine] = the engine it was tuned with
     * ("" = saved by an older app version, which only had Vosk).
     */
    fun effectiveThreshold(engine: String, level: Int, tuned: Double, tunedEngine: String): Double {
        val sameEngine = (if (tunedEngine.isEmpty()) VOSK else tunedEngine) == engine
        return if (sameEngine) {
            if (tuned.isFinite() && tuned >= VoiceTune.MIN_THRESHOLD && tuned <= VoiceTune.MAX_THRESHOLD) tuned
            else levelThreshold(engine, level)
        } else levelThreshold(engine, level)
    }

    fun isTunedFor(engine: String, tuned: Double, tunedEngine: String): Boolean {
        val sameEngine = (if (tunedEngine.isEmpty()) VOSK else tunedEngine) == engine
        return sameEngine && tuned.isFinite() && tuned >= VoiceTune.MIN_THRESHOLD && tuned <= VoiceTune.MAX_THRESHOLD
    }

    /** Short UI text for the status line. */
    fun engineText(engine: String, hasProfile: Boolean, hasOnnxPrint: Boolean, onnxUsable: Boolean): String = when {
        engine == ONNX -> "naya ResNet"
        hasProfile && !hasOnnxPrint && onnxUsable -> "purana Vosk (naya ke liye AWAAZ HATAO, phir dobara save)"
        else -> "purana Vosk"
    }
}

/**
 * v6.35: voiceprint file format, kept in a pure object so it can be unit tested.
 * {"v":[128 numbers],"v2":[256 numbers]}  - "v2" is optional (only when the ONNX print was made too).
 * Old files with only "v" stay valid.
 */
object VoiceProfileCodec {
    class Profile(val v: DoubleArray, val v2: DoubleArray?)

    private fun valid(a: DoubleArray): Boolean {
        if (a.size < 3 || a.any { !it.isFinite() }) return false
        var norm = 0.0
        for (x in a) norm += x * x
        return norm > 1e-12
    }

    private fun arr(a: DoubleArray): String = a.joinToString(",", "[", "]") { it.toString() }

    /** null = not saveable (too short, NaN/Infinity, all zero). A bad v2 is dropped, a bad v refuses everything. */
    fun encode(v: DoubleArray, v2: DoubleArray?): String? {
        if (!valid(v)) return null
        val good2 = if (v2 != null && valid(v2)) v2 else null
        return if (good2 != null) "{\"v\":" + arr(v) + ",\"v2\":" + arr(good2) + "}" else "{\"v\":" + arr(v) + "}"
    }

    private fun field(text: String, name: String): DoubleArray? {
        val m = Regex("\"" + name + "\"\\s*:\\s*\\[([^\\]]*)\\]").find(text) ?: return null
        val body = m.groupValues[1].trim()
        if (body.isEmpty()) return null
        val parts = body.split(",")
        val out = DoubleArray(parts.size)
        for (i in parts.indices) out[i] = parts[i].trim().toDoubleOrNull() ?: return null
        return out
    }

    /** null = no usable "v". An unreadable or invalid "v2" is ignored (the Vosk print still works). */
    fun decode(text: String): Profile? {
        val v = field(text, "v") ?: return null
        if (v.isEmpty() || v.any { !it.isFinite() }) return null
        val v2 = field(text, "v2")?.takeIf { it.isNotEmpty() && it.all { x -> x.isFinite() } }
        return Profile(v, v2)
    }
}
