package com.nova.assistant

/**
 * v18: phone feature switches by voice. Pure Kotlin (unit tested), no Android classes.
 * parse() turns a short normalized sentence into ONE of:
 *   Cmd("toggle", "<name>:<on|off>")   wifi, bluetooth, airplane, hotspot, location, dnd, rotation, nfc, batterysaver, dark, mobiledata
 *   Cmd("ringer", "<silent|vibrate|normal>")
 *   Cmd("timeout", "", seconds)        screen off time
 * The service decides HOW (direct Android API when allowed, else the Quick Settings tile through Accessibility).
 * A sentence that only names a settings PAGE ("open wifi settings") returns null so the page still opens.
 */
object SettingRules {
    val NAMES = setOf("wifi", "bluetooth", "airplane", "hotspot", "location", "dnd", "rotation", "nfc", "batterysaver", "dark", "mobiledata")

    private val ON = setOf("on", "chalu", "chalao", "enable", "start", "shuru", "activate")
    private val OFF = setOf("off", "band", "bandh", "bnd", "disable", "stop", "deactivate")
    private val NEGATE = setOf("mat", "nahi", "nahin", "nhi", "dont", "not", "no")
    private val PAGE = setOf("settings", "setting", "page")

    /** Words shown on the Quick Settings tiles (English; the tile text is matched as whole words). */
    fun tileLabels(name: String): List<String> = when (name) {
        "wifi" -> listOf("wifi", "wi fi", "internet")
        "bluetooth" -> listOf("bluetooth")
        "airplane" -> listOf("airplane mode", "flight mode", "aeroplane mode", "airplane")
        "hotspot" -> listOf("hotspot", "mobile hotspot")
        "location" -> listOf("location", "gps")
        "dnd" -> listOf("do not disturb", "dnd")
        "rotation" -> listOf("auto rotate", "auto rotation", "rotation")
        "nfc" -> listOf("nfc")
        "batterysaver" -> listOf("battery saver", "power saving", "power saver")
        "dark" -> listOf("dark theme", "dark mode")
        "mobiledata" -> listOf("mobile data", "cellular data")
        else -> emptyList()
    }

    fun spokenName(name: String): String = when (name) {
        "wifi" -> "Wi-Fi"; "bluetooth" -> "Bluetooth"; "airplane" -> "Airplane mode"; "hotspot" -> "Hotspot"
        "location" -> "Location"; "dnd" -> "Do not disturb"; "rotation" -> "Auto rotate"; "nfc" -> "NFC"
        "batterysaver" -> "Battery saver"; "dark" -> "Dark mode"; "mobiledata" -> "Mobile data"
        else -> name
    }

    /** Names that need a spoken yes first (they cut or open the phone's connection). */
    fun needsConfirm(name: String): Boolean = name == "airplane" || name == "hotspot"

    fun parse(n: String): Logic.Cmd? {
        val t = n.trim().lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (t.size < 2 || t.size > 9) return null
        val s = t.toSet()
        if (s.any { it in NEGATE && !(it == "not" && "disturb" in s) }) return null   // "do not disturb" is a name, not a negation
        if (s.any { it in PAGE }) return null

        // ---- screen off time: "screen timeout 30 seconds", "screen time out 2 minutes"
        val timeout = "timeout" in s || ("time" in s && "out" in s) || ("screen" in s && "off" in s && "time" in s)
        if (timeout) {
            val num = t.firstOrNull { it.all { c -> c.isDigit() } && it.length in 1..4 }?.toIntOrNull() ?: return null
            val unitMin = s.any { it == "minute" || it == "minutes" || it == "min" || it == "mins" }
            val unitSec = s.any { it == "second" || it == "seconds" || it == "sec" || it == "secs" }
            if (!unitMin && !unitSec) return null
            val sec = if (unitMin) num * 60 else num
            if (sec !in 15..1800) return null
            return Logic.Cmd("timeout", "", sec)
        }

        // ---- ringer: "phone silent karo", "ringer vibrate", "sound normal"
        val ringerCtx = s.any { it in setOf("phone", "mobile", "ringer", "ring", "sound", "ringtone") }
        val ringerWord = when {
            "vibrate" in s || "vibration" in s -> "vibrate"
            "silent" in s -> "silent"
            "normal" in s -> "normal"
            else -> null
        }
        if (ringerCtx && ringerWord != null && "replies" !in s && "reply" !in s) return Logic.Cmd("ringer", ringerWord)

        // ---- on / off switches
        val on = s.any { it in ON }
        val off = s.any { it in OFF }
        if (on == off) return null                     // neither, or both: not a clear switch command
        val names = LinkedHashSet<String>()
        if ("wifi" in s) names.add("wifi")
        if ("bluetooth" in s) names.add("bluetooth")
        if ("airplane" in s || "aeroplane" in s || "flight" in s) names.add("airplane")
        if ("hotspot" in s) names.add("hotspot")
        if ("location" in s || "gps" in s) names.add("location")
        if ("dnd" in s || "disturb" in s) names.add("dnd")
        if ("rotation" in s || "rotate" in s || "autorotate" in s) names.add("rotation")
        if ("nfc" in s) names.add("nfc")
        if ("battery" in s && "saver" in s || "power" in s && "saving" in s) names.add("batterysaver")
        if ("dark" in s && ("mode" in s || "theme" in s)) names.add("dark")
        if (("mobile" in s || "cellular" in s) && "data" in s) names.add("mobiledata")
        if (names.size != 1) return null               // none, or two different switches in one sentence
        return Logic.Cmd("toggle", names.first() + ":" + (if (on) "on" else "off"))
    }
}
