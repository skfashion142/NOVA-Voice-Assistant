package com.nova.assistant

import android.annotation.SuppressLint
import android.app.Activity
import android.graphics.Bitmap
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout

/**
 * v18: NOVA's own small browser, so "google par X dhundo" / "wikipedia par X" open INSIDE the app.
 * Only http / https pages load; every other scheme (intent:, file:, javascript:, market:) is blocked.
 * Extra: "url". The address bar accepts a link, a domain or search words (Google).
 */
class NovaBrowserActivity : Activity() {
    private var web: WebView? = null
    private var bar: EditText? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        val w = WebView(this)
        web = w
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.allowFileAccess = false
        w.settings.allowContentAccess = false
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean =
                !BrowserRules.safeUrl(request.url.toString())      // true = blocked
            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) { if (url != null) bar?.setText(url) }
        }
        val back = Button(this).apply { text = "<"; isAllCaps = false; setOnClickListener { goBackOrClose() } }
        val box = EditText(this).apply {
            setSingleLine(true)
            hint = "Link ya search likho"
            imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_GO) { BrowserRules.fromAddressBar(text.toString())?.let { w.loadUrl(it) }; true } else false
            }
        }
        bar = box
        val close = Button(this).apply { text = "X"; isAllCaps = false; setOnClickListener { finish() } }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val p = (6 * d).toInt()
            setPadding(p, p, p, p)
            addView(back)
            addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(close)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(w, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        }
        setContentView(root)
        val u = intent?.getStringExtra("url") ?: ""
        w.loadUrl(if (BrowserRules.safeUrl(u)) u else "https://www.google.com")
    }

    private fun goBackOrClose() {
        val w = web
        if (w != null && w.canGoBack()) w.goBack() else finish()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { goBackOrClose() }

    override fun onDestroy() {
        try { (web?.parent as? ViewGroup)?.removeView(web); web?.destroy() } catch (e: Exception) { }
        web = null
        super.onDestroy()
    }
}
