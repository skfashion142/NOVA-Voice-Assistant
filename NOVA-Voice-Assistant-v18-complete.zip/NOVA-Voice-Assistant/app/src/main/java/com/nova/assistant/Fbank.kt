package com.nova.assistant

/**
 * v6.34: Kaldi-style 80-bin log-mel filterbank (the input of the WeSpeaker ResNet34 speaker model).
 * Pure Kotlin (no Android classes) so it is unit tested on a normal JVM.
 * Settings are the ones WeSpeaker uses: 16 kHz, 25 ms window / 10 ms shift, povey window, pre-emphasis 0.97, DC removal,
 * no dither, FFT 512, mel range 20 Hz .. 8 kHz, natural log of the power, then cepstral mean subtraction over time.
 */
object Fbank {
    const val RATE = 16000
    const val FRAME_LEN = 400          // 25 ms
    const val FRAME_SHIFT = 160        // 10 ms
    const val FFT_N = 512
    const val MELS = 80
    private const val LOW_HZ = 20.0
    private const val PREEMPH = 0.97
    private const val EPS = 1.1920929e-07   // float epsilon: log floor, same as Kaldi

    private val window = DoubleArray(FRAME_LEN) { n ->
        Math.pow(0.5 - 0.5 * Math.cos(2.0 * Math.PI * n / (FRAME_LEN - 1)), 0.85)
    }

    private fun mel(hz: Double) = 1127.0 * Math.log(1.0 + hz / 700.0)

    /** Triangular filters over the first FFT_N/2 bins (the Nyquist bin is not used, like Kaldi). */
    private val bins: Array<DoubleArray> = run {
        val nFft = FFT_N / 2
        val fftBinHz = RATE.toDouble() / FFT_N
        val lowMel = mel(LOW_HZ)
        val highMel = mel(RATE / 2.0)
        val delta = (highMel - lowMel) / (MELS + 1)
        Array(MELS) { b ->
            val left = lowMel + b * delta
            val center = lowMel + (b + 1) * delta
            val right = lowMel + (b + 2) * delta
            DoubleArray(nFft) { k ->
                val m = mel(fftBinHz * k)
                if (m > left && m < right) {
                    if (m <= center) (m - left) / (center - left) else (right - m) / (right - center)
                } else 0.0
            }
        }
    }

    private val cosT = DoubleArray(FFT_N / 2) { Math.cos(2.0 * Math.PI * it / FFT_N) }
    private val sinT = DoubleArray(FFT_N / 2) { -Math.sin(2.0 * Math.PI * it / FFT_N) }

    /** In-place iterative radix-2 FFT of size FFT_N. */
    private fun fft(re: DoubleArray, im: DoubleArray) {
        val n = FFT_N
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val half = len shr 1
            val step = n / len
            var i = 0
            while (i < n) {
                var k = 0
                for (m in i until i + half) {
                    val wr = cosT[k]
                    val wi = sinT[k]
                    val xr = re[m + half] * wr - im[m + half] * wi
                    val xi = re[m + half] * wi + im[m + half] * wr
                    re[m + half] = re[m] - xr
                    im[m + half] = im[m] - xi
                    re[m] += xr
                    im[m] += xi
                    k += step
                }
                i += len
            }
            len = len shl 1
        }
    }

    /** Number of frames for [samples] samples (snip edges: only complete frames). */
    fun frameCount(samples: Int): Int = if (samples < FRAME_LEN) 0 else 1 + (samples - FRAME_LEN) / FRAME_SHIFT

    /** 16-bit little-endian mono PCM -> samples in int16 range (Kaldi / WeSpeaker use the unscaled int16 values). */
    fun pcmToSamples(pcm: ByteArray, maxSamples: Int = Int.MAX_VALUE): DoubleArray {
        val n = minOf(pcm.size / 2, maxSamples)
        return DoubleArray(n) { i ->
            val lo = pcm[2 * i].toInt() and 0xff
            val hi = pcm[2 * i + 1].toInt()
            ((hi shl 8) or lo).toShort().toDouble()
        }
    }

    /** Returns frames x 80 features (mean-subtracted over time), flat row-major, or null when the audio is shorter than one frame. */
    fun compute(x: DoubleArray): FloatArray? {
        val t = frameCount(x.size)
        if (t <= 0) return null
        val out = FloatArray(t * MELS)
        val frame = DoubleArray(FRAME_LEN)
        val re = DoubleArray(FFT_N)
        val im = DoubleArray(FFT_N)
        val pow = DoubleArray(FFT_N / 2)
        for (f in 0 until t) {
            val s = f * FRAME_SHIFT
            var mean = 0.0
            for (i in 0 until FRAME_LEN) { frame[i] = x[s + i]; mean += frame[i] }
            mean /= FRAME_LEN
            for (i in 0 until FRAME_LEN) frame[i] -= mean
            for (i in FRAME_LEN - 1 downTo 1) frame[i] -= PREEMPH * frame[i - 1]
            frame[0] -= PREEMPH * frame[0]
            for (i in 0 until FRAME_LEN) { re[i] = frame[i] * window[i]; im[i] = 0.0 }
            for (i in FRAME_LEN until FFT_N) { re[i] = 0.0; im[i] = 0.0 }
            fft(re, im)
            for (k in 0 until FFT_N / 2) pow[k] = re[k] * re[k] + im[k] * im[k]
            for (b in 0 until MELS) {
                val w = bins[b]
                var e = 0.0
                for (k in w.indices) { val wk = w[k]; if (wk != 0.0) e += wk * pow[k] }
                out[f * MELS + b] = Math.log(Math.max(e, EPS)).toFloat()
            }
        }
        // cepstral mean normalisation over the whole utterance
        for (b in 0 until MELS) {
            var m = 0.0
            for (f in 0 until t) m += out[f * MELS + b]
            m /= t
            for (f in 0 until t) out[f * MELS + b] = (out[f * MELS + b] - m).toFloat()
        }
        return out
    }
}
