package com.nova.assistant

import java.net.URLEncoder

/**
 * v18: in-app browser rules. Pure Kotlin (unit tested), no Android classes.
 * "nova wikipedia par taj mahal dhundo" / "google par iphone price search karo" -> a search URL that NovaBrowserActivity
 * opens INSIDE the NOVA app (a WebView; Chrome itself cannot be embedded). Anything about another app (WhatsApp group,
 * Instagram ...) returns null here, so it is never stolen from the app / agent path.
 */
object BrowserRules {
    private val OTHER_APPS = setOf(
        "whatsapp", "instagram", "facebook", "telegram", "gmail", "group", "message", "sms", "call", "snapchat", "twitter",
        "youtube", "amazon", "flipkart", "maps", "playstore"
    )
    private val NEGATE = setOf("mat", "nahi", "nahin", "nhi", "dont", "not", "no")
    private val SEARCH_VERBS = setOf("search", "dhundo", "dhoondo", "dhundh", "dhundho", "dhoondho", "khojo", "khoj", "find", "lookup")
    private val WIKI = setOf("wikipedia", "wiki")
    private val WEB = setOf("google", "chrome", "browser", "internet", "net", "web")
    private val SHOW = setOf("andar", "app", "dikhao", "dikha", "kholo", "khol", "open", "show")
    private val ASK = setOf("batao", "bata", "btao", "tell", "explain", "kya", "kaun", "kitna", "kitni", "kab", "kaise", "why", "what", "who", "when", "how")
    private val DROP = setOf(
        "nova", "hey", "please", "plz", "pls", "zara", "mujhe", "mujhko", "mere", "meri", "mera", "ko", "ka", "ki", "ke", "par", "pe", "per", "pr",
        "mein", "me", "se", "ye", "yeh", "wo", "woh", "the", "a", "an", "for", "on", "in", "of", "about", "and", "aur", "phir", "fir",
        "google", "chrome", "browser", "internet", "net", "web", "wikipedia", "wiki",
        "search", "dhundo", "dhoondo", "dhundh", "dhundho", "dhoondho", "khojo", "khoj", "find", "lookup",
        "karo", "kar", "kro", "kr", "kardo", "krdo", "do", "de", "dena", "andar", "app", "baare", "bare", "baarein", "batao", "bata", "btao",
        "dikhao", "dekho", "open", "kholo", "khol", "use", "karke", "liye", "lie", "jankari", "information", "info", "h", "hai", "ho", "ek",
        "i", "want", "can", "you", "could", "would", "tell", "me", "us", "isme", "usme", "wahan", "yahan"
    )
    const val MAX_QUERY_WORDS = 8

    /** n = normalized text (lower case a-z0-9 and spaces). Returns the https URL to open in the app, or null. */
    fun parse(n: String): String? {
        val t = n.trim().lowercase().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (t.size < 2 || t.size > 24) return null
        val s = t.toSet()
        if (s.any { it in NEGATE }) return null
        if (s.any { it in OTHER_APPS }) return null
        val wiki = s.any { it in WIKI }
        val web = s.any { it in WEB }
        if (!wiki && !web) return null
        val verb = s.any { it in SEARCH_VERBS }
        val show = s.any { it in SHOW }
        if (!verb && !(wiki && show)) return null   // "chrome kholo" alone is the normal open_app; "wikipedia par X batao" is answered by NOVA itself
        if (!show && s.any { it in ASK }) return null   // a question wants an ANSWER (spoken), not a web page
        val q = t.filter { it !in DROP }
        if (q.isEmpty() || q.size > MAX_QUERY_WORDS) return null
        val query = q.joinToString(" ")
        val enc = URLEncoder.encode(query, "UTF-8")
        return if (wiki) "https://en.wikipedia.org/w/index.php?search=$enc" else "https://www.google.com/search?q=$enc"
    }

    /** Only plain web pages may load inside the app browser. */
    fun safeUrl(u: String): Boolean {
        val x = u.trim().lowercase()
        return (x.startsWith("https://") || x.startsWith("http://")) && x.length < 2000
    }

    /** What the address bar of the in-app browser does with typed text: a link, a domain, or a Google search. */
    fun fromAddressBar(raw: String): String? {
        val x = raw.trim()
        if (x.isEmpty()) return null
        if (safeUrl(x)) return x
        if (!x.contains(" ") && x.contains(".") && !x.contains("://")) return "https://$x"
        return "https://www.google.com/search?q=" + URLEncoder.encode(x, "UTF-8")
    }
}
