package com.nova.assistant

/** Strict local parser for explicit WhatsApp send commands. It never guesses a contact or message. */
object WhatsAppCommandRules {
    data class Request(val recipient: String, val message: String)



    fun parse(input: String): Request? {
        val r = parseNorm(input) ?: return null
        // Logic.norm lowercases; give back the owner's original casing when it appears verbatim.
        fun restore(x: String) = Regex(Regex.escape(x), RegexOption.IGNORE_CASE).find(input)?.value ?: x
        return Request(restore(r.recipient), restore(r.message))
    }

    private fun parseNorm(input: String): Request? {
        val n = Logic.stripWake(Logic.norm(input))
        if (!n.startsWith("whatsapp ")) return null
        val rest = n.removePrefix("whatsapp ").trim()
        if (rest.isBlank()) return null
        val explicit = Regex("^(.+?)\\s+ko\\s+(?:message\\s+)?(?:bhejo|bhejna|send)\\s+(.+)$").find(rest)
        if (explicit != null) return clean(explicit.groupValues[1], explicit.groupValues[2])
        val explicit2 = Regex("^(.+?)\\s+ko\\s+(?:whatsapp\\s+)?(?:par\\s+)?message\\s+(.+)$").find(rest)
        if (explicit2 != null) return clean(explicit2.groupValues[1], explicit2.groupValues[2])
        val send = Regex("^(.+?)\\s+(?:bhejo|bhejna|send)\\s+(.+)$").find(rest)
        if (send != null) return clean(send.groupValues[1], send.groupValues[2])
        // Exact requested short form: WhatsApp <two-word contact> <message>.
        // Contact resolution against the real Contacts database remains authoritative.
        val words = rest.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.size >= 3) return clean(words.take(2).joinToString(" "), words.drop(2).joinToString(" "))
        return null
    }

    private fun clean(to: String, message: String): Request? {
        val r = to.trim(); val m = message.trim()
        if (r.isBlank() || m.isBlank() || r.length > 80 || m.length > 1000) return null
        if (r.equals("biswan", true)) return null
        return Request(r, m)
    }
}
