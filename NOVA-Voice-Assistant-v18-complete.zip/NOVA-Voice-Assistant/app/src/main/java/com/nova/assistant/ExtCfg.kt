package com.nova.assistant

import android.content.Context

/** Extra settings that live in their own small store: how long NOVA waits after you stop speaking. */
object ExtCfg {
    private const val PREF = "nova_ext"
    private const val WAIT = "wait_sec"
    const val DEFAULT_WAIT_SEC = 5

    fun waitSec(ctx: Context): Int = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt(WAIT, DEFAULT_WAIT_SEC).coerceIn(2, 10)
    } catch (e: Exception) { DEFAULT_WAIT_SEC }

    fun setWaitSec(ctx: Context, sec: Int) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt(WAIT, sec.coerceIn(2, 10)).apply()
        } catch (e: Exception) { }
    }

    fun waitMs(ctx: Context): Int = waitSec(ctx) * 1000

    private const val ALERTS = "alerts_on"

    /** v16 proactive alerts (low battery spoken once per 30 minutes). Default OFF since v6.30 (it made NOVA listen without being called). */
    fun alerts(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(ALERTS, true)
    } catch (e: Exception) { true }

    fun setAlerts(ctx: Context, on: Boolean) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(ALERTS, on).apply()
        } catch (e: Exception) { }
    }

    private const val CONVO = "convo_mode_v2"   // v6.30: new key so the old default-ON value of existing installs is dropped

    /** v16 conversation mode: after a spoken reply NOVA listens again (up to 3 times in a row) without the wake word. Default OFF since v6.30 (it made NOVA listen without being called). */
    fun convo(ctx: Context): Boolean = try {
        !novaOnly(ctx) && ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(CONVO, false)   // v18: "Sirf Nova" always wins
    } catch (e: Exception) { false }

    private const val NOVA_ONLY = "nova_only_v18"

    /**
     * v18 "Sirf Nova": when ON (default) NOVA wakes ONLY on the word "nova" (custom wake words are ignored),
     * never listens again after a reply without being called (conversation mode is forced off), and the only talking
     * it does by itself is the rare screen / battery alert. A pending yes / no answer is NOT a wake: it still works.
     */
    fun novaOnly(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(NOVA_ONLY, true)
    } catch (e: Exception) { true }

    fun setNovaOnly(ctx: Context, on: Boolean) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(NOVA_ONLY, on).apply()
        } catch (e: Exception) { }
    }

    fun setConvo(ctx: Context, on: Boolean) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(CONVO, on).apply()
        } catch (e: Exception) { }
    }

    private const val AUTO_MODELS = "auto_models"

    /** v17: download the small voice-check model by itself when the mic service starts. Default ON (about 14 MB). */
    fun autoModels(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(AUTO_MODELS, true)
    } catch (e: Exception) { true }

    fun setAutoModels(ctx: Context, on: Boolean) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(AUTO_MODELS, on).apply()
        } catch (e: Exception) { }
    }

    private const val VOICE_LEVEL = "voice_level"

    /** v17: how strict the voice lock is. 0 STRICT (default), 1 NORMAL, 2 LOOSE. */
    fun voiceLevel(ctx: Context): Int = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getInt(VOICE_LEVEL, 0).coerceIn(0, 2)
    } catch (e: Exception) { 0 }

    fun setVoiceLevel(ctx: Context, level: Int) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putInt(VOICE_LEVEL, level.coerceIn(0, 2)).apply()
        } catch (e: Exception) { }
    }

    // ---- Part 5: voice self-tuning + lock-screen face gate
    private const val VOICE_THR = "voice_threshold"
    private const val VOICE_OWN = "voice_own_dists"
    private const val FACE_GATE = "face_gate"

    /** The limit chosen by the owner's own voice test. 0.0 = not tuned (the STRICT / NORMAL / LOOSE level is used). */
    fun voiceThreshold(ctx: Context): Double = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getFloat(VOICE_THR, 0f).toDouble()
    } catch (e: Exception) { 0.0 }

    fun setVoiceThreshold(ctx: Context, v: Double) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putFloat(VOICE_THR, v.toFloat()).apply()
        } catch (e: Exception) { }
    }

    private const val AUTO_LEARN = "auto_learn"

    /** v6.38 owner request: RAKHO is required again. Auto learn (v6.37) is now OFF by default; the old pending note + RAKHO flow is used. */
    fun autoLearn(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(AUTO_LEARN, false)
    } catch (e: Exception) { false }

    fun setAutoLearn(ctx: Context, on: Boolean) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(AUTO_LEARN, on).apply()
        } catch (e: Exception) { }
    }

    private const val NOISE_CANCEL = "noise_cancel"

    /** v6.36: background noise cancellation (phone's NoiseSuppressor + echo canceller) on the mic. Default ON. */
    fun noiseCancel(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(NOISE_CANCEL, true)
    } catch (e: Exception) { true }

    fun setNoiseCancel(ctx: Context, on: Boolean) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(NOISE_CANCEL, on).apply()
        } catch (e: Exception) { }
    }

    private const val VOICE_TUNED_ENGINE = "voice_tuned_engine"

    /** v6.35: the speaker engine the tuned limit was made with ("" = older app version = Vosk). */
    fun voiceTunedEngine(ctx: Context): String = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(VOICE_TUNED_ENGINE, "") ?: ""
    } catch (e: Exception) { "" }

    fun setVoiceTunedEngine(ctx: Context, engine: String) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(VOICE_TUNED_ENGINE, engine).apply()
        } catch (e: Exception) { }
    }

    /** Distances (plain numbers, no audio) of the owner's test sentences, kept so another person's test can be compared later. */
    fun voiceOwnDists(ctx: Context): String = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(VOICE_OWN, "") ?: ""
    } catch (e: Exception) { "" }

    fun setVoiceOwnDists(ctx: Context, s: String) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(VOICE_OWN, s).apply()
        } catch (e: Exception) { }
    }

    /** Locked phone: NOVA acts only when the voice AND the system face / fingerprint check pass. Default OFF. */
    /** v6.39 owner request: no face / fingerprint prompt any more. A matched OWNER voice unlocks the phone by itself (see NovaService.ownerUnlock). */
    fun faceGate(ctx: Context): Boolean = false

    fun setFaceGate(ctx: Context, on: Boolean) {
        try {
            val e = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(FACE_GATE, on)
            if (on) e.putBoolean(LOCK_OPT_IN, true)
            e.apply()
        } catch (e: Exception) { }
    }

    private const val LOCK_OPT_IN = "lock_opt_in"

    /** v6.38 owner request: the voice lock and the face gate are NOT enforced unless the owner switches one of them ON again in Settings (older saved ON values are ignored). */
    @Suppress("UNUSED_PARAMETER")
    private fun lockOptIn(ctx: Context): Boolean = true   // v6.39 owner request: the voice check is mandatory, no opt-in

    /** v6.38 owner request: no spoken yes/no for risky taps, deletes, bulk sends. Default ON = never ask. Hard-blocked screens (bank, payment, password, Settings, installer) stay blocked. */
    fun skipRiskyConfirm(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("skip_risky_confirm", true)
    } catch (e: Exception) { true }

    private const val VOICE_LOCK = "voice_lock"

    /** v17 "only my voice": when ON (and a voiceprint exists) every spoken turn must match the owner. Default OFF until enrolled. */
    fun voiceLock(ctx: Context): Boolean = true   // v6.39 owner request: always ON, the owner's voice is mandatory for every command

    fun setVoiceLock(ctx: Context, on: Boolean) {
        try {
            val e = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(VOICE_LOCK, on)
            if (on) e.putBoolean(LOCK_OPT_IN, true)
            e.apply()
        } catch (e: Exception) { }
    }

    private const val VOICE_SILENT = "voice_silent"

    /** v6.32 owner request: an ordinary order (WhatsApp message, call) runs at once, no yes/no question. Deletes, payments and risky taps still ask. */
    fun skipOrderConfirm(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean("skip_order_confirm", true)
    } catch (e: Exception) { true }

    /** v6.28 strict: when ON (default) and the voice lock is active, a different voice gets NO reaction at all: no chat line, no speech, no cloud call. */
    fun voiceSilent(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(VOICE_SILENT, true)
    } catch (e: Exception) { true }

    fun setVoiceSilent(ctx: Context, on: Boolean) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(VOICE_SILENT, on).apply()
        } catch (e: Exception) { }
    }

    private const val FREE_CHAIN = "free_chain"
    private const val FREE_KEYLESS = "free_keyless"

    /** Public topic-only Wikipedia lookup plus the free online AI chain (Groq / OpenRouter / legacy Pollinations). Default OFF since v6.30 (it made NOVA listen without being called). */
    fun freeChain(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(FREE_CHAIN, true)
    } catch (e: Exception) { true }

    fun setFreeChain(ctx: Context, on: Boolean) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(FREE_CHAIN, on).apply()
        } catch (e: Exception) { }
    }

    private const val MEMORY_IN_CHAIN = "memory_in_chain"

    /** Default ON: at most 3 RELEVANT personal facts may be added to the online free chain's prompt (never to Gemini). */
    fun memoryInChain(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(MEMORY_IN_CHAIN, true)
    } catch (e: Exception) { true }

    fun setMemoryInChain(ctx: Context, on: Boolean) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(MEMORY_IN_CHAIN, on).apply()
        } catch (e: Exception) { }
    }

    /** Legacy no-key Pollinations attempt. Current provider docs may require a key; keep failures best-effort only. */
    fun freeKeyless(ctx: Context): Boolean = try {
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(FREE_KEYLESS, true)
    } catch (e: Exception) { true }

    fun setFreeKeyless(ctx: Context, on: Boolean) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(FREE_KEYLESS, on).apply()
        } catch (e: Exception) { }
    }
}
