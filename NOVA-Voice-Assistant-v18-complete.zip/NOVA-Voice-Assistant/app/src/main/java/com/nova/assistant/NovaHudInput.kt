package com.nova.assistant

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout

/**
 * v18: typed message box shown from the floating NOVA card (keyboard button).
 * A separate small overlay window, because the card itself is NOT focusable (it must never steal the keyboard
 * from the app underneath). Main thread only. Without "Display over other apps" it is a silent no-op.
 * The text goes to NovaService.typed(): exactly like a spoken command, and a typed "yes" never approves a risky action.
 */
class NovaHudInput(private val ctx: Context) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var root: LinearLayout? = null

    val isShown: Boolean get() = root != null

    fun show(onSend: (String) -> Unit) {
        if (root != null || !Settings.canDrawOverlays(ctx)) return
        val d = ctx.resources.displayMetrics.density
        val box = EditText(ctx).apply {
            hint = "NOVA ko likh kar bolo..."
            setHintTextColor(0xFF6F86AD.toInt())
            setTextColor(0xFFEAF2FF.toInt())
            textSize = 15f
            maxLines = 3
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            background = null
        }
        val send = Button(ctx).apply { text = "Bhejo"; isAllCaps = false }
        val close = Button(ctx).apply { text = "X"; isAllCaps = false }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val p = (10 * d).toInt()
            setPadding(p, p, p, p)
            background = GradientDrawable().apply {
                setColor(0xF0101A33.toInt())
                cornerRadius = 18f * d
                setStroke((1.5f * d).toInt().coerceAtLeast(1), 0xAA27E1FF.toInt())
            }
            addView(box, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(send, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(close, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        fun submit() {
            val text = box.text.toString().trim()
            if (text.isEmpty()) return
            hide()
            onSend(text)
        }
        send.setOnClickListener { submit() }
        close.setOnClickListener { hide() }
        box.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { submit(); true } else false }
        row.setOnTouchListener { _, e -> if (e.actionMasked == MotionEvent.ACTION_OUTSIDE) { hide(); true } else false }
        val lp = WindowManager.LayoutParams(
            (minOf(ctx.resources.displayMetrics.widthPixels - 32 * d, 400 * d)).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (200 * d).toInt()
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN
        try {
            wm.addView(row, lp)
            root = row
            box.requestFocus()
        } catch (e: Exception) {
            root = null
        }
    }

    fun hide() {
        val v = root ?: return
        root = null
        try { wm.removeView(v) } catch (e: Exception) { }
    }
}
