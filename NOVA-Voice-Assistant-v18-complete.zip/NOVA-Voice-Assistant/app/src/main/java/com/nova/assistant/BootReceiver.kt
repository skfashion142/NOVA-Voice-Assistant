package com.nova.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * After a phone restart NOVA does NOT start and shows NO notification.
 * It only re-arms the user's own saved reminders/scheduled tasks. NOVA starts only when the owner taps ACTIVATE.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val a = i.action
        if (a != Intent.ACTION_BOOT_COMPLETED && a != "android.intent.action.QUICKBOOT_POWERON") return
        try { Cfg(c).active = false } catch (_: Exception) { }
        try { ScheduledTaskStore.rescheduleAll(c) } catch (_: Exception) { }
    }
}
