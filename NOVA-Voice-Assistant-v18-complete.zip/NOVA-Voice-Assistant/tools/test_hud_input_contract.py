#!/usr/bin/env python3
"""Static contract checks for the typed-message box on the NOVA card (v18). Not a compile; GitHub Actions compiles."""
from pathlib import Path
import sys
R = Path(__file__).resolve().parents[1] / "app/src/main/java/com/nova/assistant"
hud = (R / "NovaHud.kt").read_text(encoding="utf-8")
inp = (R / "NovaHudInput.kt").read_text(encoding="utf-8")
checks = {
    "card has a type callback": "var onTypeTap" in hud and "nv.onTypeTap = {" in hud,
    "keyboard button drawn": "drawKeyControl(c, right - 75f * d" in hud,
    "keyboard button hit-tested on touch up": "onTypeTap?.invoke()" in hud,
    "typed text goes through NovaService.typed": "NovaService.instance?.typed(text)" in hud,
    "input box needs overlay permission": "canDrawOverlays" in inp,
    "input window is focusable (no NOT_FOCUSABLE flag)": "FLAG_NOT_FOCUSABLE" not in inp,
    "input closes on destroy": "input.hide()" in hud,
    "empty text is never sent": "text.isEmpty()) return" in inp,
}
for f in (hud, inp):
    assert f.count("{") == f.count("}"), "unbalanced braces"
bad = [k for k, v in checks.items() if not v]
for k, v in checks.items(): print(("OK   " if v else "FAIL ") + k)
sys.exit(1 if bad else 0)
