#!/usr/bin/env python3
"""Static contract checks for v18 (typed popup box, Sirf Nova, in-app browser, phone switches). Not a compile; GitHub Actions compiles."""
from pathlib import Path
import re, sys
R = Path(__file__).resolve().parents[1] / "app/src"
J = R / "main/java/com/nova/assistant"
def rd(p): return p.read_text(encoding="utf-8")
svc, ext, acc, br, sr = rd(J/"NovaService.kt"), rd(J/"ExtCfg.kt"), rd(J/"NovaAccessibilityService.kt"), rd(J/"BrowserRules.kt"), rd(J/"SettingRules.kt")
logic, ui, man, main = rd(J/"Logic.kt"), rd(R/"main/assets/ui.html"), rd(R/"main/AndroidManifest.xml"), rd(J/"MainActivity.kt")
checks = {
 "Sirf Nova default ON": 'getBoolean(NOVA_ONLY, true)' in ext,
 "Sirf Nova forces wake word nova": "if (ExtCfg.novaOnly(this)) return Logic.DEFAULT_WAKE" in svc,
 "Sirf Nova disables conversation mode": "!novaOnly(ctx) &&" in ext,
 "Sirf Nova switch in UI + bridge": 'id="no_on"' in ui and "fun setNovaOnly" in main and "Android.setNovaOnly" in ui,
 "browser activity registered": ".NovaBrowserActivity" in man,
 "browser only http(s)": "!BrowserRules.safeUrl(request.url.toString())" in rd(J/"NovaBrowserActivity.kt"),
 "classify hooks browser + switches": "BrowserRules.parse(n)" in logic and "SettingRules.parse(n)" in logic,
 "runLocalTool dispatches new kinds": all(k in svc for k in ['"browse" -> browseInApp', '"toggle" -> toggleSetting', '"ringer" -> ringerMode', '"timeout" -> screenTimeout']),
 "tile press only inside System UI": 'pkg.contains("systemui")' in acc,
 "airplane/hotspot need spoken yes": "askFirst(prompt, true)" in svc and 'name == "airplane" || name == "hotspot"' in sr,
 "AI tools declared + executed": '"toggle_setting"' in svc and '"browse_in_app"' in svc and 'tool("toggle_setting"' in svc,
 "free providers allow-list": "toggle_setting" in rd(J/"PhoneActionRules.kt"),
 "agent answers questions": "put the exact answer in" in rd(J/"AgentRules.kt"),
}
def strip(t):
    t = re.sub(r'"""[\s\S]*?"""', "", t)
    t = re.sub(r'"(?:\\.|[^"\\\n])*"', '""', t)
    t = re.sub(r"'(?:\\.|[^'\\\n])'", "''", t)
    t = re.sub(r"//[^\n]*", "", t)
    return re.sub(r"/\*[\s\S]*?\*/", "", t)
for p in ["NovaHud.kt", "NovaHudInput.kt", "NovaBrowserActivity.kt", "BrowserRules.kt", "SettingRules.kt", "NovaService.kt", "NovaAccessibilityService.kt", "ExtCfg.kt", "Logic.kt", "PhoneActionRules.kt", "AgentRules.kt", "MainActivity.kt"]:
    t = strip(rd(J / p))
    for a, b in (("{", "}"), ("(", ")"), ("[", "]")):
        if t.count(a) != t.count(b): checks[f"balanced {a}{b} in {p}"] = False
bad = [k for k, v in checks.items() if not v]
for k, v in checks.items(): print(("OK   " if v else "FAIL ") + k)
sys.exit(1 if bad else 0)
