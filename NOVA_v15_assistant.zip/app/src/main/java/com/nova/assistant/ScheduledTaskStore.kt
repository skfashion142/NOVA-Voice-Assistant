package com.nova.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.ZoneId
import java.time.LocalDateTime
import java.util.UUID

/** Private on-device schedule store. Scheduled message content is never sent to AI or written to logs. */
object ScheduledTaskStore {
    data class Entry(val id: String, val spec: ScheduledTaskRules.Spec, val nextAtMs: Long)
    private const val PREFS = "nova_scheduled_tasks"
    private const val KEY = "items_v1"
    private const val MAX_ITEMS = 30

    @Synchronized private fun read(ctx: Context): List<Entry> {
        val raw = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null) ?: return emptyList()
        return try {
            val a = JSONArray(raw); val out = ArrayList<Entry>()
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val spec = ScheduledTaskRules.decode(o.optString("spec")) ?: continue
                val id = o.optString("id").take(80)
                if (id.isNotBlank()) out.add(Entry(id, spec, o.optLong("next", 0L)))
            }
            out.takeLast(MAX_ITEMS)
        } catch (_: Exception) { emptyList() }
    }

    @Synchronized private fun write(ctx: Context, entries: List<Entry>): Boolean {
        val a = JSONArray()
        entries.takeLast(MAX_ITEMS).forEach { e ->
            a.put(JSONObject().put("id", e.id).put("spec", ScheduledTaskRules.encode(e.spec)).put("next", e.nextAtMs))
        }
        return ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).commit()
    }

    /** Returns status exact/inexact/cap/storage/invalid. A schedule never claims exact timing without OS permission. */
    @Synchronized fun add(ctx: Context, spec: ScheduledTaskRules.Spec): String {
        if (spec.hour !in 0..23 || spec.minute !in 0..59) return "invalid"
        if (spec.kind == ScheduledTaskRules.Kind.SEND_MESSAGE &&
            (spec.recipient.isBlank() || spec.message.isBlank() || Driving.looksSensitive(spec.message))) return "message_incomplete_or_sensitive"
        val old = read(ctx)
        if (old.size >= MAX_ITEMS) return "limit"
        val entry = Entry(UUID.randomUUID().toString(), spec, ScheduledTaskRules.nextAtMillis(spec))
        if (!write(ctx, old + entry)) return "storage_failed"
        return if (scheduleAlarm(ctx, entry)) "exact" else "inexact"
    }

    fun list(ctx: Context): List<Entry> = read(ctx)
    fun get(ctx: Context, id: String): Entry? = read(ctx).firstOrNull { it.id == id }

    @Synchronized fun cancelAll(ctx: Context): Int {
        val old = read(ctx)
        old.forEach { cancelAlarm(ctx, it.id) }
        write(ctx, emptyList())
        return old.size
    }

    @Synchronized fun cancel(ctx: Context, query: String): Boolean {
        val old = read(ctx)
        val match = old.firstOrNull { it.id == query || it.id.startsWith(query) || it.spec.label.equals(query, true) }
            ?: return false
        cancelAlarm(ctx, match.id)
        return write(ctx, old.filterNot { it.id == match.id })
    }

    /** Called by the receiver at fire time. One-shot jobs are removed before running to prevent duplicate sends. */
    @Synchronized fun consume(ctx: Context, id: String): Entry? {
        val old = read(ctx)
        val found = old.firstOrNull { it.id == id } ?: return null
        return if (found.spec.repeatDaily) {
            val next = found.copy(nextAtMs = maxOf(found.nextAtMs + 86_400_000L, ScheduledTaskRules.nextAtMillis(found.spec)))
            if (write(ctx, old.map { if (it.id == id) next else it })) scheduleAlarm(ctx, next)
            found
        } else {
            cancelAlarm(ctx, id)
            write(ctx, old.filterNot { it.id == id })
            found
        }
    }

    @Synchronized fun rescheduleAll(ctx: Context) {
        val all = read(ctx)
        all.forEach { e ->
            val corrected = if (e.nextAtMs > System.currentTimeMillis()) e else e.copy(nextAtMs = ScheduledTaskRules.nextAtMillis(e.spec))
            scheduleAlarm(ctx, corrected)
        }
    }

    fun listText(ctx: Context): String {
        val items = list(ctx)
        if (items.isEmpty()) return "Koi scheduled task nahi hai."
        return items.take(10).joinToString(" ") { e ->
            val t = LocalDateTime.ofInstant(Instant.ofEpochMilli(e.nextAtMs), ZoneId.systemDefault())
            val time = String.format(java.util.Locale.ROOT, "%02d:%02d", t.hour, t.minute)
            "ID ${e.id.take(8)}: ${e.spec.label.ifBlank { e.spec.kind.name }} $time ${if (e.spec.repeatDaily) "roz" else "ek baar"}."
        }
    }

    private fun pending(ctx: Context, e: Entry): PendingIntent = PendingIntent.getBroadcast(
        ctx, e.id.hashCode(), Intent(ctx, ScheduledTaskReceiver::class.java).setAction(ACTION_FIRE).putExtra(EXTRA_ID, e.id),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    private fun scheduleAlarm(ctx: Context, e: Entry): Boolean {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return false
        return try {
            val pi = pending(ctx, e)
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e.nextAtMs, pi)
                false
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e.nextAtMs, pi)
                true
            }
        } catch (_: SecurityException) {
            try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, e.nextAtMs, pending(ctx, e)) } catch (_: Exception) { }
            false
        } catch (_: Exception) { false }
    }

    private fun cancelAlarm(ctx: Context, id: String) {
        try { ctx.getSystemService(AlarmManager::class.java)?.cancel(pending(ctx, Entry(id, ScheduledTaskRules.Spec(0, 0, false, ScheduledTaskRules.Kind.REMINDER, ""), 0))) } catch (_: Exception) { }
    }

    const val ACTION_FIRE = "com.nova.assistant.SCHEDULED_TASK_FIRE"
    const val EXTRA_ID = "task_id"
}
