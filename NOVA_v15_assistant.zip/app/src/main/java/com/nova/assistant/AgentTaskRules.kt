package com.nova.assistant

/**
 * Durable task lifecycle rules for NOVA's agent. Pure Kotlin: no Android APIs, so transitions are testable.
 * A task reported complete by a model is deliberately NOT the same as independently verified success.
 */
object AgentTaskRules {
    const val MAX_HISTORY = 20
    const val MAX_TASK_CHARS = 400
    const val MAX_SUMMARY_CHARS = 120
    const val MAX_RETRIES = 3
    const val MAX_RUNTIME_MS = 300_000L

    enum class State {
        CREATED,
        PLANNING,
        WAITING_FOR_PERMISSION,
        WAITING_FOR_CONFIRMATION,
        RUNNING,
        VERIFYING,
        RETRYING,
        SUCCEEDED,
        REPORTED_COMPLETE,
        NEEDS_OWNER,
        FAILED,
        CANCELLED,
        INTERRUPTED
    }

    fun isTerminal(state: State): Boolean = state in setOf(
        State.SUCCEEDED, State.REPORTED_COMPLETE, State.NEEDS_OWNER,
        State.FAILED, State.CANCELLED, State.INTERRUPTED
    )

    fun isActive(state: State): Boolean = !isTerminal(state)

    fun canTransition(from: State, to: State): Boolean {
        if (from == to) return true
        if (isTerminal(from)) return false
        if (to == State.INTERRUPTED) return true
        if (to in setOf(State.SUCCEEDED, State.REPORTED_COMPLETE, State.NEEDS_OWNER, State.FAILED, State.CANCELLED)) return true
        return when (from) {
            State.CREATED -> to == State.PLANNING
            State.PLANNING -> to in setOf(State.RUNNING, State.WAITING_FOR_PERMISSION, State.WAITING_FOR_CONFIRMATION, State.RETRYING, State.VERIFYING)
            State.WAITING_FOR_PERMISSION -> to in setOf(State.PLANNING, State.RUNNING, State.WAITING_FOR_CONFIRMATION)
            State.WAITING_FOR_CONFIRMATION -> to in setOf(State.RUNNING, State.PLANNING, State.WAITING_FOR_PERMISSION)
            State.RUNNING -> to in setOf(State.PLANNING, State.WAITING_FOR_PERMISSION, State.WAITING_FOR_CONFIRMATION, State.VERIFYING, State.RETRYING)
            State.VERIFYING -> to in setOf(State.RUNNING, State.PLANNING, State.RETRYING)
            State.RETRYING -> to in setOf(State.PLANNING, State.RUNNING)
            else -> false
        }
    }

    fun canRetry(retryCount: Int, createdAtMs: Long, nowMs: Long, maxRetries: Int = MAX_RETRIES): Boolean {
        if (retryCount < 0 || maxRetries < 0 || retryCount >= maxRetries) return false
        if (nowMs < createdAtMs) return false
        return nowMs - createdAtMs < MAX_RUNTIME_MS
    }

    /** Store only a short, redacted task label; never persist screen text, audio, or full project prompts in the ledger. */
    fun safeSummary(raw: String): String {
        val oneLine = raw.replace('\n', ' ').replace('\r', ' ').replace(Regex("\\s+"), " ").trim()
        val redacted = oneLine
            .replace(Regex("(?i)(api[_ -]?key|token|password|passwd|secret)\\s*[:=]\\s*\\S+"), "$1=[hidden]")
            .replace(Regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}"), "[email]")
            .replace(Regex("(?<![0-9])\\+?[0-9][0-9 -]{8,}[0-9](?![0-9])"), "[number]")
            .replace(Regex("(?<![A-Za-z0-9])[A-Za-z0-9_\\-]{32,}(?![A-Za-z0-9])"), "[hidden]")
        return redacted.take(MAX_SUMMARY_CHARS)
    }

    fun isStatusQuery(raw: String): Boolean {
        val n = Logic.norm(raw).removePrefix("nova ").trim()
        return n in setOf("agent status", "task status", "kaam status", "kaam ki status", "pichla kaam", "last task", "agent history", "kaam ka status")
    }
}
