package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Private on-device task history. No microphone audio or screen content is stored.
 * An active task found after service/process restart is marked INTERRUPTED, never auto-replayed (avoids duplicate taps/sends).
 */
class AgentTaskLedger(context: Context) {
    data class Task(
        val id: String,
        val summary: String,
        val state: AgentTaskRules.State,
        val createdAtMs: Long,
        val updatedAtMs: Long,
        val deadlineAtMs: Long,
        val retryCount: Int = 0,
        val steps: Int = 0,
        val message: String = ""
    )

    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun start(task: String, nowMs: Long = System.currentTimeMillis()): Task? = synchronized(LOCK) {
        val old = readAll()
        if (old.any { AgentTaskRules.isActive(it.state) }) return@synchronized null
        val clean = AgentTaskRules.safeSummary(task.take(AgentTaskRules.MAX_TASK_CHARS))
        val created = Task(
            id = UUID.randomUUID().toString(),
            summary = clean,
            state = AgentTaskRules.State.CREATED,
            createdAtMs = nowMs,
            updatedAtMs = nowMs,
            deadlineAtMs = nowMs + AgentTaskRules.MAX_RUNTIME_MS,
            message = "Task accepted; not yet verified"
        )
        if (!writeAll((old + created).takeLast(AgentTaskRules.MAX_HISTORY))) return@synchronized null
        created
    }

    fun transition(id: String?, target: AgentTaskRules.State, message: String = "", nowMs: Long = System.currentTimeMillis()): Task? = synchronized(LOCK) {
        if (id.isNullOrBlank()) return@synchronized null
        val all = readAll()
        val index = all.indexOfLast { it.id == id }
        if (index < 0) return@synchronized null
        val old = all[index]
        if (!AgentTaskRules.canTransition(old.state, target)) return@synchronized old
        val next = old.copy(
            state = target,
            updatedAtMs = nowMs.coerceAtLeast(old.updatedAtMs),
            retryCount = old.retryCount + if (target == AgentTaskRules.State.RETRYING && old.state != target) 1 else 0,
            message = safeMessage(message).ifBlank { old.message }
        )
        val updated = all.toMutableList().also { it[index] = next }
        if (!writeAll(updated.takeLast(AgentTaskRules.MAX_HISTORY))) return@synchronized old
        next
    }

    fun recordStep(id: String?, message: String = "", nowMs: Long = System.currentTimeMillis()): Task? = synchronized(LOCK) {
        if (id.isNullOrBlank()) return@synchronized null
        val all = readAll()
        val index = all.indexOfLast { it.id == id }
        if (index < 0) return@synchronized null
        val old = all[index]
        if (!AgentTaskRules.isActive(old.state)) return@synchronized old
        val next = old.copy(steps = (old.steps + 1).coerceAtMost(1000), updatedAtMs = nowMs.coerceAtLeast(old.updatedAtMs), message = safeMessage(message).ifBlank { old.message })
        val updated = all.toMutableList().also { it[index] = next }
        if (!writeAll(updated.takeLast(AgentTaskRules.MAX_HISTORY))) return@synchronized old
        next
    }

    /** Call when NOVA's service starts. This marks stale work interrupted rather than replaying unsafe UI actions. */
    fun recoverInterrupted(nowMs: Long = System.currentTimeMillis()): Int = synchronized(LOCK) {
        val all = readAll()
        var count = 0
        val changed = all.map { task ->
            if (AgentTaskRules.isActive(task.state)) {
                count++
                task.copy(state = AgentTaskRules.State.INTERRUPTED, updatedAtMs = nowMs.coerceAtLeast(task.updatedAtMs), message = "NOVA restart/service stop detected; not resumed to avoid repeating actions")
            } else task
        }
        if (count > 0 && !writeAll(changed.takeLast(AgentTaskRules.MAX_HISTORY))) return@synchronized 0
        count
    }

    fun latest(): Task? = synchronized(LOCK) { readAll().lastOrNull() }
    fun history(): List<Task> = synchronized(LOCK) { readAll().toList() }

    fun statusText(): String {
        val task = latest() ?: return "NOVA agent history: abhi tak koi task record nahi hai."
        val state = when (task.state) {
            AgentTaskRules.State.CREATED -> "shuru hone ke liye bana"
            AgentTaskRules.State.PLANNING -> "planning"
            AgentTaskRules.State.WAITING_FOR_PERMISSION -> "permission ka intezar"
            AgentTaskRules.State.WAITING_FOR_CONFIRMATION -> "aapki confirmation ka intezar"
            AgentTaskRules.State.RUNNING -> "chal raha hai"
            AgentTaskRules.State.VERIFYING -> "verify kar raha hai"
            AgentTaskRules.State.RETRYING -> "bounded retry chal raha hai"
            AgentTaskRules.State.SUCCEEDED -> "verified success"
            AgentTaskRules.State.REPORTED_COMPLETE -> "agent ne complete report kiya; result independently verify nahi hua"
            AgentTaskRules.State.NEEDS_OWNER -> "aapki madad/step chahiye"
            AgentTaskRules.State.FAILED -> "fail hua"
            AgentTaskRules.State.CANCELLED -> "aapne rok diya"
            AgentTaskRules.State.INTERRUPTED -> "beech mein interrupt hua; automatically dobara nahi chalayega"
        }
        val label = task.summary.ifBlank { "task" }
        return "Aakhri task: $label. Status: $state. Steps: ${task.steps}. ${task.message}".take(420)
    }

    private fun readAll(): List<Task> {
        val primary = prefs.getString(KEY_TASKS, null)
        if (!primary.isNullOrBlank()) parse(primary)?.let { return it }
        val backup = prefs.getString(KEY_BACKUP, null)
        return parse(backup) ?: emptyList()
    }

    private fun parse(raw: String?): List<Task>? {
        if (raw.isNullOrBlank()) return null
        return try {
            val arr = JSONArray(raw)
            val out = ArrayList<Task>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val state = try { AgentTaskRules.State.valueOf(o.optString("state")) } catch (_: Exception) { AgentTaskRules.State.INTERRUPTED }
                out.add(Task(
                    id = o.optString("id"),
                    summary = o.optString("summary").take(AgentTaskRules.MAX_SUMMARY_CHARS),
                    state = state,
                    createdAtMs = o.optLong("created", 0L),
                    updatedAtMs = o.optLong("updated", 0L),
                    deadlineAtMs = o.optLong("deadline", 0L),
                    retryCount = o.optInt("retries", 0).coerceIn(0, AgentTaskRules.MAX_RETRIES),
                    steps = o.optInt("steps", 0).coerceIn(0, 1000),
                    message = safeMessage(o.optString("message"))
                ))
            }
            out.takeLast(AgentTaskRules.MAX_HISTORY)
        } catch (_: Exception) { null }
    }

    private fun writeAll(tasks: List<Task>): Boolean {
        val current = prefs.getString(KEY_TASKS, null)
        val arr = JSONArray()
        tasks.takeLast(AgentTaskRules.MAX_HISTORY).forEach { t ->
            arr.put(JSONObject()
                .put("id", t.id)
                .put("summary", t.summary)
                .put("state", t.state.name)
                .put("created", t.createdAtMs)
                .put("updated", t.updatedAtMs)
                .put("deadline", t.deadlineAtMs)
                .put("retries", t.retryCount)
                .put("steps", t.steps)
                .put("message", safeMessage(t.message)))
        }
        // Commit synchronously: this is a small status ledger, and an async write could be lost on process death.
        return prefs.edit().putString(KEY_BACKUP, current).putString(KEY_TASKS, arr.toString()).commit()
    }

    private fun safeMessage(raw: String): String = AgentTaskRules.safeSummary(raw).take(160)

    companion object {
        private const val PREFS = "nova_agent_task_ledger"
        private const val KEY_TASKS = "tasks_v1"
        private const val KEY_BACKUP = "tasks_backup_v1"
        private val LOCK = AgentTaskLedger::class.java
    }
}
