#!/usr/bin/env python3
"""Source-contract guards for persistent task status and safe restart behavior (not an Android build)."""
from pathlib import Path
import re
import sys
ROOT = Path(__file__).resolve().parent.parent
JAVA = ROOT / "app/src/main/java/com/nova/assistant"
rules = (JAVA / "AgentTaskRules.kt").read_text(encoding="utf-8")
ledger = (JAVA / "AgentTaskLedger.kt").read_text(encoding="utf-8")
service = (JAVA / "NovaService.kt").read_text(encoding="utf-8")
tests = (ROOT / "app/src/test/java/com/nova/assistant/AgentTaskRulesTest.kt").read_text(encoding="utf-8")
fails = []
def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond: fails.append(name)

for state in ("CREATED", "PLANNING", "WAITING_FOR_PERMISSION", "WAITING_FOR_CONFIRMATION", "RUNNING", "VERIFYING", "RETRYING", "SUCCEEDED", "REPORTED_COMPLETE", "NEEDS_OWNER", "FAILED", "CANCELLED", "INTERRUPTED"):
    check(f"task state exists: {state}", f"{state}," in rules or f"{state}\n" in rules)
check("history is capped", "MAX_HISTORY = 20" in rules and "takeLast(AgentTaskRules.MAX_HISTORY)" in ledger)
check("retry count and runtime have fixed caps", "MAX_RETRIES = 3" in rules and "MAX_RUNTIME_MS = 300_000L" in rules and "fun canRetry" in rules)
check("task summaries redact key-like text, email and phone numbers", "[hidden]" in rules and "[email]" in rules and "[number]" in rules and "MAX_SUMMARY_CHARS" in rules)
check("task ledger is private app storage", 'getSharedPreferences(PREFS, Context.MODE_PRIVATE)' in ledger)
check("task ledger persists synchronously with a backup", ".commit()" in ledger and "KEY_BACKUP" in ledger)
check("active task is not duplicated", "old.any { AgentTaskRules.isActive(it.state) }" in ledger)
check("in-flight task is marked interrupted on recovery instead of replayed", "fun recoverInterrupted" in ledger and "State.INTERRUPTED" in ledger and "not resumed to avoid repeating actions" in ledger)
check("task status summary is exposed from local ledger", "fun statusText()" in ledger and "isStatusQuery(text)" in service)
check("agent start persists task before its worker begins", service.index("ledger.start(task)") < service.index('Thread({', service.index("private fun agentStart")))
check("spoken stop cancels and persists agent state", '"stop" -> {' in service and 'agentCancel = true' in service and 'State.CANCELLED, "Owner said stop"' in service)
check("service restart cancels/marks interrupted rather than resuming automatically", "AgentTaskLedger(this).recoverInterrupted()" in service and "NOVA service stopped" in service)
check("model completion is not presented as independently verified success", "State.REPORTED_COMPLETE" in service and "independently verify" in ledger and "verify kar lo" in service)
check("ledger persists a neutral terminal status, not the model's answer", "val persistedStatus = when (agentOutcome)" in service and "ledger.transition(record.id, agentOutcome, persistedStatus)" in service and "ledger.transition(record.id, agentOutcome, result)" not in service)
check("step history never persists typed content or raw screen excerpt", 'recordStep(agentTaskId, "Step $step: action=${a.act}; result=$res")' in service and "recordStep(agentTaskId, line)" not in service)
check("Kotlin unit tests cover lifecycle, retries, status and privacy", all(x in tests for x in ("normalLifecycleAndTerminalStates", "retryBudgetAndDeadlineAreBounded", "sensitiveStringsAreNotKeptInSummary", "statusQueriesAreNarrowAndDoNotStealNormalLanguage")))
print("\nALL PASSED" if not fails else f"\n{len(fails)} FAILED")
sys.exit(1 if fails else 0)
