#!/usr/bin/env python3
"""v6.25: structural check (Kotlin NOT run) that the voice-lock auto test and the multi-segment speaker vector are wired."""
import os, sys
J = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "java", "com", "nova", "assistant")
rd = lambda f: open(os.path.join(J, f), encoding="utf-8").read()
NS, ST, VL, SR, WP = (rd(f) for f in ("NovaService.kt", "SelfTest.kt", "VoiceLock.kt", "SpeakerRules.kt", "WavPcm.kt"))
bad = 0
def check(name, cond):
    global bad
    print(("PASS " if cond else "FAIL ") + name)
    if not cond: bad += 1
check("vector() collects every segment (acceptWaveForm result) and merges", "if (r.acceptWaveForm(" in VL and "take(r.result)" in VL and "take(r.finalResult)" in VL and "SpeakerRules.mergeParts(parts)" in VL)
check("failure reason is kept and shown", "var lastWhy" in VL and "VoiceLock.lastWhy" in NS)
check("mergeParts exists", "fun mergeParts(" in SR)
check("self test calls the voice-lock check", "svc.testVoiceLock(rec)" in ST)
check("hook synthesizes to a file (no sound) and refuses a synthetic voice", "synthesizeToFile" in NS and "fun testVoiceLock(" in NS and "SpeakerRules.Verdict.ALLOW -> rec(\"FAIL\"" in NS)
check("wav helper has overflow-safe data length", "len > b.size - body" in WP and "fun to16k(" in WP)
check("synthetic voice never saved or sent: temp file deleted", "f.delete()" in NS and "vl_selftest.wav" in NS)
FC = rd("FeatureCheck.kt")
check("v6.27 hard test: mic, hearing, internet, storage are real checks", all(x in ST for x in ("svc.testMic()", "svc.testHearing(rec)", "Internet (asli HTTPS)", "Phone storage likh/padh sakta hai")))
check("v6.27 no unconditional fake PASS left in FeatureCheck", 'rec("PASS", "Agent task history' not in FC and 'rec("PASS", "Calendar/meeting rules"' not in FC)
check("v6.27 report says what is NOT tested and splits real vs rule-only", "NOT TESTED" in ST and "SIRF RULE/CONFIG PASS=" in ST)
sys.exit(1 if bad else 0)
