package com.nova.assistant

import android.content.Context
import org.nehuatl.llamacpp.LlamaHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Real on-device GGUF inference adapter for the bundled LocalBrain slot. */
class LlamaBrain(
    private val context: Context,
    private val modelPath: String
) : LocalBrain {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val events = MutableSharedFlow<LlamaHelper.LLMEvent>(extraBufferCapacity = 128)
    private val helper = LlamaHelper(context.contentResolver, scope, events)
    @Volatile private var loaded = false
    @Volatile private var closed = false
    private var loadJob: Job? = null

    init {
        val file = File(modelPath)
        if (file.isFile && file.length() > 100L * 1024 * 1024) {
            val latch = CountDownLatch(1)
            loadJob = scope.launch {
                try {
                    helper.load(file.toURI().toString(), 2048) { _ ->
                        loaded = true
                        latch.countDown()
                    }
                } catch (_: Throwable) {
                    latch.countDown()
                }
            }
            latch.await(45, TimeUnit.SECONDS)
        }
    }

    override val ready: Boolean
        get() = loaded && !closed

    override fun complete(prompt: String): String? {
        if (!ready || closed) return null
        val out = StringBuilder()
        val done = CountDownLatch(1)
        val job = scope.launch {
            try {
                val collector = launch {
                    events.collect { event ->
                        when (event) {
                            is LlamaHelper.LLMEvent.Ongoing -> out.append(event.word)
                            is LlamaHelper.LLMEvent.Done -> done.countDown()
                            is LlamaHelper.LLMEvent.Error -> done.countDown()
                            else -> Unit
                        }
                    }
                }
                // Do not call predict until the collector is subscribed; SharedFlow otherwise may drop the first tokens.
                events.subscriptionCount.first { it > 0 }
                helper.predict(prompt)
                withTimeoutOrNull(LocalChat.TIMEOUT_MS) { while (done.count > 0) kotlinx.coroutines.delay(20) }
                collector.cancel()
            } catch (_: Throwable) {
                done.countDown()
            }
        }
        done.await(LocalChat.TIMEOUT_MS + 1000L, TimeUnit.MILLISECONDS)
        job.cancel()
        return LocalChat.clean(out.toString())
    }

    override fun close() {
        if (closed) return
        closed = true
        try { helper.stopPrediction() } catch (_: Throwable) { }
        try { helper.release() } catch (_: Throwable) { }
        scope.cancel()
    }
}
