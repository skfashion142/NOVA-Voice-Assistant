package com.nova.assistant

import android.content.Context
import java.util.concurrent.atomic.AtomicBoolean

/**
 * v17 model downloads.
 *  - v34: AutoSetup (one silent background runner) now starts this download; autoStart below is kept but no longer called.
 *  - Voice-check model (about 14 MB): downloaded by itself once the mic service runs (so the permissions are given),
 *    at most one attempt every 6 hours, only when the owner left "auto" ON. Also available as a manual button.
 *  - Qwen offline brain (491 MB): downloaded automatically after app/service startup when the device has enough RAM.
 *    The file is resumable, size+SHA-256 verified, and is never activated unless the real local engine loads it.
 * Evidence level: written + statically checked. Not compiled here, not phone tested.
 */
object ModelAuto {
    private const val PREF = "nova_ext"
    private const val LAST = "auto_model_last"
    private const val GAP_MS = 6L * 60 * 60 * 1000
    private val running = AtomicBoolean(false)

    private fun say(t: String) { try { NovaService.listener?.invoke("ai", t) } catch (e: Exception) { } }

    /** Called when the mic service starts. Silent unless it actually has something to download. */
    fun autoStart(ctx: Context) {
        if (!ExtCfg.autoModels(ctx) || VoiceLock.modelReady(ctx)) return
        val app = ctx.applicationContext
        val p = app.getSharedPreferences(PREF, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        if (now - p.getLong(LAST, 0L) < GAP_MS) return
        p.edit().putLong(LAST, now).apply()
        runVoice(app, false)
    }

    /** Settings button. "ok" started, "ready" already there, "busy" already running. */
    fun manualVoice(ctx: Context): String {
        val app = ctx.applicationContext
        if (VoiceLock.modelReady(app)) return "ready"
        if (running.get()) return "busy"
        runVoice(app, true)
        return "ok"
    }

    /** v34: silent variant for AutoSetup (no chat text). null = downloaded, "busy" = another download runs, otherwise the error. Worker thread. */
    fun silentVoice(app: Context): String? {
        if (VoiceLock.modelReady(app)) return null
        if (!running.compareAndSet(false, true)) return "busy"
        try {
            return VoiceLock.downloadModel(app)
        } finally {
            running.set(false)
        }
    }

    /** Silent auto-install of the verified offline Qwen model. */
    fun silentOfflineQwen(ctx: Context): String? {
        val app = ctx.applicationContext
        if (UpdateManager.activeModelPath(app).isNotEmpty()) return null
        if (!ModelCatalog.ramOk(totalRamMb(app))) return "ram-low"
        if (LocalBrains.factory == null) return "engine-unavailable"
        if (!running.compareAndSet(false, true)) return "busy"
        return try {
            UpdateManager.offerOfflineBrain(app) ?: run {
                val latch = java.util.concurrent.CountDownLatch(1)
                var ok = false
                var msg = "install failed"
                UpdateManager.install(app, ModelCatalog.ID) { success, text ->
                    ok = success
                    msg = text
                    latch.countDown()
                }
                latch.await(15, java.util.concurrent.TimeUnit.MINUTES)
                if (ok) null else msg.ifBlank { "install timeout" }
            }
        } finally {
            running.set(false)
        }
    }

    private fun totalRamMb(ctx: Context): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager ?: return 0L
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.totalMem / (1024L * 1024L)
    }

    private fun runVoice(app: Context, manual: Boolean) {
        if (!running.compareAndSet(false, true)) return
        Thread({
            try {
                say("Awaaz-pehchaan ka chhota model download ho raha hai (lagbhag 14 MB). Dobara mat dabao.")
                val err = VoiceLock.downloadModel(app)
                if (err == null) say("Awaaz model download ho gaya. Ab Settings > MERI AWAAZ me AWAAZ SAVE KARO dabao.")
                else if (err != "busy") say("Awaaz model download nahi hua ($err). Internet check karke Settings me MODEL DOWNLOAD dabao." + if (manual) "" else " Main 6 ghante baad phir koshish karunga.")
            } finally {
                running.set(false)
            }
        }, "nova-model-auto").start()
    }
}
