package com.nova.assistant

/**
 * Part 1 rules, pure Kotlin (no Android classes) so they are unit tested.
 * 1) CaptureRules: when a spoken command capture ends (3 s continuous silence, 60 s emergency cap).
 * 2) EnrollGuard: one voice-enrollment session, stops after the last sample, never restarts by itself.
 * 3) AlertGate: a spoken proactive alert (battery) must wait while a voice interaction is active.
 */
object CaptureRules {
    const val SILENCE_MS = 3000
    const val MAX_MS = 60000

    /** Silence counter after one chunk: speech resets it, silence adds to it, but only after speech was heard. */
    fun nextSilentMs(silentMs: Int, heard: Boolean, speaking: Boolean, chunkMs: Int): Int =
        if (speaking) 0 else if (heard) silentMs + chunkMs else silentMs

    /** true = finalize now. [silenceMs] is the needed continuous silence, [maxMs] the emergency cap. */
    fun shouldEnd(heard: Boolean, silentMs: Int, totalMs: Int, silenceMs: Int, maxMs: Int, noSpeechMs: Int): Boolean =
        (heard && silentMs >= silenceMs) || totalMs >= maxMs || (!heard && totalMs >= noSpeechMs)
}

class EnrollGuard(private val total: Int) {
    enum class State { IDLE, STARTING, ACTIVE }
    enum class Sample { MORE, DONE, IGNORED }

    private var state = State.IDLE
    private var count = 0
    private var session = 0

    @Synchronized fun state(): State = state
    @Synchronized fun count(): Int = count
    @Synchronized fun sessionId(): Int = session

    /** Explicit user action. Returns the session id, or -1 when a session is already starting/active (double tap, stale thread). */
    @Synchronized fun tryBegin(): Int {
        if (state != State.IDLE) return -1
        state = State.STARTING
        count = 0
        session++
        return session
    }

    /** The model is ready and the first prompt was shown. false = this session was cancelled meanwhile, do not start. */
    @Synchronized fun activate(id: Int): Boolean {
        if (id != session || state != State.STARTING) return false
        state = State.ACTIVE
        return true
    }

    /** One accepted sample. After the last one the guard is IDLE again and nothing restarts. */
    @Synchronized fun sample(): Sample {
        if (state != State.ACTIVE) return Sample.IGNORED
        count++
        if (count >= total) { state = State.IDLE; count = 0; return Sample.DONE }
        return Sample.MORE
    }

    /** Cancel / error / service stop. Any thread that still holds an older session id can no longer activate. */
    @Synchronized fun cancel() { state = State.IDLE; count = 0; session++ }

    @Synchronized fun active(): Boolean = state != State.IDLE
}

object AlertGate {
    /** true = the alert may be spoken now. Any active voice interaction defers it (the notification is not affected). */
    fun maySpeak(
        busy: Boolean, listening: Boolean, ttsActive: Boolean, confirmPending: Boolean,
        enrolling: Boolean, tuning: Boolean
    ): Boolean = !(busy || listening || ttsActive || confirmPending || enrolling || tuning)
}
