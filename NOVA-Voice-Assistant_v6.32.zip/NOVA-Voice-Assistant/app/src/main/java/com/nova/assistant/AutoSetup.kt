package com.nova.assistant

import android.content.Context
import java.util.concurrent.atomic.AtomicBoolean

/**
 * v34 PART 3: ONE silent background runner for everything NOVA can prepare by itself once the owner has pressed "allow":
 *  1. the voice-check model (small download),
 *  2. the verified offline Qwen model when the device has enough RAM/storage,
 *  3. a tiny health check of every online AI provider that has a key (Groq, Qwen via Groq, OpenRouter).
 * No pop-up, nothing spoken, no provider name in a chat reply. Results are only SELF TEST lines (Settings).
 * Retries use AutoSetupPlan's back-off. It cannot switch on Accessibility / Notification access / Overlay: Android forbids that.
 */
object AutoSetup {
    private const val PREFS = "nova_auto_setup"
    private const val AUTO_ENROLL_STARTED = "voice_auto_enroll_started_v2"
    private val started = AtomicBoolean(false)
    @Volatile private var stopFlag = false
    private val lines = ArrayList<String>()

    private fun add(l: String) {
        synchronized(lines) {
            lines.add(l)
            while (lines.size > 40) lines.removeAt(0)
        }
    }

    /** Lines written by the background runner so far. */
    fun log(): List<String> = synchronized(lines) { ArrayList(lines) }

    /** Called when the mic service is running (permissions given). Safe to call again: only one runner exists. */
    fun start(ctx: Context) {
        if (!started.compareAndSet(false, true)) { stopFlag = false; return }   // already running (maybe about to stop): keep it
        stopFlag = false
        val app = ctx.applicationContext
        Thread({
            try {
                loop(app)
            } catch (e: Throwable) {
                add("WARN Auto setup ruk gaya - " + e.javaClass.simpleName)
            } finally {
                started.set(false)
            }
        }, "nova-autosetup").apply { isDaemon = true }.start()
    }

    fun stop() { stopFlag = true }

    private fun loop(app: Context) {
        var tasks = AutoSetupPlan.initial()
        var hindiAttempted = false
        var lastQwenAttempt = 0L
        while (!stopFlag) {
            val now = System.currentTimeMillis()
            val t = AutoSetupPlan.due(tasks, now)
            if (t == null) {
                // The provider task repeats every 6 hours, so code after loop(app) would never run while the service stays alive.
                // Try the optional Hindi model once after the initial voice/provider setup pass, before waiting for the next task.
                if (!hindiAttempted) {
                    hindiAttempted = true
                    if (!stopFlag && ExtCfg.autoModels(app) && !HindiPack.ready(app)) {
                        val herr = HindiPack.ensure(app)
                        if (herr == null) add("READY Hindi voice pack")
                        else if (herr != "wait" && herr != "busy") add("WARN Hindi voice pack - $herr, agli baar koshish hogi")
                    }
                    if (!stopFlag && System.currentTimeMillis() - lastQwenAttempt >= 10L * 60L * 1000L) {
                        lastQwenAttempt = System.currentTimeMillis()
                        offlineQwenTask(app)
                    }
                    // Auto-enrol only once per installation. If a sample is rejected, the owner can use
                    // AWAAZ SAVE KARO again; the background runner must never start a new 5-sample loop.
                    val prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    if (!stopFlag && NovaService.instance != null && !VoiceLock.hasProfile(app) &&
                        !prefs.getBoolean(AUTO_ENROLL_STARTED, false)) {
                        prefs.edit().putBoolean(AUTO_ENROLL_STARTED, true).apply()
                        try { NovaService.instance?.startVoiceEnroll() } catch (e: Throwable) { }
                    }
                }
                val next = AutoSetupPlan.nextWake(tasks) ?: return
                try { Thread.sleep(minOf(maxOf(next - now, 1000L), 60_000L)) } catch (e: InterruptedException) { return }
                continue
            }
            val o = try {
                when (t.id) {
                    AutoSetupPlan.VOICE -> voiceTask(app)
                    AutoSetupPlan.PROVIDERS -> providersTask(app)
                    else -> AutoSetupPlan.Outcome.FATAL
                }
            } catch (e: Throwable) { AutoSetupPlan.Outcome.RETRY }
            val after = AutoSetupPlan.apply(t, o, System.currentTimeMillis())
            tasks = tasks.map { if (it.id == t.id) after else it }
        }
    }

    private fun voiceTask(app: Context): AutoSetupPlan.Outcome {
        if (!ExtCfg.autoModels(app)) { add("SKIP Awaaz model - auto band hai"); return AutoSetupPlan.Outcome.SKIP }
        if (VoiceLock.modelReady(app)) return AutoSetupPlan.Outcome.SKIP
        val err = ModelAuto.silentVoice(app)
        return if (err == null) { add("PASS Awaaz model - download ho gaya"); AutoSetupPlan.Outcome.OK }
        else { add("WARN Awaaz model - $err, dobara koshish hogi"); AutoSetupPlan.Outcome.RETRY }
    }

    private fun offlineQwenTask(app: Context) {
        if (UpdateManager.activeModelPath(app).isNotEmpty()) { add("READY Offline Qwen") ; return }
        if (!ModelCatalog.ramOk(totalRamMb(app))) { add("SKIP Offline Qwen - RAM too low"); return }
        if (LocalBrains.factory == null) { add("WARN Offline Qwen engine unavailable"); return }
        val r = ModelAuto.silentOfflineQwen(app)
        when {
            r == null -> add("READY Offline Qwen - downloaded and verified")
            r == "busy" -> add("WAIT Offline Qwen - download already running")
            else -> add("WARN Offline Qwen - $r, retry later")
        }
    }

    private fun totalRamMb(ctx: Context): Long {
        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? android.app.ActivityManager ?: return 0L
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.totalMem / (1024L * 1024L)
    }

    /** Providers that have the key they need. Pollinations (no key) is left out: it is not a setup item. */
    private fun keyOf(ctx: Context, p: FreeProvider): String = when (p.keyName) {
        "groq" -> SecureStore.getGroq(ctx)
        "openrouter" -> SecureStore.getSlot(ctx, "openrouter")
        "zai" -> SecureStore.getSlot(ctx, "zai")
        "zai2" -> SecureStore.getSlot(ctx, "zai2")
        "zai3" -> SecureStore.getSlot(ctx, "zai3")
        else -> ""
    }.trim()

    /** One tiny request per keyed provider (first model only). Returns SELF TEST lines. Network: worker thread only. */
    fun checkProviders(ctx: Context): List<Pair<String, Int>> {
        val out = ArrayList<Pair<String, Int>>()
        for (p in FreeProviders.ordered()) {
            if (p.keyName == null) continue
            val key = keyOf(ctx, p)
            if (key.isEmpty()) continue
            val r = FreeHttp.post(p, FreeProviders.buildBody(p.models[0], "Reply with one word.", "ok", 16), key)
            out.add(Pair(p.label + " (" + p.models[0] + ")", r.code))
        }
        return out
    }

    private fun providersTask(app: Context): AutoSetupPlan.Outcome {
        val res = checkProviders(app)
        if (res.isEmpty()) return AutoSetupPlan.Outcome.SKIP
        var worst = AutoSetupPlan.Outcome.OK
        for ((label, code) in res) {
            add(AutoSetupPlan.line(label, code))
            if (AutoSetupPlan.outcomeFor(code) == AutoSetupPlan.Outcome.RETRY) worst = AutoSetupPlan.Outcome.RETRY
        }
        return worst
    }
}
